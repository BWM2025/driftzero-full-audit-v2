from __future__ import annotations

from fastapi import Request
from api.dependencies.tenant_context import get_tenant_context

# Global dependencies can be re-exported here if needed
# Currently tenant context is header-based and used directly