from __future__ import annotations

import logging
from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from api.routers.auth import router as auth_router
from api.tenancy.router_tenants import router as tenants_router
from api.tenancy.router_projects import router as projects_router
from api.tenancy.router_teams import router as teams_router
from api.tenancy.router_feature_flags import router as feature_flags_router
from api.approval.router_requests import router as approval_requests_router
from api.approval.router_decisions import router as approval_decisions_router
from api.approval.router_assignments import router as approval_assignments_router
from api.websocket.router import router as websocket_router
from core.config import settings

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="DriftZero Control Plane API",
    version="3.3.0",
    description="Schema drift governance platform – Phase 5 Complete",
    openapi_url="/openapi.json",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global exception handlers
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors()},
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled exception")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal server error"},
    )

# Health check
@app.get("/health")
async def health():
    return {"status": "healthy", "version": "3.3.0"}

# Mount routers with prefixes
app.include_router(auth_router, prefix="/auth", tags=["Authentication"])
app.include_router(tenants_router, prefix="/tenants", tags=["Tenancy"])
app.include_router(projects_router, prefix="/projects", tags=["Projects"])
app.include_router(teams_router, prefix="/teams", tags=["Teams"])
app.include_router(feature_flags_router, prefix="/feature-flags", tags=["Feature Flags"])
app.include_router(approval_requests_router, prefix="/approvals", tags=["Approvals"])
app.include_router(approval_decisions_router, prefix="/approvals", tags=["Approvals"])
app.include_router(approval_assignments_router, prefix="/approver-assignments", tags=["Approvals"])

# WebSocket endpoint
app.include_router(websocket_router)

@app.on_event("startup")
async def startup_event():
    logger.info("DriftZero Control Plane API v3.3.0 — Phase 5 COMPLETE")
    logger.info("All authentication, tenancy, approval, and real-time systems online")
    logger.info(f"CORS allowed origins: {settings.ALLOWED_ORIGINS}")
    logger.info("API ready at /docs")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("DriftZero Control Plane shutting down")

# Root redirect to docs
@app.get("/")
async def root():
    return {"message": "DriftZero Control Plane — see /docs for API"}