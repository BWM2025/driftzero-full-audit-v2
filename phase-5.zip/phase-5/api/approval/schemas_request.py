from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from models.approval_request import ApprovalRequest, ApprovalStatus


class ApprovalRequestResponse(BaseModel):
    id: str
    saga_id: str
    tenant_id: str
    environment_id: str
    dataset_id: str
    requested_by: str
    requested_at: datetime
    expires_at: datetime
    resolved_at: Optional[datetime]
    required_approvers: int
    status: ApprovalStatus
    decisions: List["ApprovalDecisionResponse"] = []

    class Config:
        orm_mode = True