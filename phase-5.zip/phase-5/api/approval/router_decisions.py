from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from core.approval.approval_service import ApprovalService
from core.approval.enums import ApprovalDecisionType
from core.approval.exceptions import (
    ApprovalNotFoundError,
    ApprovalAlreadyDecidedError,
    ApprovalExpiredError,
)
from db.session import get_async_session
from api.dependencies.current_user import get_current_active_user
from .schemas_decision import ApprovalDecisionCreate, ApprovalDecisionResponse

router = APIRouter(prefix="/approvals", tags=["Approvals"])


@router.post("/{request_id}/decide", response_model=ApprovalDecisionResponse)
async def submit_decision(
    request_id: str,
    payload: ApprovalDecisionCreate,
    db: AsyncSession = Depends(get_async_session),
    user = Depends(get_current_active_user),
):
    try:
        decision = await ApprovalService.record_decision(
            db,
            request_id=request_id,
            approver_user_id=str(user.id),
            decision=ApprovalDecisionType(payload.decision),
            comment=payload.comment,
        )
        return ApprovalDecisionResponse.from_orm(decision)
    except ApprovalNotFoundError:
        raise HTTPException(status_code=404, detail="Approval request not found")
    except ApprovalAlreadyDecidedError:
        raise HTTPException(status_code=410, detail="Approval already decided")
    except ApprovalExpiredError:
        raise HTTPException(status_code=410, detail="Approval request expired")