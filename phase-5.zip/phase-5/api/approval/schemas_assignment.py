from pydantic import BaseModel
from typing import Optional
from datetime import datetime
from models.approver_assignment import ApproverAssignment


class ApproverAssignmentCreate(BaseModel):
    user_id: str
    dataset_pattern: str


class ApproverAssignmentResponse(BaseModel):
    id: str
    user_id: str
    tenant_id: str
    dataset_pattern: str
    created_at: datetime

    class Config:
        orm_mode = True