from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from api.dependencies.current_user import get_current_active_user
from core.approval.approval_service import ApprovalService
from core.approval.exceptions import ApprovalNotFoundError
from db.session import get_async_session
from .schemas_request import ApprovalRequestResponse

router = APIRouter(prefix="/approvals", tags=["Approvals"])


@router.get("/queue", response_model=List[ApprovalRequestResponse])
async def get_my_pending_approvals(
    db: AsyncSession = Depends(get_async_session),
    user = Depends(get_current_active_user),
):
    requests = await ApprovalService.get_pending_requests_for_user(
        db, user_id=str(user.id), tenant_id=user.tenant_id
    )
    return [ApprovalRequestResponse.from_orm(r) for r in requests]


@router.get("/{request_id}", response_model=ApprovalRequestResponse)
async def get_approval_request(
    request_id: str,
    db: AsyncSession = Depends(get_async_session),
    user = Depends(get_current_active_user),
):
    try:
        request = await ApprovalService.get_request_by_id(db, request_id)
        if request.tenant_id != user.tenant_id:
            raise HTTPException(status_code=403, detail="Forbidden")
        return ApprovalRequestResponse.from_orm(request)
    except ApprovalNotFoundError:
        raise HTTPException(status_code=404, detail="Approval request not found")