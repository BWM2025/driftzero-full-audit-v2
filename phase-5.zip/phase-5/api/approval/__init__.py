from __future__ import annotations

# Re-export routers for inclusion in main app
from .router_requests import router as requests_router
from .router_decisions import router as decisions_router
from .router_assignments import router as assignments_router

__all__ = [
    "requests_router",
    "decisions_router",
    "assignments_router",
]