from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from models.approver_assignment import ApproverAssignment
from db.session import get_async_session
from api.dependencies.current_user import get_current_active_user
from api.dependencies.auth import require_roles
from .schemas_assignment import ApproverAssignmentCreate, ApproverAssignmentResponse

router = APIRouter(prefix="/approver-assignments", tags=["Approver Assignments"])


@router.post("/", response_model=ApproverAssignmentResponse, status_code=status.HTTP_201_CREATED)
async def create_assignment(
    payload: ApproverAssignmentCreate,
    db: AsyncSession = Depends(get_async_session),
    user = Depends(require_roles(["admin"])),
):
    assignment = ApproverAssignment(
        user_id=payload.user_id,
        tenant_id=user.tenant_id,
        dataset_pattern=payload.dataset_pattern,
    )
    db.add(assignment)
    await db.commit()
    await db.refresh(assignment)
    return ApproverAssignmentResponse.from_orm(assignment)


@router.get("/", response_model=List[ApproverAssignmentResponse])
async def list_assignments(
    db: AsyncSession = Depends(get_async_session),
    user = Depends(require_roles(["admin"])),
):
    assignments = await ApproverAssignmentRepository.get_all_assignments(db, user.tenant_id)
    return [ApproverAssignmentResponse.from_orm(a) for a in assignments]