from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from api.dependencies.current_user import get_current_active_user
from core.tenancy.tenant_service import TenantService
from core.tenancy.exceptions import ConflictError
from db.session import get_async_session

router = APIRouter(prefix="/tenants", tags=["Tenancy"])

@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_tenant(
    payload: dict,
    db: AsyncSession = Depends(get_async_session),
    user = Depends(get_current_active_user),
):
    if "admin" not in user.roles:
        raise HTTPException(status_code=403)
    try:
        tenant = await TenantService.create_tenant(db, payload["name"], payload["slug"])
        return {"id": str(tenant.id), "name": tenant.name, "slug": tenant.slug}
    except ConflictError:
        raise HTTPException(status_code=409, detail="Slug already exists")