from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from models.team import Team
from models.team_membership import TeamMembership


class TeamCreate(BaseModel):
    name: str = Field(..., max_length=255)
    description: Optional[str] = None


class TeamMemberAdd(BaseModel):
    user_id: str
    roles: List[str] = Field(default=["member"])


class TeamResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    description: Optional[str]
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        orm_mode = True