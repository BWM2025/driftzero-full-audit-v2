from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from models.project import Project


class ProjectCreate(BaseModel):
    name: str = Field(..., max_length=255)
    slug: str = Field(..., max_length=100)
    description: Optional[str] = None


class ProjectResponse(BaseModel):
    id: str
    tenant_id: str
    name: str
    slug: str
    description: Optional[str]
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        orm_mode = True