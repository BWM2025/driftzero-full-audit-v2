from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from api.dependencies.current_user import get_current_active_user
from core.tenancy.project_service import ProjectService
from core.tenancy.exceptions import ConflictError
from db.session import get_async_session

router = APIRouter(prefix="/projects", tags=["Projects"])

@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_project(
    payload: dict,
    db: AsyncSession = Depends(get_async_session),
    user = Depends(get_current_active_user),
):
    try:
        project = await ProjectService.create_project(
            db,
            tenant_id=user.tenant_id,
            name=payload["name"],
            slug=payload["slug"],
            description=payload.get("description"),
        )
        return {"id": str(project.id), "name": project.name, "slug": project.slug}
    except ConflictError:
        raise HTTPException(status_code=409, detail="Project slug already exists in tenant")