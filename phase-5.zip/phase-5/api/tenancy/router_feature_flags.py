from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies.current_user import get_current_active_user
from core.tenancy.feature_flag_service import FeatureFlagService
from db.session import get_async_session

router = APIRouter(prefix="/feature-flags", tags=["Feature Flags"])

@router.get("/{key}")
async def get_flag(
    key: str,
    project_id: str | None = None,
    db: AsyncSession = Depends(get_async_session),
    user = Depends(get_current_active_user),
):
    value = await FeatureFlagService.get_effective_flag(
        db, tenant_id=user.tenant_id, flag_key=key, project_id=project_id
    )
    return {"key": key, "value": value}