from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime
from models.tenant import Tenant


class TenantCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    slug: str = Field(..., min_length=1, max_length=100)
    is_active: bool = True


class TenantUpdate(BaseModel):
    is_active: bool


class TenantResponse(BaseModel):
    id: str
    name: str
    slug: str
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        orm_mode = True