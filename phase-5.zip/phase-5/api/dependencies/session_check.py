from fastapi import Depends, HTTPException, status
from core.auth.session_validator import SessionValidator
from core.auth.auth_exceptions import SessionInvalidError, TokenExpiredError
from sqlalchemy.ext.asyncio import AsyncSession
from db.session import get_async_session


async def require_valid_session(
    refresh_token: str = Depends(lambda x: x.headers.get("Authorization", "").replace("Bearer ", "")),
    tenant_id: str = Depends(get_tenant_context),
    db: AsyncSession = Depends(get_async_session),
):
    if not refresh_token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Refresh token required")
    try:
        await SessionValidator.validate_refresh_session(db, None, tenant_id, refresh_token)
        return refresh_token
    except (SessionInvalidError, TokenExpiredError):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or revoked session")