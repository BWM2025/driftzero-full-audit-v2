from fastapi import Header, HTTPException, status


def get_tenant_context(tenant_id: str = Header(..., alias="X-Tenant-ID")) -> str:
    if not tenant_id or len(tenant_id) > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Valid X-Tenant-ID header required",
        )
    return tenant_id