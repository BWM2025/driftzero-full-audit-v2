from __future__ import annotations

from typing import Dict, Set
from uuid import UUID
import json
from core.websocket.broadcaster import Broadcaster
from api.websocket.connection import WebSocketConnection
from core.auth.token_service import TokenService
from core.auth.auth_exceptions import TokenExpiredError, InvalidTokenError


class WebSocketManager:
    def __init__(self):
        self.active_connections: Dict[UUID, WebSocketConnection] = {}
        self.broadcaster = Broadcaster()

    async def connect(self, websocket, token: str, tenant_id: str):
        try:
            payload = TokenService.decode_access(token)
            if payload["tenant_id"] != tenant_id:
                await websocket.close(code=1008, reason="Tenant mismatch")
                return None
        except (TokenExpiredError, InvalidTokenError):
            await websocket.close(code=1008, reason="Invalid or expired token")
            return None

        conn = WebSocketConnection(
            websocket=websocket,
            user_id=payload["user_id"],
            tenant_id=tenant_id,
            roles=payload["roles"],
        )
        self.active_connections[conn.connection_id] = conn
        await self.broadcaster.subscribe(tenant_id, conn)
        return conn

    def disconnect(self, conn: WebSocketConnection):
        self.broadcaster.unsubscribe(conn.tenant_id, conn)
        self.active_connections.pop(conn.connection_id, None)

    async def broadcast_to_tenant(self, tenant_id: str, event: Dict):
        await self.broadcaster.publish(tenant_id, event)