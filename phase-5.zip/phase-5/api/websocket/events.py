from __future__ import annotations

from enum import Enum
from pydantic import BaseModel
from datetime import datetime


class WebSocketEventType(str, Enum):
    INCIDENT_CREATED = "incident.created"
    INCIDENT_UPDATED = "incident.updated"
    SAGA_CREATED = "saga.created"
    SAGA_UPDATED = "saga.updated"
    APPROVAL_REQUIRED = "approval.required"
    APPROVAL_DECIDED = "approval.decided"
    QUARANTINE_TRIGGERED = "quarantine.triggered"
    PATCH_APPLIED = "patch.applied"


class WebSocketEvent(BaseModel):
    type: WebSocketEventType
    timestamp: datetime = None
    tenant_id: str
    payload: dict

    def __init__(self, **data):
        if "timestamp" not in data:
            data["timestamp"] = datetime.utcnow()
        super().__init__(**data)