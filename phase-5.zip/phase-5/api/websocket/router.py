from fastapi import APIRouter, Depends, WebSocket, WebSocketDisconnect
from api.websocket.manager import WebSocketManager
from api.websocket.auth import authenticate_websocket

router = APIRouter()
manager = WebSocketManager()


@router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    token: str = None,
    tenant_id: str = None,
):
    await websocket.accept()
    conn = await manager.connect(websocket, token, tenant_id)
    if not conn:
        return

    try:
        while True:
            data = await websocket.receive_text()
            await websocket.send_text(f"Echo: {data}")
    except WebSocketDisconnect:
        manager.disconnect(conn)