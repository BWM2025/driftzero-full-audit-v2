from __future__ import annotations

from uuid import uuid4, UUID
from fastapi import WebSocket
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class WebSocketConnection:
    websocket: WebSocket
    user_id: str
    tenant_id: str
    roles: List[str]
    connection_id: UUID = None

    def __post_init__(self):
        if self.connection_id is None:
            self.connection_id = uuid4()

    async def send_json(self, data: dict):
        await self.websocket.send_json(data)

    async def close(self, code: int = 1000):
        await self.websocket.close(code=code)