from fastapi import WebSocket, Header, Query, HTTPException, status
from core.auth.token_service import TokenService
from core.auth.auth_exceptions import TokenExpiredError, InvalidTokenError


async def authenticate_websocket(
    websocket: WebSocket,
    token: str = Query(...),
    tenant_id: str = Query(...),
):
    try:
        payload = TokenService.decode_access(token)
        if payload["tenant_id"] != tenant_id:
            await websocket.close(code=1008, reason="Tenant mismatch")
            return
        websocket.state.user = payload
        websocket.state.tenant_id = tenant_id
    except (TokenExpiredError, InvalidTokenError):
        await websocket.close(code=1008, reason="Invalid token")
        return