from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies.auth import rate_limit_login
from api.dependencies.current_user import get_current_active_user
from api.dependencies.tenant_context import get_tenant_context
from api.dependencies.session_check import require_valid_session
from core.auth.auth_service import AuthService
from core.auth.auth_exceptions import (
    InvalidCredentialsError,
    AccountLockedError,
    AccountInactiveError,
)
from db.session import get_async_session

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/login", status_code=status.HTTP_200_OK)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    tenant_id: str = Depends(get_tenant_context),
    db: AsyncSession = Depends(get_async_session),
    _: None = Depends(rate_limit_login),  # 5/min per IP
):
    try:
        result = await AuthService.login(
            db,
            identifier=form_data.username,
            password=form_data.password,
            tenant_id=tenant_id,
        )
        return result
    except (InvalidCredentialsError, AccountLockedError, AccountInactiveError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials or account issue",
            headers={"WWW-Authenticate": "Bearer"},
        )


@router.post("/refresh", status_code=status.HTTP_200_OK)
async def refresh_token(
    tenant_id: str = Depends(get_tenant_context),
    refresh_token: str = Depends(require_valid_session),
    db: AsyncSession = Depends(get_async_session),
):
    result = await AuthService.refresh_token(db, tenant_id, refresh_token)
    return result


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(
    user=Depends(get_current_active_user),
    refresh_token: str = Depends(require_valid_session),
    db: AsyncSession = Depends(get_async_session),
):
    await AuthService.logout(db, str(user.id), user.tenant_id, refresh_token)
    return None


@router.get("/me", status_code=status.HTTP_200_OK)
async def read_users_me(current_user=Depends(get_current_active_user)):
    return {
        "id": str(current_user.id),
        "username": current_user.username,
        "email": current_user.email,
        "roles": current_user.roles,
        "tenant_id": current_user.tenant_id,
    }