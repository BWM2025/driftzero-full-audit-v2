from __future__ import annotations

from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.approver_assignment import ApproverAssignment
import fnmatch


class ApproverAssignmentRepository:
    @staticmethod
    async def get_approvers_for_dataset(
        db: AsyncSession, tenant_id: str, dataset_id: str
    ) -> List[ApproverAssignment]:
        result = await db.execute(select(ApproverAssignment).where(ApproverAssignment.tenant_id == tenant_id))
        assignments = result.scalars().all()
        return [a for a in assignments if fnmatch.fnmatch(dataset_id, a.dataset_pattern)]

    @staticmethod
    async def get_all_assignments(db: AsyncSession, tenant_id: str) -> List[ApproverAssignment]:
        result = await db.execute(select(ApproverAssignment).where(ApproverAssignment.tenant_id == tenant_id))
        return result.scalars().all()