from __future__ import annotations

from sqlalchemy import Column, JSON, DateTime, func, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from db.base import Base


class ProjectSettings(Base):
    __tablename__ = "project_settings"

    project_id = Column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"), primary_key=True)
    settings = Column(JSON, nullable=False, default=dict)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __repr__(self) -> str:
        return f"<ProjectSettings project={self.project_id}>"