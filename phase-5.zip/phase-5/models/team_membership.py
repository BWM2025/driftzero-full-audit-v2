from __future__ import annotations

from sqlalchemy import Column, String, Boolean, DateTime, func, ForeignKey, UniqueConstraint, Index
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from uuid import uuid4
from db.base import Base


class TeamMembership(Base):
    __tablename__ = "team_memberships"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    team_id = Column(UUID(as_uuid=True), ForeignKey("teams.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    roles = Column(ARRAY(String), nullable=False, default=["member"])
    is_active = Column(Boolean, nullable=False, default=True)
    invited_at = Column(DateTime(timezone=True), server_default=func.now())
    joined_at = Column(DateTime(timezone=True), nullable=True)
    left_at = Column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        UniqueConstraint("team_id", "user_id", name="uq_team_user"),
        Index("ix_memberships_team_active", "team_id", "is_active"),
        Index("ix_memberships_user", "user_id"),
    )

    def __repr__(self) -> str:
        return f"<TeamMembership user={self.user_id} team={self.team_id} roles={self.roles}>"