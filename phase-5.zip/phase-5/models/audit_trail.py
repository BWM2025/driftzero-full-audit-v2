from __future__ import annotations

from uuid import uuid4
from sqlalchemy import Column, String, Text, DateTime, func, ForeignKey, Index
from sqlalchemy.dialects.postgresql import UUID, JSON
from db.base import Base


class AuditTrail(Base):
    __tablename__ = "audit_trail"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="SET NULL"), nullable=True, index=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    entity_type = Column(String(100), nullable=False, index=True)
    entity_id = Column(UUID(as_uuid=True), nullable=False)
    action = Column(String(100), nullable=False)
    old_values = Column(JSON, nullable=True)
    new_values = Column(JSON, nullable=True)
    event_metadata = Column(JSON, nullable=True)
    occurred_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    __table_args__ = (
        Index("ix_audit_trail_entity", "entity_type", "entity_id"),
        Index("ix_audit_trail_user_action", "user_id", "action"),
    )

    def __repr__(self) -> str:
        return f"<AuditTrail {self.action} on {self.entity_type}:{self.entity_id} by {self.user_id}>"