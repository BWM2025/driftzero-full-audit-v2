from __future__ import annotations

from sqlalchemy import Column, DateTime, String, ForeignKey, func, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from db.base import Base


class ApprovalDecision(Base):
    __tablename__ = "approval_decisions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=func.gen_random_uuid())
    approval_request_id = Column(UUID(as_uuid=True), ForeignKey("approval_requests.id", ondelete="CASCADE"), nullable=False)
    approver_user_id = Column(String, nullable=False)
    decision = Column(String(50), nullable=False)  # approved / rejected
    comment = Column(Text, nullable=True)
    decided_at = Column(DateTime(timezone=True), server_default=func.now())

    request = relationship("ApprovalRequest", back_populates="decisions")