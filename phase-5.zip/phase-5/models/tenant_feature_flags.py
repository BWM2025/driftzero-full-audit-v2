from __future__ import annotations

from sqlalchemy import Column, String, Boolean, JSON, DateTime, func, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from db.base import Base


class TenantFeatureFlag(Base):
    __tablename__ = "tenant_feature_flags"

    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), primary_key=True)
    flag_key = Column(String(100), primary_key=True)
    enabled = Column(Boolean, nullable=False, default=False)
    override_value = Column(JSON, nullable=True)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def __repr__(self) -> str:
        return f"<TenantFeatureFlag {self.flag_key}={self.enabled} for tenant {self.tenant_id}>"