from __future__ import annotations

from sqlalchemy import Column, String, DateTime, ForeignKey, Text, func
from sqlalchemy.dialects.postgresql import UUID
from uuid import uuid4
from datetime import datetime
from db.base import Base


class Session(Base):
    __tablename__ = "sessions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    tenant_id = Column(String, nullable=False, index=True)
    refresh_token = Column(Text, nullable=False, unique=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True), nullable=False)
    last_accessed = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    def is_expired(self) -> bool:
        return func.now() > self.expires_at

    @classmethod
    def create(cls, user_id: str, tenant_id: str, refresh_token: str, expires_at: datetime) -> "Session":
        return cls(
            user_id=user_id,
            tenant_id=tenant_id,
            refresh_token=refresh_token,
            expires_at=expires_at,
        )