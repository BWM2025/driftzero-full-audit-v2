from __future__ import annotations

from sqlalchemy import Column, String, Boolean, DateTime, func, ForeignKey, Index
from sqlalchemy.dialects.postgresql import UUID
from uuid import uuid4
from db.base import Base


class Team(Base):
    __tablename__ = "teams"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    tenant_id = Column(UUID(as_uuid=True), ForeignKey("tenants.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(String(1024), nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index("ix_teams_tenant_active", "tenant_id", "is_active"),
    )

    def __repr__(self) -> str:
        return f"<Team {self.name} in tenant {self.tenant_id}>"