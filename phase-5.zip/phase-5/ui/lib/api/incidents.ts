import { getAuthHeaders } from "@/lib/auth";

export async function getIncidents() {
  const headers = getAuthHeaders();
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/drift-incidents`, {
    headers,
    credentials: "include",
  });

  if (!res.ok) throw new Error("Failed to fetch incidents");
  return res.json();
}