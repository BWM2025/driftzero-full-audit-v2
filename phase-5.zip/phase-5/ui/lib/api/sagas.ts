import { getAuthHeaders } from "@/lib/auth";

export async function getSagas() {
  const headers = getAuthHeaders();
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/sagas`, {
    headers,
    credentials: "include",
  });
  if (!res.ok) throw new Error("Failed to fetch sagas");
  return res.json();
}

export async function getSaga(sagaId: string) {
  const headers = getAuthHeaders();
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/sagas/${sagaId}`, {
    headers,
    credentials: "include",
  });
  if (!res.ok) return null;
  return res.json();
}