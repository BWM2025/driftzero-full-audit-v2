import { getAuthHeaders } from "@/lib/auth";

export async function getMyApprovals() {
  const headers = getAuthHeaders();
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/approvals/queue`, {
    headers,
    credentials: "include",
  });
  if (!res.ok) throw new Error("Failed to fetch approvals");
  return res.json();
}

export async function getApprovalRequest(requestId: string) {
  const headers = getAuthHeaders();
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/approvals/${requestId}`, {
    headers,
    credentials: "include",
  });
  if (!res.ok) return null;
  return res.json();
}

export async function submitDecision(requestId: string, decision: string, comment?: string) {
  const headers = getAuthHeaders();
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/approvals/${requestId}/decide`, {
    method: "POST",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify({ decision, comment }),
    credentials: "include",
  });
  if (!res.ok) throw new Error("Failed to submit decision");
}