import { cookies } from "next/headers";

const TOKEN_COOKIE = "dz_access_token";
const REFRESH_COOKIE = "dz_refresh_token";
const TENANT_COOKIE = "dz_tenant_id";

export function setAuthTokens(access: string, refresh: string, tenant_id: string) {
  const cookieStore = cookies();
  cookieStore.set(TOKEN_COOKIE, access, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: 3600,
  });
  cookieStore.set(REFRESH_COOKIE, refresh, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
  cookieStore.set(TENANT_COOKIE, tenant_id, {
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
  });
}

export function getAuthHeaders() {
  const cookieStore = cookies();
  const token = cookieStore.get(TOKEN_COOKIE)?.value;
  const tenant = cookieStore.get(TENANT_COOKIE)?.value;

  return token && tenant
    ? { Authorization: `Bearer ${token}`, "X-Tenant-ID": tenant }
    : {};
}

export function clearAuthTokens() {
  const cookieStore = cookies();
  cookieStore.delete(TOKEN_COOKIE);
  cookieStore.delete(REFRESH_COOKIE);
  cookieStore.delete(TENANT_COOKIE);
}