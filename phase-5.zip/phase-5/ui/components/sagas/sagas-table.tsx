"use client";

import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getSagas } from "@/lib/api/sagas";
import { Table, TableBody, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { SagaStatusBadge } from "./saga-status-badge";
import Link from "next/link";

export function SagasTable() {
  const queryClient = useQueryClient();
  const { data: sagas = [], isLoading } = useQuery({
    queryKey: ["sagas"],
    queryFn: getSagas,
  });

  useWebSocket((event) => {
    if (event.type === "saga.created" || event.type === "saga.updated") {
      queryClient.setQueryData(["sagas"], (old: any) => {
        if (!old) return [event.payload];
        const exists = old.some((s: any) => s.id === event.payload.id);
        if (exists) {
          return old.map((s: any) => (s.id === event.payload.id ? event.payload : s));
        }
        return [event.payload, ...old];
      });
    }
  });

  if (isLoading) return <div className="text-center py-12">Loading sagas...</div>;

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Dataset</TableHead>
            <TableHead>Environment</TableHead>
            <TableHead>Started</TableHead>
            <TableHead>Current Step</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sagas.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                No active sagas
              </TableCell>
            </TableRow>
          ) : (
            sagas.map((saga: any) => (
              <TableRow key={saga.id}>
                <TableCell>
                  <Link href={`/sagas/${saga.id}`} className="font-medium hover:underline">
                    {saga.id.slice(0, 8)}
                  </Link>
                </TableCell>
                <TableCell>
                  <SagaStatusBadge status={saga.status} />
                </TableCell>
                <TableCell>{saga.dataset_id}</TableCell>
                <TableCell>{saga.environment_id}</TableCell>
                <TableCell>{new Date(saga.created_at).toLocaleString()}</TableCell>
                <TableCell>{saga.current_step || "—"}</TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}