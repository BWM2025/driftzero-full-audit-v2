import { Badge } from "@/components/ui/badge";

interface SagaStepBadgeProps {
  status: string;
}

export function SagaStepBadge({ status }: SagaStepBadgeProps) {
  const variant: Record<string, any> = {
    RUNNING: "default",
    FAILED: "destructive",
    WAITING: "secondary",
    COMPLETED: "outline",
  };

  return (
    <Badge variant={variant[status] || "secondary"} className="text-xs">
      {status}
    </Badge>
  );
}