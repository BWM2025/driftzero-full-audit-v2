import { Badge } from "@/components/ui/badge";

interface SagaStatusBadgeProps {
  status: string;
}

export function SagaStatusBadge({ status }: SagaStatusBadgeProps) {
  const config: Record<string, { variant: any; label: string }> = {
    RUNNING: { variant: "default", label: "Running" },
    COMPLETED: { variant: "outline", label: "Completed" },
    FAILED: { variant: "destructive", label: "Failed" },
    COMPENSATED: { variant: "secondary", label: "Compensated" },
    CANCELLED: { variant: "secondary", label: "Cancelled" },
  };

  const { variant, label } = config[status] || { variant: "secondary", label: status };

  return <Badge variant={variant}>{label}</Badge>;
}