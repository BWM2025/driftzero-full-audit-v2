import { Timeline, TimelineItem } from "@/components/ui/timeline";
import { SagaStepBadge } from "./saga-step-badge";
import { CheckCircle2, Circle, AlertCircle } from "lucide-react";

interface SagaTimelineProps {
  saga: any;
}

const stepOrder = [
  "DETECT_DRIFT",
  "CLASSIFY_INCIDENTS",
  "EVALUATE_POLICY",
  "AWAIT_APPROVAL",
  "GENERATE_PATCH",
  "EXECUTE_SANDBOX",
  "EXECUTE_CANARY",
  "COMMIT_PATCH",
  "FINALIZE",
];

export function SagaTimeline({ saga }: SagaTimelineProps) {
  const currentStepIndex = stepOrder.indexOf(saga.current_step || "");
  const completedSteps = saga.completed_steps || [];

  return (
    <Timeline>
      {stepOrder.map((step, index) => {
        const isCompleted = completedSteps.includes(step);
        const isCurrent = index === currentStepIndex;
        const isPending = index > currentStepIndex && currentStepIndex >= 0;

        return (
          <TimelineItem
            key={step}
            status={isCompleted ? "completed" : isCurrent ? "current" : isPending ? "pending" : "upcoming"}
          >
            <div className="flex items-center gap-4">
              {isCompleted ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-500" />
              ) : isCurrent ? (
                <Circle className="h-5 w-5 text-primary animate-pulse" />
              ) : (
                <Circle className="h-5 w-5 text-muted-foreground" />
              )}
              <div>
                <p className="font-medium">{step.replace(/_/g, " ")}</p>
                {isCurrent && <SagaStepBadge status={saga.status} />}
              </div>
            </div>
          </TimelineItem>
        );
      })}
    </Timeline>
  );
}