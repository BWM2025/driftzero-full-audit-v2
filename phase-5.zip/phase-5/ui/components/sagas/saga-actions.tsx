"use client";

import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useAuth } from "@/hooks/use-auth";
import { MoreHorizontal, RotateCcw, XCircle } from "lucide-react";

interface SagaActionsProps {
  saga: any;
}

export function SagaActions({ saga }: SagaActionsProps) {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes("admin");

  if (!isAdmin) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem>
          <RotateCcw className="mr-2 h-4 w-4" />
          Retry Failed Step
        </DropdownMenuItem>
        <DropdownMenuItem className="text-destructive">
          <XCircle className="mr-2 h-4 w-4" />
          Cancel Saga
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}