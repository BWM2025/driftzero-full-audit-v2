"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { AlertTriangle, GitBranch, CheckSquare, ShieldAlert, Building2, Settings } from "lucide-react";

const icons = {
  "alert-triangle": AlertTriangle,
  "git-branch": GitBranch,
  "check-square": CheckSquare,
  "shield-alert": ShieldAlert,
  "building-2": Building2,
  settings: Settings,
};

interface NavItemProps {
  href: string;
  label: string;
  icon: keyof typeof icons;
  collapsed: boolean;
  admin?: boolean;
}

export function NavItem({ href, label, icon: iconName, collapsed }: NavItemProps) {
  const pathname = usePathname();
  const Icon = icons[iconName];
  const isActive = pathname.startsWith(href);

  return (
    <Button
      asChild
      variant={isActive ? "secondary" : "ghost"}
      className={cn("w-full justify-start", collapsed && "px-2")}
    >
      <Link href={href}>
        <Icon className={cn("h-4 w-4", !collapsed && "mr-3")} />
        {!collapsed && <span>{label}</span>}
      </Link>
    </Button>
  );
}