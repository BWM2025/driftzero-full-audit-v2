"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "react-hot-toast";
import { submitDecision } from "@/lib/api/approvals";

interface DecisionDialogProps {
  request: any;
}

export function DecisionDialog({ request }: DecisionDialogProps) {
  const [open, setOpen] = useState(false);
  const [decision, setDecision] = useState<"approved" | "rejected">("approved");
  const [comment, setComment] = useState("");

  const handleSubmit = async () => {
    try {
      await submitDecision(request.id, decision, comment);
      toast.success(`Request ${decision}!`);
      setOpen(false);
    } catch {
      toast.error("Failed to submit decision");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="w-full">Submit Decision</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Submit Approval Decision</DialogTitle>
          <DialogDescription>
            This action cannot be undone. Your decision will be recorded.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-4">
          <div className="flex gap-4">
            <Button
              variant={decision === "approved" ? "default" : "outline"}
              onClick={() => setDecision("approved")}
              className="flex-1"
            >
              Approve
            </Button>
            <Button
              variant={decision === "rejected" ? "destructive" : "outline"}
              onClick={() => setDecision("rejected")}
              className="flex-1"
            >
              Reject
            </Button>
          </div>
          <Textarea
            placeholder="Optional comment..."
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
          <Button onClick={handleSubmit} className="w-full">
            Confirm Decision
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}