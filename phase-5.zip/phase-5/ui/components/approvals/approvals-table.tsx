"use client";

import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getMyApprovals } from "@/lib/api/approvals";
import { Table, TableBody, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ApprovalRow } from "./approval-row";
import Link from "next/link";

export function ApprovalsTable() {
  const queryClient = useQueryClient();
  const { data: requests = [], isLoading } = useQuery({
    queryKey: ["my-approvals"],
    queryFn: getMyApprovals,
  });

  useWebSocket((event) => {
    if (event.type === "approval.required" || event.type === "approval.decided") {
      queryClient.invalidateQueries({ queryKey: ["my-approvals"] });
    }
  });

  if (isLoading) return <div className="text-center py-12">Loading approvals...</div>;

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Status</TableHead>
            <TableHead>Dataset</TableHead>
            <TableHead>Environment</TableHead>
            <TableHead>Required</TableHead>
            <TableHead>Expires</TableHead>
            <TableHead>Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {requests.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                No pending approvals
              </TableCell>
            </TableRow>
          ) : (
            requests.map((request: any) => (
              <ApprovalRow key={request.id} request={request} />
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}