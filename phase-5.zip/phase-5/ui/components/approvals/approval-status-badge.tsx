import { Badge } from "@/components/ui/badge";

interface ApprovalStatusBadgeProps {
  status: string;
}

export function ApprovalStatusBadge({ status }: ApprovalStatusBadgeProps) {
  const config: Record<string, { variant: any; label: string }> = {
    PENDING: { variant: "secondary", label: "Pending" },
    APPROVED: { variant: "default", label: "Approved" },
    REJECTED: { variant: "destructive", label: "Rejected" },
    EXPIRED: { variant: "outline", label: "Expired" },
  };

  const { variant, label } = config[status] || { variant: "secondary", label: status };

  return <Badge variant={variant}>{label}</Badge>;
}