import { Timeline, TimelineItem } from "@/components/ui/timeline";
import { CheckCircle2, XCircle, Clock } from "lucide-react";
import { format } from "date-fns";

interface ApprovalTimelineProps {
  decisions: any[];
}

export function ApprovalTimeline({ decisions }: ApprovalTimelineProps) {
  if (decisions.length === 0) {
    return <p className="text-muted-foreground text-center py-8">No decisions yet</p>;
  }

  return (
    <Timeline>
      {decisions.map((d: any) => (
        <TimelineItem
          key={d.id}
          status={d.decision === "approved" ? "completed" : "failed"}
        >
          <div className="flex items-center gap-3">
            {d.decision === "approved" ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            ) : (
              <XCircle className="h-5 w-5 text-destructive" />
            )}
            <div>
              <p className="font-medium">{d.approver_user_id}</p>
              <p className="text-sm text-muted-foreground">
                {d.decision} • {format(new Date(d.decided_at), "PPp")}
              </p>
              {d.comment && <p className="text-sm mt-1">{d.comment}</p>}
            </div>
          </div>
        </TimelineItem>
      ))}
    </Timeline>
  );
}