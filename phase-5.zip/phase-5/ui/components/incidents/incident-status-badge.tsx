import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface IncidentStatusBadgeProps {
  status: string;
}

export function IncidentStatusBadge({ status }: IncidentStatusBadgeProps) {
  const variants: Record<string, string> = {
    OPEN: "destructive",
    INVESTIGATING: "secondary",
    QUARANTINED: "outline",
    RESOLVED: "default",
  };

  return (
    <Badge variant={variants[status] || "secondary"} className="capitalize">
      {status.toLowerCase()}
    </Badge>
  );
}