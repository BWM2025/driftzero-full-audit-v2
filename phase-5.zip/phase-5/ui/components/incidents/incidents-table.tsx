"use client";

import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getIncidents } from "@/lib/api/incidents";
import { Table, TableBody, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TableToolbar } from "./table-toolbar";
import { IncidentRow } from "./incident-row";
import { useWebSocket } from "@/hooks/use-websocket";

export function IncidentsTable() {
  const queryClient = useQueryClient();
  const { data: incidents = [], isLoading } = useQuery({
    queryKey: ["incidents"],
    queryFn: getIncidents,
  });

  useWebSocket((event) => {
    if (event.type === "incident.created" || event.type === "incident.updated") {
      queryClient.setQueryData(["incidents"], (old: any) => {
        if (!old) return [event.payload];
        const exists = old.some((i: any) => i.id === event.payload.id);
        if (exists) {
          return old.map((i: any) => (i.id === event.payload.id ? event.payload : i));
        }
        return [event.payload, ...old];
      });
    }
  });

  if (isLoading) {
    return <div className="text-center py-12">Loading incidents...</div>;
  }

  return (
    <div className="space-y-4">
      <TableToolbar />
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Status</TableHead>
              <TableHead>Priority</TableHead>
              <TableHead>Dataset</TableHead>
              <TableHead>Environment</TableHead>
              <TableHead>Detected</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {incidents.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                  No active incidents
                </TableCell>
              </TableRow>
            ) : (
              incidents.map((incident: any) => (
                <IncidentRow key={incident.id} incident={incident} />
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}