import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Eye, Shield, CheckCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

interface IncidentRowActionsProps {
  incident: any;
}

export function IncidentRowActions({ incident }: IncidentRowActionsProps) {
  const { user } = useAuth();

  const canResolve = user?.roles.includes("operator") || user?.roles.includes("admin");
  const canQuarantine = user?.roles.includes("admin");

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem>
          <Eye className="mr-2 h-4 w-4" />
          View Details
        </DropdownMenuItem>
        {canQuarantine && (
          <DropdownMenuItem className="text-destructive">
            <Shield className="mr-2 h-4 w-4" />
            Quarantine
          </DropdownMenuItem>
        )}
        {canResolve && (
          <DropdownMenuItem className="text-emerald-600">
            <CheckCircle className="mr-2 h-4 w-4" />
            Mark Resolved
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}