import { TableCell, TableRow } from "@/components/ui/table";
import { IncidentStatusBadge } from "./incident-status-badge";
import { IncidentPriorityBadge } from "./incident-priority-badge";
import { IncidentRowActions } from "./incident-row-actions";
import { formatDistanceToNow } from "date-fns";

interface IncidentRowProps {
  incident: any;
}

export function IncidentRow({ incident }: IncidentRowProps) {
  return (
    <TableRow>
      <TableCell>
        <IncidentStatusBadge status={incident.status} />
      </TableCell>
      <TableCell>
        <IncidentPriorityBadge priority={incident.risk_level} />
      </TableCell>
      <TableCell className="font-medium">{incident.dataset_id}</TableCell>
      <TableCell>{incident.environment_id}</TableCell>
      <TableCell>
        {formatDistanceToNow(new Date(incident.detected_at), { addSuffix: true })}
      </TableCell>
      <TableCell className="capitalize">{incident.drift_type.replace("_", " ")}</TableCell>
      <TableCell className="text-right">
        <IncidentRowActions incident={incident} />
      </TableCell>
    </TableRow>
  );
}