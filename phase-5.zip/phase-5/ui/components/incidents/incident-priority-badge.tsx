import { Badge } from "@/components/ui/badge";

interface IncidentPriorityBadgeProps {
  priority: string;
}

export function IncidentPriorityBadge({ priority }: IncidentPriorityBadgeProps) {
  const colors: Record<string, string> = {
    CRITICAL: "bg-red-500",
    HIGH: "bg-orange-500",
    MEDIUM: "bg-yellow-500",
    LOW: "bg-green-500",
  };

  return (
    <Badge className={cn("text-white", colors[priority] || "bg-gray-500")}>
      {priority}
    </Badge>
  );
}