"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toast } from "react-hot-toast";
import { replayQuarantine } from "@/lib/api/quarantine";
import { Play, AlertTriangle } from "lucide-react";

interface ReplayDialogProps {
  record: any;
}

export function ReplayDialog({ record }: ReplayDialogProps) {
  const [open, setOpen] = useState(false);
  const [dryRun, setDryRun] = useState(true);

  const handleReplay = async () => {
    try {
      await replayQuarantine(record.id, dryRun);
      toast.success(dryRun ? "Dry-run completed" : "Replay started");
      setOpen(false);
    } catch {
      toast.error("Replay failed");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Play className="mr-2 h-4 w-4" />
          Replay Data
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Replay Quarantined Data</DialogTitle>
          <DialogDescription>
            This will reprocess the quarantined records for dataset {record.dataset_id}.
          </DialogDescription>
        </DialogHeader>
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            This action is irreversible and may affect downstream systems.
          </AlertDescription>
        </Alert>
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <input
              type="checkbox"
              id="dryrun"
              checked={dryRun}
              onChange={(e) => setDryRun(e.target.checked)}
            />
            <label htmlFor="dryrun">Dry run (no data written)</label>
          </div>
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleReplay} variant={dryRun ? "default" : "destructive"}>
              {dryRun ? "Run Dry Test" : "Execute Replay"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}