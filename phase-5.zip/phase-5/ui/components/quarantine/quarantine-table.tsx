"use client";

import { useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getQuarantinedRecords } from "@/lib/api/quarantine";
import { QuarantineCard } from "./quarantine-card";

export function QuarantineTable() {
  const queryClient = useQueryClient();
  const { data: records = [], isLoading } = useQuery({
    queryKey: ["quarantine"],
    queryFn: getQuarantinedRecords,
  });

  useWebSocket((event) => {
    if (event.type === "quarantine.triggered") {
      queryClient.invalidateQueries({ queryKey: ["quarantine"] });
    }
  });

  if (isLoading) return <div className="text-center py-12">Loading quarantine...</div>;

  return (
    <div className="space-y-4">
      {records.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          No active quarantined records
        </div>
      ) : (
        records.map((record: any) => (
          <QuarantineCard key={record.id} record={record} />
        ))
      )}
    </div>
  );
}