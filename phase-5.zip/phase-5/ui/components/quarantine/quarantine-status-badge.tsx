import { Badge } from "@/components/ui/badge";

interface QuarantineStatusBadgeProps {
  status: string;
}

export function QuarantineStatusBadge({ status }: QuarantineStatusBadgeProps) {
  const config: Record<string, { variant: any; label: string }> = {
    ACTIVE: { variant: "destructive", label: "Active" },
    REPLAYED: { variant: "default", label: "Replayed" },
    DISCARDED: { variant: "secondary", label: "Discarded" },
  };

  const { variant, label } = config[status] || { variant: "secondary", label: status };

  return <Badge variant={variant}>{label}</Badge>;
}