import { Timeline, TimelineItem } from "@/components/ui/timeline";
import { CheckCircle2, XCircle, Clock } from "lucide-react";
import { format } from "date-fns";

interface ReplayTimelineProps {
  history: any[];
}

export function ReplayTimeline({ history }: ReplayTimelineProps) {
  if (!history || history.length === 0) {
    return <p className="text-muted-foreground text-center py-8">No replay history</p>;
  }

  return (
    <Timeline>
      {history.map((entry: any, i: number) => (
        <TimelineItem
          key={i}
          status={entry.success ? "completed" : "failed"}
        >
          <div className="flex items-center gap-3">
            {entry.success ? (
              <CheckCircle2 className="h-5 w-5 text-emerald-500" />
            ) : (
              <XCircle className="h-5 w-5 text-destructive" />
            )}
            <div>
              <p className="font-medium">
                {entry.dry_run ? "Dry Run" : "Live Replay"}
              </p>
              <p className="text-sm text-muted-foreground">
                {format(new Date(entry.timestamp), "PPp")}
              </p>
              {entry.message && <p className="text-sm mt-1">{entry.message}</p>}
            </div>
          </div>
        </TimelineItem>
      ))}
    </Timeline>
  );
}