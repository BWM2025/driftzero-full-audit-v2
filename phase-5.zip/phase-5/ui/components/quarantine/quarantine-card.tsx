"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { QuarantineStatusBadge } from "./quarantine-status-badge";
import { ReplayDialog } from "./replay-dialog";
import { formatDistanceToNow } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { ShieldAlert, Database, Clock, HardDrive } from "lucide-react";

interface QuarantineCardProps {
  record: any;
}

export function QuarantineCard({ record }: QuarantineCardProps) {
  const { user } = useAuth();
  const isAdmin = user?.roles.includes("admin");

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldAlert className="h-6 w-6 text-destructive" />
            <div>
              <CardTitle>{record.dataset_id}</CardTitle>
              <CardDescription>
                Environment: {record.environment_id} • Saga: {record.drift_saga_id}
              </CardDescription>
            </div>
          </div>
          <QuarantineStatusBadge status={record.status} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="flex items-center gap-2">
            <Database className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Volume</p>
              <p className="font-medium">{record.volume_estimate?.toLocaleString() || "—"} rows</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Expires</p>
              <p className="font-medium">
                {formatDistanceToNow(new Date(record.expires_at), { addSuffix: true })}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <HardDrive className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-xs text-muted-foreground">Location</p>
              <p className="font-mono text-xs">{record.data_location}</p>
            </div>
          </div>
        </div>
        {isAdmin && <ReplayDialog record={record} />}
      </CardContent>
    </Card>
  );
}