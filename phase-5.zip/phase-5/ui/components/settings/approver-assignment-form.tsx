"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createApproverAssignment } from "@/lib/api/approver-assignments";
import { toast } from "react-hot-toast";

export function ApproverAssignmentForm() {
  const [userId, setUserId] = useState("");
  const [pattern, setPattern] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createApproverAssignment(userId, pattern);
      toast.success("Approver assignment created");
      setUserId("");
      setPattern("");
    } catch {
      toast.error("Failed to create assignment");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="rounded-lg border bg-card p-6">
        <h3 className="text-lg font-semibold mb-4">New Approver Assignment</h3>
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="user">User ID</Label>
            <Input
              id="user"
              placeholder="user-uuid-or-email"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="pattern">Dataset Pattern (glob)</Label>
            <Input
              id="pattern"
              placeholder="payments.* or *.prod"
              value={pattern}
              onChange={(e) => setPattern(e.target.value)}
              required
            />
          </div>
        </div>
        <div className="mt-6">
          <Button type="submit">Create Assignment</Button>
        </div>
      </div>
    </form>
  );
}