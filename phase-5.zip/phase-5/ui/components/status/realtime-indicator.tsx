"use client";

import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Activity } from "lucide-react";

export function RealtimeIndicator() {
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const ws = new WebSocket(`wss://${window.location.host}/ws?token=dummy`);

    ws.onopen = () => setConnected(true);
    ws.onclose = () => setConnected(false);
    ws.onerror = () => setConnected(false);

    return () => ws.close();
  }, []);

  return (
    <Badge variant={connected ? "default" : "destructive"} className="gap-1">
      <Activity className={`h-3 w-3 ${connected && "animate-pulse"}`} />
      {connected ? "Live" : "Disconnected"}
    </Badge>
  );
}