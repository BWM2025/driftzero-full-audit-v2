"use client";

import { NavItem } from "@/components/navigation/nav-item";

const navItems = [
  { href: "/incidents", label: "Incidents", icon: "alert-triangle" },
  { href: "/sagas", label: "Sagas", icon: "git-branch" },
  { href: "/approvals", label: "Approvals", icon: "check-square" },
  { href: "/quarantine", label: "Quarantine", icon: "shield-alert" },
  { href: "/tenancy", label: "Tenancy", icon: "building-2", admin: true },
  { href: "/settings", label: "Settings", icon: "settings" },
];

interface MainNavProps {
  collapsed: boolean;
}

export function MainNav({ collapsed }: MainNavProps) {
  return (
    <nav className="flex-1 space-y-1 p-2">
      {navItems.map((item) => (
        <NavItem key={item.href} {...item} collapsed={collapsed} />
      ))}
    </nav>
  );
}