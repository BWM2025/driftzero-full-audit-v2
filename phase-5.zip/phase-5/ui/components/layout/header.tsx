import { Breadcrumb } from "./breadcrumb";
import { UserMenu } from "@/components/navigation/user-menu";
import { RealtimeIndicator } from "@/components/status/realtime-indicator";

export function Header() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background">
      <div className="flex h-14 items-center justify-between px-4">
        <Breadcrumb />
        <div className="flex items-center gap-4">
          <RealtimeIndicator />
          <UserMenu />
        </div>
      </div>
    </header>
  );
}