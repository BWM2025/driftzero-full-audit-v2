"use client";

import { useState } from "react";
import { MainNav } from "./main-nav";
import { MobileNav } from "./mobile-nav";
import { Button } from "@/components/ui/button";
import { PanelLeft, PanelRight } from "lucide-react";

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <>
      <aside
        className={`hidden md:flex flex-col border-r bg-card transition-all duration-300 ${
          collapsed ? "w-16" : "w-64"
        }`}
      >
        <div className="flex h-14 items-center justify-between border-b px-4">
          {!collapsed && <h2 className="text-lg font-semibold">DriftZero</h2>}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCollapsed(!collapsed)}
            className="ml-auto"
          >
            {collapsed ? <PanelRight className="h-4 w-4" /> : <PanelLeft className="h-4 w-4" />}
          </Button>
        </div>
        <MainNav collapsed={collapsed} />
      </aside>
      <MobileNav />
    </>
  );
}