"use client";

import { create } from "zustand";
import { devtools } from "zustand/middleware";

type User = {
  id: string;
  username: string;
  email: string;
  roles: string[];
  tenant_id: string;
};

type AuthState = {
  user: User | null;
  isLoading: boolean;
  login: (credentials: { tenant_id: string; username: string; password: string }) => Promise<void>;
  logout: () => Promise<void>;
  checkSession: () => Promise<User | null>;
};

export const useAuth = create<AuthState>()(
  devtools((set) => ({
    user: null,
    isLoading: true,

    login: async (credentials) => {
      set({ isLoading: true });
      const res = await fetch("/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(credentials),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Login failed");
      }

      const data = await res.json();
      document.cookie = `dz_access_token=${data.access_token}; path=/; secure; samesite=strict`;
      document.cookie = `dz_refresh_token=${data.refresh_token}; path=/; secure; samesite=strict`;
      document.cookie = `dz_tenant_id=${credentials.tenant_id}; path=/`;

      set({ user: data.user, isLoading: false });
    },

    logout: async () => {
      document.cookie = "dz_access_token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
      document.cookie = "dz_refresh_token=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
      document.cookie = "dz_tenant_id=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT";
      set({ user: null });
    },

    checkSession: async () => {
      set({ isLoading: true });
      try {
        const res = await fetch("/auth/me", { credentials: "include" });
        if (res.ok) {
          const user = await res.json();
          set({ user, isLoading: false });
          return user;
        }
      } catch {}
      set({ user: null, isLoading: false });
      return null;
    },
  }))
);