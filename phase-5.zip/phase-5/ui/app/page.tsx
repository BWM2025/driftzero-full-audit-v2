import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-background">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center">DriftZero</CardTitle>
          <CardDescription className="text-center">
            Schema Drift Governance Platform
          </CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Button asChild size="lg" className="gap-2">
            <Link href="/auth/login">
              <LogIn className="w-4 h-4" />
              Sign in to Console
            </Link>
          </Button>
        </CardContent>
      </Card>
    </main>
  );
}