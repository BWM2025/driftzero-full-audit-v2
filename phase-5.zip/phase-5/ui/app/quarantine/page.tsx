import { Suspense } from "react";
import { QuarantineTable } from "@/components/quarantine/quarantine-table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldAlert } from "lucide-react";

export const revalidate = 0;

export default function QuarantinePage() {
  return (
    <>
      <div className="mb-8">
        <div className="flex items-center gap-3">
          <ShieldAlert className="h-8 w-8 text-destructive" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Quarantine</h1>
            <p className="text-muted-foreground">High-risk data held for review</p>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Quarantined Records</CardTitle>
        </CardHeader>
        <CardContent>
          <Suspense fallback={<div className="text-center py-12">Loading quarantine...</div>}>
            <QuarantineTable />
          </Suspense>
        </CardContent>
      </Card>
    </>
  );
}