import { Suspense } from "react";
import { SagasTable } from "@/components/sagas/sagas-table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GitBranch } from "lucide-react";

export const revalidate = 0;

export default function SagasPage() {
  return (
    <>
      <div className="mb-8">
        <div className="flex items-center gap-3">
          <GitBranch className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Sagas</h1>
            <p className="text-muted-foreground">Drift resolution workflows</p>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Active Sagas</CardTitle>
        </CardHeader>
        <CardContent>
          <Suspense fallback={<div className="text-center py-12">Loading sagas...</div>}>
            <SagasTable />
          </Suspense>
        </CardContent>
      </Card>
    </>
  );
}