import { notFound } from "next/navigation";
import { ApprovalCard } from "@/components/approvals/approval-card";
import { ApprovalTimeline } from "@/components/approvals/approval-timeline";
import { getApprovalRequest } from "@/lib/api/approvals";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ApprovalStatusBadge } from "@/components/approvals/approval-status-badge";

interface ApprovalDetailPageProps {
  params: { request_id: string };
}

export default async function ApprovalDetailPage({ params }: ApprovalDetailPageProps) {
  const request = await getApprovalRequest(params.request_id);
  if (!request) notFound();

  return (
    <>
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Approval Request {request.id.slice(0, 8)}
            </h1>
            <p className="text-muted-foreground">
              Saga: {request.saga_id} • Dataset: {request.dataset_id}
            </p>
          </div>
          <ApprovalStatusBadge status={request.status} />
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ApprovalCard request={request} />
        </div>
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Decision Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              <ApprovalTimeline decisions={request.decisions} />
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}