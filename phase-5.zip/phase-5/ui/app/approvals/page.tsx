import { Suspense } from "react";
import { ApprovalsTable } from "@/components/approvals/approvals-table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckSquare } from "lucide-react";

export const revalidate = 0;

export default function ApprovalsPage() {
  return (
    <>
      <div className="mb-8">
        <div className="flex items-center gap-3">
          <CheckSquare className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Approvals</h1>
            <p className="text-muted-foreground">Pending human approval requests</p>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>My Approval Queue</CardTitle>
        </CardHeader>
        <CardContent>
          <Suspense fallback={<div className="text-center py-12">Loading approvals...</div>}>
            <ApprovalsTable />
          </Suspense>
        </CardContent>
      </Card>
    </>
  );
}