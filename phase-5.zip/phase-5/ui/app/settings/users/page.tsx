import { UserTable } from "@/components/settings/user-table";
import { UserForm } from "@/components/settings/user-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function UsersSettingsPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>User Management</CardTitle>
        <CardDescription>Invite users and manage their roles</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <UserForm />
          <UserTable />
        </div>
      </CardContent>
    </Card>
  );
}