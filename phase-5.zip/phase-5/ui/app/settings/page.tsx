import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Settings } from "lucide-react";

export default function SettingsPage() {
  return (
    <>
      <div className="mb-8">
        <div className="flex items-center gap-3">
          <Settings className="h-8 w-8 text-primary" />
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
            <p className="text-muted-foreground">Manage users, roles, and approver assignments</p>
          </div>
        </div>
      </div>

      <Tabs defaultValue="users" className="space-y-6">
        <TabsList>
          <TabsTrigger value="users">Users & Roles</TabsTrigger>
          <TabsTrigger value="approvers">Approver Assignments</TabsTrigger>
        </TabsList>

        <TabsContent value="users">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>Invite users and manage their roles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <UserForm />
                <UserTable />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="approvers">
          <Card>
            <CardHeader>
              <CardTitle>Approver Assignments</CardTitle>
              <CardDescription>
                Assign users to automatically approve changes for specific datasets
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ApproverAssignmentForm />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}