import { ApproverAssignmentForm } from "@/components/settings/approver-assignment-form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function ApproversSettingsPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Approver Assignments</CardTitle>
        <CardDescription>
          Assign users to automatically approve changes for specific dataset patterns
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ApproverAssignmentForm />
      </CardContent>
    </Card>
  );
}