from models.tenant import Tenant
from models.tenant_settings import TenantSettings


def test_tenant_settings_one_to_one(db_session, tenant):
    settings = TenantSettings(
        tenant_id=tenant.id,
        settings={"billing_plan": "enterprise", "mfa_required": True}
    )
    db_session.add(settings)
    db_session.commit()

    assert settings.updated_at is not None
    assert repr(settings) == f"<TenantSettings tenant={tenant.id}>"