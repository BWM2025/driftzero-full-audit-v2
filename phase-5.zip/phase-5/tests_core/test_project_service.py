import pytest
from uuid import uuid4
from sqlalchemy.exc import IntegrityError
from core.tenancy.project_service import ProjectService
from core.tenancy.exceptions import NotFoundError, ConflictError


@pytest.mark.asyncio
async def test_create_project_success(db_session_async, tenant):
    project = await ProjectService.create_project(
        db_session_async,
        tenant_id=tenant.id,
        name="Web App",
        slug="web",
    )
    assert project.name == "Web App"
    assert project.tenant_id == tenant.id


@pytest.mark.asyncio
async def test_create_project_slug_conflict_same_tenant(db_session_async, tenant):
    await ProjectService.create_project(db_session_async, tenant.id, "P1", "dup")
    with pytest.raises(ConflictError, match="Project slug already exists in this tenant"):
        await ProjectService.create_project(db_session_async, tenant.id, "P2", "dup")


@pytest.mark.asyncio
async def test_list_projects_for_tenant_active_only(db_session_async, tenant):
    await ProjectService.create_project(db_session_async, tenant.id, "Active", "active", is_active=True)
    await ProjectService.create_project(db_session_async, tenant.id, "Inactive", "inactive", is_active=False)

    active = await ProjectService.list_projects_for_tenant(db_session_async, tenant.id, active_only=True)
    all_projects = await ProjectService.list_projects_for_tenant(db_session_async, tenant.id, active_only=False)

    assert len(active) == 1
    assert len(all_projects) == 2


@pytest.mark.asyncio
async def test_set_project_active(db_session_async, project):
    updated = await ProjectService.set_project_active(db_session_async, project.id, active=False)
    assert updated.is_active is False

    updated = await ProjectService.set_project_active(db_session_async, project.id, active=True)
    assert updated.is_active is True


@pytest.mark.asyncio
async def test_set_project_active_not_found(db_session_async):
    fake_id = uuid4()
    with pytest.raises(NotFoundError):
        await ProjectService.set_project_active(db_session_async, fake_id, active=False)