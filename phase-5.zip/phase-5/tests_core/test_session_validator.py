import pytest
from datetime import datetime, timedelta
from core.auth.session_validator import SessionValidator
from core.auth.session_store import SessionStore
from core.auth.auth_exceptions import SessionInvalidError, TokenExpiredError
from models.session import Session


@pytest.mark.asyncio
async def test_validate_refresh_session_happy_path(db_session_async, user):
    await SessionStore.create_session(str(user.id), "t1", "valid-refresh")
    expires = datetime.utcnow() + timedelta(days=7)
    session = Session.create(
        user_id=str(user.id),
        tenant_id="t1",
        refresh_token="valid-refresh",
        expires_at=expires,
    )
    db_session_async.add(session)
    await db_session_async.commit()

    result = await SessionValidator.validate_refresh_session(
        db_session_async, str(user.id), "t1", "valid-refresh"
    )
    assert result.refresh_token == "valid-refresh"


@pytest.mark.asyncio
async def test_validate_refresh_session_redis_miss(db_session_async, user):
    with pytest.raises(SessionInvalidError):
        await SessionValidator.validate_refresh_session(
            db_session_async, str(user.id), "t1", "missing-token"
        )


@pytest.mark.asyncio
async def test_validate_refresh_session_expired_in_db(db_session_async, user):
    await SessionStore.create_session(str(user.id), "t1", "exp-refresh")
    past = datetime.utcnow() - timedelta(hours=1)
    session = Session.create(
        user_id=str(user.id),
        tenant_id="t1",
        refresh_token="exp-refresh",
        expires_at=past,
    )
    db_session_async.add(session)
    await db_session_async.commit()

    with pytest.raises(TokenExpiredError):
        await SessionValidator.validate_refresh_session(
            db_session_async, str(user.id), "t1", "exp-refresh"
        )


@pytest.mark.asyncio
async def test_revoke_session_removes_redis_entry(db_session_async, user):
    await SessionStore.create_session(str(user.id), "t1", "revoke-me")
    await SessionValidator.revoke_session(str(user.id))
    exists = await SessionStore.session_exists(str(user.id), "revoke-me")
    assert exists is False