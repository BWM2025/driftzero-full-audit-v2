from models.project import Project
from models.project_settings import ProjectSettings


def test_project_settings_one_to_one(db_session, project):
    settings = ProjectSettings(
        project_id=project.id,
        settings={"auto_heal_enabled": False, "notification_webhook": "https://..."}
    )
    db_session.add(settings)
    db_session.commit()

    assert settings.updated_at is not None
    assert repr(settings) == f"<ProjectSettings project={project.id}>"