import pytest
from core.tenancy.feature_flag_service import FeatureFlagService


@pytest.mark.asyncio
async def test_get_effective_flag_default_only(db_session_async, tenant):
    value = await FeatureFlagService.get_effective_flag(
        db_session_async, tenant.id, "new_ui", default=True
    )
    assert value is True


@pytest.mark.asyncio
async def test_get_effective_flag_tenant_level(db_session_async, tenant):
    await FeatureFlagService.set_tenant_flag(db_session_async, tenant.id, "new_ui", enabled=True)
    value = await FeatureFlagService.get_effective_flag(db_session_async, tenant.id, "new_ui")
    assert value is True

    await FeatureFlagService.set_tenant_flag(db_session_async, tenant.id, "new_ui", enabled=False, override_value={"msg": "disabled"})
    value = await FeatureFlagService.get_effective_flag(db_session_async, tenant.id, "new_ui")
    assert value == {"msg": "disabled"}


@pytest.mark.asyncio
async def test_get_effective_flag_project_override(db_session_async, tenant, project):
    await FeatureFlagService.set_tenant_flag(db_session_async, tenant.id, "beta", enabled=False)
    await FeatureFlagService.set_project_flag(db_session_async, project.id, "beta", enabled=True, override_value="forced-on")

    value = await FeatureFlagService.get_effective_flag(
        db_session_async, tenant.id, "beta", project_id=project.id
    )
    assert value == "forced-on"

    # Without project → tenant value
    value = await FeatureFlagService.get_effective_flag(db_session_async, tenant.id, "beta")
    assert value is False


@pytest.mark.asyncio
async def test_set_flag_upsert_behavior(db_session_async, tenant):
    await FeatureFlagService.set_tenant_flag(db_session_async, tenant.id, "test", enabled=False)
    await FeatureFlagService.set_tenant_flag(db_session_async, tenant.id, "test", enabled=True)

    value = await FeatureFlagService.get_effective_flag(db_session_async, tenant.id, "test")
    assert value is True