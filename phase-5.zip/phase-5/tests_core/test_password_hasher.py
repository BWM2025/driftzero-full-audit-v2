from core.auth.password_hasher import PasswordHasher


def test_hash_and_verify_success():
    pw = "super-secret-123"
    hashed = PasswordHasher.hash(pw)
    assert hashed.startswith("$2b$12$")
    assert PasswordHasher.verify(pw, hashed) is True


def test_verify_fails_wrong_password():
    pw = "correct-horse-battery-staple"
    wrong = "wrong-password"
    hashed = PasswordHasher.hash(pw)
    assert PasswordHasher.verify(wrong, hashed) is False


def test_hash_is_not_plaintext():
    pw = "my-password"
    hashed = PasswordHasher.hash(pw)
    assert pw not in hashed