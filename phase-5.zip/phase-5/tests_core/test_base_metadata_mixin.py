from uuid import uuid4
from sqlalchemy import Column, String
from sqlalchemy.dialects.postgresql import UUID
from db.base import Base
from models.base_metadata import BaseMetadata


class TestEntity(BaseMetadata, Base):
    __tablename__ = "test_entities"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(String(100))


def test_base_metadata_soft_delete(db_session, user):
    entity = TestEntity(id=uuid4(), name="test", created_by=user.id)
    db_session.add(entity)
    db_session.commit()

    entity.soft_delete(user_id=user.id)

    db_session.commit()
    db_session.refresh(entity)

    assert entity.deleted_at is not None
    assert entity.deleted_by == user.id