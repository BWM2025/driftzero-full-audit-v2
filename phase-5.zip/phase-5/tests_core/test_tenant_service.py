import pytest
from uuid import uuid4
from sqlalchemy.exc import IntegrityError
from core.tenancy.tenant_service import TenantService
from core.tenancy.exceptions import NotFoundError, ConflictError
from models.tenant import Tenant


@pytest.mark.asyncio
async def test_create_tenant_success(db_session_async):
    tenant = await TenantService.create_tenant(
        db_session_async,
        name="Acme Corp",
        slug="acme-corp",
        is_active=True,
    )
    assert tenant.name == "Acme Corp"
    assert tenant.slug == "acme-corp"
    assert tenant.is_active is True


@pytest.mark.asyncio
async def test_create_tenant_slug_conflict(db_session_async):
    await TenantService.create_tenant(db_session_async, "First", "dup-slug")
    with pytest.raises(ConflictError, match="Tenant slug already exists"):
        await TenantService.create_tenant(db_session_async, "Second", "dup-slug")


@pytest.mark.asyncio
async def test_get_tenant_by_id_and_slug(db_session_async, tenant):
    fetched = await TenantService.get_tenant_by_id(db_session_async, tenant.id)
    assert fetched.id == tenant.id

    fetched_slug = await TenantService.get_tenant_by_slug(db_session_async, tenant.slug)
    assert fetched_slug.id == tenant.id


@pytest.mark.asyncio
async def test_get_active_tenant_by_id_raises_when_inactive(db_session_async, tenant):
    await TenantService.set_tenant_active(db_session_async, tenant.id, active=False)
    with pytest.raises(NotFoundError, match="Active tenant not found"):
        await TenantService.get_active_tenant_by_id(db_session_async, tenant.id)


@pytest.mark.asyncio
async def test_set_tenant_active_toggles_correctly(db_session_async, tenant):
    updated = await TenantService.set_tenant_active(db_session_async, tenant.id, active=False)
    assert updated.is_active is False

    updated = await TenantService.set_tenant_active(db_session_async, tenant.id, active=True)
    assert updated.is_active is True