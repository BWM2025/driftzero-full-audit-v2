from core.tenancy.exceptions import TenancyError, NotFoundError, ConflictError


def test_tenancy_exceptions_inheritance():
    assert issubclass(NotFoundError, TenancyError)
    assert issubclass(ConflictError, TenancyError)


def test_tenancy_exceptions_docstrings():
    assert "not found" in NotFoundError.__doc__.lower()
    assert "conflict" in ConflictError.__doc__.lower() or "uniqueness" in ConflictError.__doc__.lower()