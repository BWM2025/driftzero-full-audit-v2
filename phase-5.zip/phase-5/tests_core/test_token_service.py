import jwt as pyjwt
import pytest
from core.auth.token_service import TokenService
from core.auth.jwt_manager import JWTManager
from core.auth.auth_exceptions import TokenExpiredError, InvalidTokenError


def test_issue_tokens_structure():
    tokens = TokenService.issue_tokens("usr-123", "t1", ["viewer", "operator"])
    assert set(tokens.keys()) == {"access_token", "refresh_token", "token_type", "expires_in"}
    assert tokens["token_type"] == "bearer"
    assert tokens["expires_in"] == 3600


def test_decode_access_success():
    access = JWTManager.create_access_token("usr-123", "t1", ["viewer"])
    payload = TokenService.decode_access(access)
    assert payload["user_id"] == "usr-123"
    assert payload["tenant_id"] == "t1"
    assert payload["roles"] == ["viewer"]
    assert payload["type"] == "access"


def test_decode_access_raises_on_expired(mocker):
    mocker.patch("core.auth.jwt_manager.JWTManager.decode_access_token", side_effect=pyjwt.ExpiredSignatureError)
    with pytest.raises(TokenExpiredError):
        TokenService.decode_access("expired-token")


def test_decode_refresh_rejects_access_token():
    access = JWTManager.create_access_token("usr-123", "t1", [])
    with pytest.raises(InvalidTokenError):
        TokenService.decode_refresh(access)


def test_verify_any_accepts_both():
    access = JWTManager.create_access_token("usr-123", "t1", [])
    refresh = JWTManager.create_refresh_token("usr-123", "t1")
    assert TokenService.verify_any(access)["type"] == "access"
    assert TokenService.verify_any(refresh)["type"] == "refresh"