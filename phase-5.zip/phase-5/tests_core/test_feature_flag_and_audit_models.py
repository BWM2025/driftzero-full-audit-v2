from datetime import datetime
from uuid import uuid4
from models.tenant import Tenant
from models.tenant_feature_flags import TenantFeatureFlag
from models.project import Project
from models.project_feature_flags import ProjectFeatureFlag
from models.audit_trail import AuditTrail
from models.user import User


def test_tenant_feature_flag_composite_pk(db_session, tenant):
    flag = TenantFeatureFlag(
        tenant_id=tenant.id,
        flag_key="beta_feature_x",
        enabled=True,
        override_value={"limit": 100}
    )
    db_session.add(flag)
    db_session.commit()

    assert repr(flag) == f"<TenantFeatureFlag beta_feature_x=True for tenant {tenant.id}>"


def test_project_feature_flag_composite_pk(db_session, project):
    flag = ProjectFeatureFlag(
        project_id=project.id,
        flag_key="canary_enabled",
        enabled=False
    )
    db_session.add(flag)
    db_session.commit()

    assert repr(flag) == f"<ProjectFeatureFlag canary_enabled=False for project {project.id}>"


def test_audit_trail_creation(db_session, tenant, user):
    audit = AuditTrail(
        id=uuid4(),
        tenant_id=tenant.id,
        user_id=user.id,
        entity_type="project",
        entity_id=uuid4(),
        action="created",
        old_values=None,
        new_values={"name": "New Project"},
        event_metadata={"source": "api"}
    )
    db_session.add(audit)
    db_session.commit()

    assert audit.occurred_at is not None
    assert repr(audit) == f"<AuditTrail created on project:{audit.entity_id} by {user.id}>"