import pytest
from core.auth.auth_exceptions import (
    AuthError,
    InvalidCredentialsError,
    AccountLockedError,
    AccountInactiveError,
    UnauthorizedError,
    TokenExpiredError,
    InvalidTokenError,
    TenantMismatchError,
    SessionInvalidError,
)


def test_all_exceptions_inherit_from_auth_error():
    exceptions = [
        InvalidCredentialsError,
        AccountLockedError,
        AccountInactiveError,
        UnauthorizedError,
        TokenExpiredError,
        InvalidTokenError,
        TenantMismatchError,
        SessionInvalidError,
    ]
    for exc in exceptions:
        assert issubclass(exc, AuthError)


def test_exception_docstrings_contain_expected_text():
    assert "Invalid username" in InvalidCredentialsError.__doc__ or "Invalid credentials" in InvalidCredentialsError.__doc__
    assert "locked" in AccountLockedError.__doc__
    assert "not active" in AccountInactiveError.__doc__ or "disabled" in AccountInactiveError.__doc__
    assert "No valid credentials" in UnauthorizedError.__doc__
    assert "expired" in TokenExpiredError.__doc__
    assert "Invalid token" in InvalidTokenError.__doc__
    assert "tenant" in TenantMismatchError.__doc__
    assert "revoked" in SessionInvalidError.__doc__ or "invalid" in SessionInvalidError.__doc__