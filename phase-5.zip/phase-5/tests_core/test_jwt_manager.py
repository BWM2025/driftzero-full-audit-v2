import jwt
import pytest
from core.auth.jwt_manager import JWTManager
from core.config import settings


def test_create_access_token():
    token = JWTManager.create_access_token("usr-123", "t1", ["viewer", "operator"])
    payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=["HS256"])
    assert payload["user_id"] == "usr-123"
    assert payload["tenant_id"] == "t1"
    assert payload["roles"] == ["viewer", "operator"]
    assert payload["type"] == "access"
    assert "exp" in payload
    assert "iat" in payload


def test_create_refresh_token():
    token = JWTManager.create_refresh_token("usr-123", "t1")
    payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=["HS256"])
    assert payload["user_id"] == "usr-123"
    assert payload["tenant_id"] == "t1"
    assert payload["type"] == "refresh"
    assert "exp" in payload


def test_decode_access_token_rejects_refresh():
    refresh = JWTManager.create_refresh_token("usr-123", "t1")
    with pytest.raises(jwt.InvalidTokenError):
        JWTManager.decode_access_token(refresh)


def test_decode_refresh_token_rejects_access():
    access = JWTManager.create_access_token("usr-123", "t1", ["viewer"])
    with pytest.raises(jwt.InvalidTokenError):
        JWTManager.decode_refresh_token(access)


def test_verify_token_accepts_both():
    access = JWTManager.create_access_token("usr-123", "t1", ["viewer"])
    refresh = JWTManager.create_refresh_token("usr-123", "t1")
    assert JWTManager.verify_token(access)["type"] == "access"
    assert JWTManager.verify_token(refresh)["type"] == "refresh"