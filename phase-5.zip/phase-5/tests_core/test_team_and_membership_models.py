import pytest
from uuid import uuid4
from sqlalchemy.exc import IntegrityError
from models.tenant import Tenant
from models.team import Team
from models.team_membership import TeamMembership
from models.user import User


def test_team_creation_and_repr(db_session, tenant):
    team = Team(
        id=uuid4(),
        tenant_id=tenant.id,
        name="Data Platform",
        description="Owns all pipelines"
    )
    db_session.add(team)
    db_session.commit()

    assert team.is_active is True
    assert repr(team) == f"<Team Data Platform in tenant {tenant.id}>"


def test_team_membership_uniqueness_and_defaults(db_session, tenant, user):
    team = Team(id=uuid4(), tenant_id=tenant.id, name="Ops")
    db_session.add(team)
    db_session.commit()

    m1 = TeamMembership(
        team_id=team.id,
        user_id=user.id,
        roles=["lead", "operator"]
    )
    db_session.add(m1)
    db_session.commit()

    assert m1.roles == ["lead", "operator"]
    assert m1.is_active is True
    assert m1.invited_at is not None

    # Duplicate user+team
    m2 = TeamMembership(team_id=team.id, user_id=user.id)
    db_session.add(m2)
    with pytest.raises(IntegrityError):
        db_session.commit()