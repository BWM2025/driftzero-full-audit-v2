import pytest
from core.tenancy.team_service import TeamService
from core.tenancy.exceptions import NotFoundError, ConflictError


@pytest.mark.asyncio
async def test_create_team_and_list(db_session_async, tenant):
    team = await TeamService.create_team(db_session_async, tenant.id, "Data Team")
    teams = await TeamService.list_teams_for_tenant(db_session_async, tenant.id)
    assert any(t.id == team.id for t in teams)


@pytest.mark.asyncio
async def test_add_member_success_and_duplicate(db_session_async, tenant, user):
    team = await TeamService.create_team(db_session_async, tenant.id, "Ops")

    membership = await TeamService.add_member(db_session_async, team.id, user.id, roles=["lead"])
    assert membership.roles == ["lead"]

    with pytest.raises(ConflictError, match="User is already a member of this team"):
        await TeamService.add_member(db_session_async, team.id, user.id)


@pytest.mark.asyncio
async def test_remove_member_sets_inactive(db_session_async, tenant, user):
    team = await TeamService.create_team(db_session_async, tenant.id, "Dev")
    await TeamService.add_member(db_session_async, team.id, user.id)

    await TeamService.remove_member(db_session_async, team.id, user.id)

    members = await TeamService.list_members_for_team(db_session_async, team.id)
    assert len(members) == 0

    with pytest.raises(NotFoundError):
        await TeamService.remove_member(db_session_async, team.id, uuid4())