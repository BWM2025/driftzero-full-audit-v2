import pytest
from uuid import uuid4
from sqlalchemy.exc import IntegrityError
from models.tenant import Tenant


def test_tenant_defaults_and_repr(db_session):
    tenant = Tenant(
        id=uuid4(),
        name="Acme Corp",
        slug="acme-corp"
    )
    db_session.add(tenant)
    db_session.commit()

    db_session.refresh(tenant)
    assert tenant.is_active is True
    assert tenant.created_at is not None

    assert repr(tenant) == "<Tenant Acme Corp (acme-corp)>"


def test_tenant_slug_unique(db_session):
    t1 = Tenant(id=uuid4(), name="T1", slug="dup")
    db_session.add(t1)
    db_session.commit()

    t2 = Tenant(id=uuid4(), name="T2", slug="dup")
    db_session.add(t2)
    with pytest.raises(IntegrityError):
        db_session.commit()