from core.auth.rbac_resolver import RBACResolver


def test_require_roles():
    assert RBACResolver.require_roles(["viewer"], ["viewer", "operator"]) is True
    assert RBACResolver.require_roles(["operator", "viewer"], ["viewer", "operator"]) is True
    assert RBACResolver.require_roles(["admin"], ["viewer"]) is False


def test_has_any_role():
    assert RBACResolver.has_any_role(["viewer", "admin"], ["operator", "viewer"]) is True
    assert RBACResolver.has_any_role(["admin"], ["viewer"]) is False


def test_has_permission_hierarchy():
    assert RBACResolver.has_permission("viewer", ["admin"]) is True
    assert RBACResolver.has_permission("operator", ["admin"]) is True
    assert RBACResolver.has_permission("admin", ["operator"]) is False
    assert RBACResolver.has_permission("approver", ["operator"]) is False
    assert RBACResolver.has_permission("unknown", ["admin"]) is False