import json
import pytest
from datetime import datetime, timedelta
from core.auth.session_store import SessionStore, redis_client


@pytest.fixture(autouse=True)
async def clear_redis():
    await redis_client.flushdb()


@pytest.mark.asyncio
async def test_create_and_exists():
    await SessionStore.create_session("usr-123", "t1", "refresh-abc")
    exists = await SessionStore.session_exists("usr-123", "refresh-abc")
    assert exists is True


@pytest.mark.asyncio
async def test_exists_wrong_token_returns_false():
    await SessionStore.create_session("usr-123", "t1", "refresh-abc")
    exists = await SessionStore.session_exists("usr-123", "wrong-token")
    assert exists is False


@pytest.mark.asyncio
async def test_delete_removes_session():
    await SessionStore.create_session("usr-123", "t1", "refresh-abc")
    await SessionStore.delete_session("usr-123")
    exists = await SessionStore.session_exists("usr-123", "refresh-abc")
    assert exists is False


@pytest.mark.asyncio
async def test_get_session_returns_dict():
    await SessionStore.create_session("usr-123", "t1", "refresh-abc")
    session = await SessionStore.get_session("usr-123")
    assert session["tenant_id"] == "t1"
    assert session["refresh_token"] == "refresh-abc"
    assert "created_at" in session


@pytest.mark.asyncio
async def test_ttl_is_seven_days():
    await SessionStore.create_session("usr-123", "t1", "refresh-abc")
    ttl = await redis_client.ttl("session:usr-123")
    assert 604790 <= ttl <= 604800