import pytest
from uuid import uuid4
from sqlalchemy.exc import IntegrityError
from models.user import User


def test_user_defaults(db_session):
    user = User(
        id=uuid4(),
        tenant_id="t1",
        username="alice",
        email="alice@example.com",
        password_hash="hashed"
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)

    assert user.roles == ["viewer"]
    assert user.is_active is True
    assert user.is_locked is False
    assert user.failed_login_attempts == 0


def test_tenant_scoped_uniqueness_username(db_session):
    tenant = "t1"
    u1 = User(id=uuid4(), tenant_id=tenant, username="bob", email="bob@x.com", password_hash="x")
    db_session.add(u1)
    db_session.commit()

    u2 = User(id=uuid4(), tenant_id=tenant, username="bob", email="bob2@x.com", password_hash="x")
    db_session.add(u2)
    with pytest.raises(IntegrityError):
        db_session.commit()


def test_tenant_scoped_uniqueness_email(db_session):
    tenant = "t1"
    u1 = User(id=uuid4(), tenant_id=tenant, username="bob", email="bob@x.com", password_hash="x")
    db_session.add(u1)
    db_session.commit()

    u2 = User(id=uuid4(), tenant_id=tenant, username="bob2", email="bob@x.com", password_hash="x")
    db_session.add(u2)
    with pytest.raises(IntegrityError):
        db_session.commit()


def test_role_helpers():
    user = User(
        id=uuid4(),
        tenant_id="t1",
        username="charlie",
        email="c@x.com",
        password_hash="x",
        roles=["viewer", "operator", "approver"]
    )
    assert user.has_role("operator") is True
    assert user.has_role("admin") is False
    assert user.has_any_role(["admin", "approver"]) is True
    assert user.has_any_role(["admin"]) is False


def test_repr():
    user = User(id=uuid4(), tenant_id="t1", username="dave", email="d@x.com", password_hash="x")
    assert repr(user) == "<User dave (t1)>"