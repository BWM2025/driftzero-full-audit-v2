import pytest
from uuid import uuid4
from sqlalchemy.exc import IntegrityError
from models.tenant import Tenant
from models.project import Project


def test_project_tenant_scoped_slug_uniqueness(db_session, tenant):
    p1 = Project(
        id=uuid4(),
        tenant_id=tenant.id,
        name="Web App",
        slug="web"
    )
    db_session.add(p1)
    db_session.commit()

    p2 = Project(
        id=uuid4(),
        tenant_id=tenant.id,
        name="Duplicate",
        slug="web"
    )
    db_session.add(p2)
    with pytest.raises(IntegrityError):
        db_session.commit()


def test_project_repr(db_session, tenant):
    project = Project(
        id=uuid4(),
        tenant_id=tenant.id,
        name="Analytics",
        slug="analytics"
    )
    db_session.add(project)
    db_session.commit()

    assert repr(project) == f"<Project Analytics (analytics) in tenant {tenant.id}>"