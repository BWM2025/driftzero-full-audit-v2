from __future__ import annotations


class TenancyError(Exception):
    """Base exception for tenancy-related service errors."""
    pass


class NotFoundError(TenancyError):
    """Raised when a requested tenant, project, team, or membership is not found."""
    pass


class ConflictError(TenancyError):
    """Raised on uniqueness violations (e.g., slug conflicts, duplicate membership)."""
    pass