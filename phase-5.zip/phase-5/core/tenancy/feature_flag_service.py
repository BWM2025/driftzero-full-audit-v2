from __future__ import annotations

from typing import Any, Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, insert, func
from models.tenant_feature_flags import TenantFeatureFlag
from models.project_feature_flags import ProjectFeatureFlag


class FeatureFlagService:
    @staticmethod
    async def get_effective_flag(
        db: AsyncSession,
        tenant_id: UUID,
        flag_key: str,
        project_id: Optional[UUID] = None,
        default: Any = False,
    ) -> Any:
        # Project override
        if project_id:
            stmt = select(ProjectFeatureFlag).where(
                ProjectFeatureFlag.project_id == project_id,
                ProjectFeatureFlag.flag_key == flag_key,
            )
            result = await db.execute(stmt)
            flag = result.scalars().first()
            if flag:
                return flag.override_value if flag.override_value is not None else flag.enabled

        # Tenant-level
        stmt = select(TenantFeatureFlag).where(
            TenantFeatureFlag.tenant_id == tenant_id,
            TenantFeatureFlag.flag_key == flag_key,
        )
        result = await db.execute(stmt)
        flag = result.scalars().first()
        if flag:
            return flag.override_value if flag.override_value is not None else flag.enabled

        return default

    @staticmethod
    async def set_tenant_flag(
        db: AsyncSession,
        tenant_id: UUID,
        flag_key: str,
        enabled: bool,
        override_value: Optional[Any] = None,
    ) -> None:
        stmt = insert(TenantFeatureFlag).values(
            tenant_id=tenant_id,
            flag_key=flag_key,
            enabled=enabled,
            override_value=override_value,
        )
        upsert = stmt.on_conflict_do_update(
            index_elements=["tenant_id", "flag_key"],
            set_={
                "enabled": enabled,
                "override_value": override_value,
                "updated_at": func.now(),
            },
        )
        await db.execute(upsert)
        await db.commit()

    @staticmethod
    async def set_project_flag(
        db: AsyncSession,
        project_id: UUID,
        flag_key: str,
        enabled: bool,
        override_value394: Optional[Any] = None,
    ) -> None:
        stmt = insert(ProjectFeatureFlag).values(
            project_id=project_id,
            flag_key=flag_key,
            enabled=enabled,
            override_value=override_value,
        )
        upsert = stmt.on_conflict_do_update(
            index_elements=["project_id", "flag_key"],
            set_={
                "enabled": enabled,
                "override_value": override_value,
                "updated_at": func.now(),
            },
        )
        await db.execute(upsert)
        await db.commit()