from __future__ import annotations

from typing import List, Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
from sqlalchemy.exc import IntegrityError
from models.project import Project
from core.tenancy.exceptions import NotFoundError, ConflictError


class ProjectService:
    @staticmethod
    async def create_project(
        db: AsyncSession,
        tenant_id: UUID,
        name: str,
        slug: str,
        description: Optional[str] = None,
        is_active: bool = True,
    ) -> Project:
        project = Project(
            tenant_id=tenant_id,
            name=name,
            slug=slug,
            description=description,
            is_active=is_active,
        )
        db.add(project)
        try:
            await db.commit()
            await db.refresh(project)
            return project
        except IntegrityError as exc:
            await db.rollback()
            raise ConflictError("Project slug already exists in this tenant") from exc

    @staticmethod
    async def list_projects_for_tenant(
        db: AsyncSession,
        tenant_id: UUID,
        active_only: bool = True,
    ) -> List[Project]:
        stmt = select(Project).where(Project.tenant_id == tenant_id)
        if active_only:
            stmt = stmt.where(Project.is_active.is_(True))
        result = await db.execute(stmt)
        return result.scalars().all()

    @staticmethod
    async def get_project_by_id(
        db: AsyncSession,
        project_id: UUID,
        tenant_id: UUID | None = None,
    ) -> Optional[Project]:
        stmt = select(Project).where(Project.id == project_id)
        if tenant_id:
            stmt = stmt.where(Project.tenant_id == tenant_id)
        result = await db.execute(stmt)
        return result.scalars().first()

    @staticmethod
    async def set_project_active(
        db: AsyncSession,
        project_id: UUID,
        active: bool,
    ) -> Project:
        stmt = update(Project).where(Project.id == project_id).values(is_active=active)
        await db.execute(stmt)
        await db.commit()
        project = await ProjectService.get_project_by_id(db, project_id)
        if not project:
            raise NotFoundError("Project not found after update")
        return project