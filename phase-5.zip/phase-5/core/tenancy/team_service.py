from __future__ import annotations

from typing import List, Optional
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update, func
from sqlalchemy.exc import IntegrityError
from models.team import Team
from models.team_membership import TeamMembership
from core.tenancy.exceptions import NotFoundError, ConflictError


class TeamService:
    @staticmethod
    async def create_team(
        db: AsyncSession,
        tenant_id: UUID,
        name: str,
        description: Optional[str] = None,
        is_active: bool = True,
    ) -> Team:
        team = Team(tenant_id=tenant_id, name=name, description=description, is_active=is_active)
        db.add(team)
        await db.commit()
        await db.refresh(team)
        return team

    @staticmethod
    async def add_member(
        db: AsyncSession,
        team_id: UUID,
        user_id: UUID,
        roles: List[str] | None = None,
    ) -> TeamMembership:
        membership = TeamMembership(
            team_id=team_id,
            user_id=user_id,
            roles=roles or ["member"],
        )
        db.add(membership)
        try:
            await db.commit()
            await db.refresh(membership)
            return membership
        except IntegrityError as exc:
            await db.rollback()
            raise ConflictError("User is already a member of this team") from exc

    @staticmethod
    async def remove_member(db: AsyncSession, team_id: UUID, user_id: UUID) -> None:
        stmt = update(TeamMembership).where(
            TeamMembership.team_id == team_id,
            TeamMembership.user_id == user_id,
        ).values(is_active=False, left_at=func.now())
        result = await db.execute(stmt)
        await db.commit()
        if result.rowcount == 0:
            raise NotFoundError("Membership not found")

    @staticmethod
    async def list_teams_for_tenant(db: AsyncSession, tenant_id: UUID) -> List[Team]:
        result = await db.execute(select(Team).where(Team.tenant_id == tenant_id, Team.is_active.is_(True)))
        return result.scalars().all()

    @staticmethod
    async def list_members_for_team(db: AsyncSession, team_id: UUID) -> List[TeamMembership]:
        result = await db.execute(
            select(TeamMembership).where(TeamMembership.team_id == team_id, TeamMembership.is_active.is_(True))
        )
        return result.scalars().all()