from __future__ import annotations

from typing import Dict, Set
import json
import asyncio
from redis.asyncio import Redis
from core.config import settings
from api.websocket.connection import WebSocketConnection

redis = Redis.from_url(settings.REDIS_URL)


class Broadcaster:
    def __init__(self):
        self.subscriptions: Dict[str, Set[WebSocketConnection]] = {}
        self.pubsub_task = None

    async def subscribe(self, tenant_id: str, connection: WebSocketConnection):
        if tenant_id not in self.subscriptions:
            self.subscriptions[tenant_id] = set()
        self.subscriptions[tenant_id].add(connection)

        if self.pubsub_task is None:
            self.pubsub_task = asyncio.create_task(self._redis_listener())

    async def unsubscribe(self, tenant_id: str, connection: WebSocketConnection):
        if tenant_id in self.subscriptions:
            self.subscriptions[tenant_id].discard(connection)
            if not self.subscriptions[tenant_id]:
                del self.subscriptions[tenant_id]

    async def publish(self, tenant_id: str, event: dict):
        message = json.dumps({"tenant_id": tenant_id, "event": event})
        await redis.publish(f"ws:tenant:{tenant_id}", message)

    async def _redis_listener(self):
        pubsub = redis.pubsub()
        async for tenant_id in self.subscriptions.keys():
            await pubsub.subscribe(f"ws:tenant:{tenant_id}")

        async for message in pubsub.listen():
            if message["type"] != "message":
                continue
            data = json.loads(message["data"])
            tenant_id = data["tenant_id"]
            event = data["event"]
            if tenant_id in self.subscriptions:
                dead = set()
                for conn in self.subscriptions[tenant_id]:
                    try:
                        await conn.send_json(event)
                    except Exception:
                        dead.add(conn)
                for conn in dead:
                    self.subscriptions[tenant_id].discard(conn)