from __future__ import annotations


class ApprovalError(Exception):
    """Base exception for approval workflow errors."""
    pass


class ApprovalNotFoundError(ApprovalError):
    """Raised when an approval request or decision is not found."""
    pass


class ApprovalAlreadyDecidedError(ApprovalError):
    """Raised when trying to decide on an already resolved request."""
    pass


class InsufficientApprovalsError(ApprovalError):
    """Raised when required approver count is not met."""
    pass


class ApprovalExpiredError(ApprovalError):
    """Raised when operating on an expired approval request."""
    pass