from __future__ import annotations

import fnmatch
from datetime import datetime, timedelta


def matches_dataset_pattern(dataset_id: str, pattern: str) -> bool:
    return fnmatch.fnmatch(dataset_id.lower(), pattern.lower())


def default_expiry_hours() -> int:
    return 24


def calculate_expiry(from_time: datetime | None = None, hours: int | None = None) -> datetime:
    base = from_time or datetime.utcnow()
    hrs = hours or default_expiry_hours()
    return base + timedelta(hours=hrs)