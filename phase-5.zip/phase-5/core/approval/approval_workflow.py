from __future__ import annotations

from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from repositories.approver_assignment_repository import ApproverAssignmentRepository
from core.approval.approval_service import ApprovalService


class ApprovalWorkflow:
    @staticmethod
    async def initiate_approval(
        db: AsyncSession,
        saga_id: str,
        tenant_id: str,
        environment_id: str,
        dataset_id: str,
        requested_by: str,
    ) -> str:
        assignments = await ApproverAssignmentRepository.get_approvers_for_dataset(db, tenant_id, dataset_id)
        required = max(len(assignments), 1)

        request = await ApprovalService.create_approval_request(
            db,
            saga_id=saga_id,
            tenant_id=tenant_id,
            environment_id=environment_id,
            dataset_id=dataset_id,
            requested_by=requested_by,
            required_approvers=required,
        )
        return str(request.id)