from __future__ import annotations

from datetime import datetime, timedelta
from typing import List
from uuid import UUID
from sqlalchemy.ext.asyncio import AsyncSession
from repositories.approval_repository import ApprovalRepository
from repositories.approver_assignment_repository import ApproverAssignmentRepository
from models.approval_request import ApprovalRequest, ApprovalStatus
from models.approval_decision import ApprovalDecision
from core.approval.enums import ApprovalDecisionType
from core.approval.exceptions import (
    ApprovalNotFoundError,
    ApprovalAlreadyDecidedError,
    ApprovalExpiredError,
)


class ApprovalService:
    DEFAULT_EXPIRY_HOURS = 24

    @staticmethod
    async def create_approval_request(
        db: AsyncSession,
        saga_id: UUID,
        tenant_id: str,
        environment_id: str,
        dataset_id: str,
        requested_by: str,
        required_approvers: int = 1,
    ) -> ApprovalRequest:
        expires_at = datetime.utcnow() + timedelta(hours=ApprovalService.DEFAULT_EXPIRY_HOURS)
        request = ApprovalRequest(
            saga_id=saga_id,
            tenant_id=tenant_id,
            environment_id=environment_id,
            dataset_id=dataset_id,
            requested_by=requested_by,
            expires_at=expires_at,
            required_approvers=required_approvers,
            status=ApprovalStatus.PENDING,
        )
        return await ApprovalRepository.create_request(db, request)

    @staticmethod
    async def record_decision(
        db: AsyncSession,
        request_id: UUID,
        approver_user_id: str,
        decision: ApprovalDecisionType,
        comment: str | None = None,
    ) -> ApprovalRequest:
        request = await ApprovalRepository.get_request(db, request_id)
        if not request:
            raise ApprovalNotFoundError()
        if request.status != ApprovalStatus.PENDING:
            raise ApprovalAlreadyDecidedError()
        if request.expires_at < datetime.utcnow():
            await ApprovalRepository.update_request_status(db, request_id, ApprovalStatus.EXPIRED)
            raise ApprovalExpiredError()

        decision_record = ApprovalDecision(
            approval_request_id=request_id,
            approver_user_id=approver_user_id,
            decision=decision.value,
            comment=comment,
        )
        await ApprovalRepository.record_decision(db, decision_record)

        await ApprovalService._reevaluate_request_status(db, request_id)
        await db.refresh(request)
        return request

    @staticmethod
    async def _reevaluate_request_status(db: AsyncSession, request_id: UUID) -> None:
        from sqlalchemy import func, and_

        request = await ApprovalRepository.get_request(db, request_id)
        if request.status != ApprovalStatus.PENDING:
            return

        approve_count = await db.scalar(
            select(func.count()).select_from(ApprovalDecision).where(
                ApprovalDecision.approval_request_id == request_id,
                ApprovalDecision.decision == ApprovalDecisionType.APPROVED.value,
            )
        )
        reject_count = await db.scalar(
            select(func.count()).select_from(ApprovalDecision).where(
                ApprovalDecision.approval_request_id == request_id,
                ApprovalDecision.decision == ApprovalDecisionType.REJECTED.value,
            )
        )

        if reject_count > 0:
            await ApprovalRepository.update_request_status(db, request_id, ApprovalStatus.REJECTED)
        elif approve_count >= request.required_approvers:
            await ApprovalRepository.update_request_status(db, request_id, ApprovalStatus.APPROVED)
        elif request.expires_at < datetime.utcnow():
            await ApprovalRepository.update_request_status(db, request_id, ApprovalStatus.EXPIRED)