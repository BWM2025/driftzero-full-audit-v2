from __future__ import annotations

import bcrypt
from typing import Final


class PasswordHasher:
    COST: Final[int] = 12

    @staticmethod
    def hash(password: str) -> str:
        salt = bcrypt.gensalt(rounds=PasswordHasher.COST)
        return bcrypt.hashpw(password.encode("utf-8"), salt).decode("utf-8")

    @staticmethod
    def verify(password: str, password_hash: str) -> bool:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))