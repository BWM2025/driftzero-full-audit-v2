from __future__ import annotations

import json
from datetime import datetime, timedelta
from typing import Optional
from redis.asyncio import Redis
from core.config import settings

redis_client = Redis.from_url(settings.REDIS_URL, decode_responses=True)


class SessionStore:
    SESSION_KEY_PREFIX = "session:"
    TTL_DAYS = 7

    @staticmethod
    async def create_session(user_id: str, tenant_id: str, refresh_token: str) -> None:
        key = f"{SessionStore.SESSION_KEY_PREFIX}{user_id}"
        value = json.dumps({
            "tenant_id": tenant_id,
            "refresh_token": refresh_token,
            "created_at": datetime.utcnow().isoformat()
        })
        await redis_client.setex(key, timedelta(days=SessionStore.TTL_DAYS), value)

    @staticmethod
    async def session_exists(user_id: str, refresh_token: str) -> bool:
        key = f"{SessionStore.SESSION_KEY_PREFIX}{user_id}"
        stored = await redis_client.get(key)
        if not stored:
            return False
        data = json.loads(stored)
        return data["refresh_token"] == refresh_token

    @staticmethod
    async def delete_session(user_id: str) -> None:
        key = f"{SessionStore.SESSION_KEY_PREFIX}{user_id}"
        await redis_client.delete(key)

    @staticmethod
    async def get_session(user_id: str) -> Optional[dict]:
        key = f"{SessionStore.SESSION_KEY_PREFIX}{user_id}"
        stored = await redis_client.get(key)
        return json.loads(stored) if stored else None