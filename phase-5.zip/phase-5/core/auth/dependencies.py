from fastapi import Depends, HTTPException, status
from core.auth.rbac_resolver import RBACResolver
from api.dependencies.current_user import get_current_active_user


def require_roles(required_roles: list[str]):
    def role_checker(user=Depends(get_current_active_user)):
        if not RBACResolver.require_roles(required_roles, user.roles):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions",
            )
        return user
    return role_checker


def require_any_role(required_roles: list[str]):
    def role_checker(user=Depends(get_current_active_user)):
        if not RBACResolver.has_any_role(required_roles, user.roles):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions",
            )
        return user
    return role_checker