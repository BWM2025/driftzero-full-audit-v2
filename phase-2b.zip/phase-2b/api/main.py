from fastapi import FastAPI
from api.controllers import (
    drift_incident_controller,
    drift_saga_controller,
    patch_manifest_controller,
    policy_decision_controller,
    quarantine_controller,
    sandbox_controller,
    canary_controller,
    cross_env_rollout_controller,
)
from api.middleware import add_middlewares

app = FastAPI(
    title="DriftZero Control Plane",
    version="3.3.0",
    description="Schema drift governance platform",
)

app.include_router(drift_incident_controller.router)
app.include_router(drift_saga_controller.router)
app.include_router(patch_manifest_controller.router)
app.include_router(policy_decision_controller.router)
app.include_router(quarantine_controller.router)
app.include_router(sandbox_controller.router)
app.include_router(canary_controller.router)
app.include_router(cross_env_rollout_controller.router)

add_middlewares(app)

@app.get("/health")
async def health():
    return {"status": "healthy"}


Python