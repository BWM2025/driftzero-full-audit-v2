from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.canary_service import CanaryService

router = APIRouter(prefix="/canary", tags=["Canary"])

@router.post("/start/{patch_id}")
async def start_canary(
    patch_id: str,
    session: AsyncSession = Depends(get_session),
    service: CanaryService = Depends(get_service(CanaryService)),
):
    await service.start_canary(patch_id)
    return {"status": "canary started"}


Python