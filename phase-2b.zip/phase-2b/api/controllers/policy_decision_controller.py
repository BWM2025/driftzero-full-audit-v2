from fastapi import APIRouter, Depends
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.policy_decision_service import PolicyDecisionService
from models.policy_decision import PolicyDecisionResponse

router = APIRouter(prefix="/policy-decisions", tags=["Policy Decisions"])

@router.get("/{decision_id}", response_model=PolicyDecisionResponse)
async def get_decision(
    decision_id: str,
    session: AsyncSession = Depends(get_session),
    service: PolicyDecisionService = Depends(get_service(PolicyDecisionService)),
):
    decision = await service.get_by_id(session, decision_id)
    if not decision:
        raise HTTPException(404, "Decision not found")
    return decision


Python