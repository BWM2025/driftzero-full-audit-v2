from fastapi import APIRouter, Depends, HTTPException
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.patch_manifest_service import PatchManifestService
from models.patch_manifest import PatchManifestResponse

router = APIRouter(prefix="/patches", tags=["Patch Manifests"])

@router.get("/{patch_id}", response_model=PatchManifestResponse)
async def get_patch(
    patch_id: str,
    session: AsyncSession = Depends(get_session),
    service: PatchManifestService = Depends(get_service(PatchManifestService)),
):
    patch = await service.get_by_id(session, patch_id)
    if not patch:
        raise HTTPException(status_code=404, detail="Patch manifest not found")
    return patch

@router.get("/", response_model=List[PatchManifestResponse])
async def list_patches(
    saga_id: Optional[str] = None,
    status: Optional[str] = None,
    session: AsyncSession = Depends(get_session),
    service: PatchManifestService = Depends(get_service(PatchManifestService)),
):
    return await service.list_patches(session, saga_id=saga_id, status=status)


Python