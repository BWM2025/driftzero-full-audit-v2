from fastapi import APIRouter, Depends, HTTPException
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.drift_saga_service import DriftSagaService
from models.drift_saga import DriftSagaResponse

router = APIRouter(prefix="/sagas", tags=["Drift Sagas"])

@router.get("/{saga_id}", response_model=DriftSagaResponse)
async def get_saga(
    saga_id: str,
    session: AsyncSession = Depends(get_session),
    service: DriftSagaService = Depends(get_service(DriftSagaService)),
):
    saga = await service.get_by_id(session, saga_id)
    if not saga:
        raise HTTPException(status_code=404, detail="Saga not found")
    return saga

@router.get("/", response_model=List[DriftSagaResponse])
async def list_sagas(
    tenant_id: str = Query(...),
    environment_id: Optional[str] = None,
    dataset_id: Optional[str] = None,
    status: Optional[str] = None,
    session: AsyncSession = Depends(get_session),
    service: DriftSagaService = Depends(get_service(DriftSagaService)),
):
    return await service.list_sagas(
        session=session,
        tenant_id=tenant,
        environment_id=environment_id,
        dataset_id=dataset_id,
        status=status,
    )


Python