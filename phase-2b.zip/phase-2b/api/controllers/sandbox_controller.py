from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.sandbox_service import SandboxService

router = APIRouter(prefix="/sandbox", tags=["Sandbox"])

@router.post("/trigger/{patch_id}")
async def trigger_sandbox(
    patch_id: str,
    session: AsyncSession = Depends(get_session),
    service: SandboxService = Depends(get_service(SandboxService)),
):
    await service.trigger_execution(patch_id)
    return {"status": "sandbox execution triggered"}


Python