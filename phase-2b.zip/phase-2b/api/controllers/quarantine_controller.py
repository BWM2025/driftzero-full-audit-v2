from fastapi import APIRouter, Depends, HTTPException
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.quarantine_service import QuarantineService
from models.quarantine_record import QuarantineRecordResponse

router = APIRouter(prefix="/quarantine", tags=["Quarantine"])

@router.get("/{quarantine_id}", response_model=QuarantineRecordResponse)
async def get_quarantine(
    quarantine_id: str,
    session: AsyncSession = Depends(get_session),
    service: QuarantineService = Depends(get_service(QuarantineService)),
):
    record = await service.get_quarantine(session, quarantine_id)
    if not record:
        raise HTTPException(404, "Quarantine record not found")
    return record


Python