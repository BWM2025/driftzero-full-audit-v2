from fastapi import APIRouter, Depends, HTTPException
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.cross_env_rollout_service import CrossEnvRolloutService
from models.cross_env_rollout import CrossEnvRolloutResponse

router = APIRouter(prefix="/cross-env", tags=["Cross-Environment"])

@router.post("/promote/{saga_id}")
async def promote_to_next_env(
    saga_id: str,
    target_env: str,
    session: AsyncSession = Depends(get_session),
    service: CrossEnvRolloutService = Depends(get_service(CrossEnvRolloutService)),
):
    await service.promote(saga_id, target_env)
    return {"status": "promotion initiated"}


Python