from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session, get_service
from services.drift_incident_service import DriftIncidentService, NotFoundError
from models.drift_incident import DriftIncident

router = APIRouter(prefix="/drift-incidents", tags=["Drift Incidents"])

class DriftIncidentResponse(BaseModel):
    incident_id: str
    tenant_id: str
    environment_id: str
    dataset_id: str
    detected_at: str
    detected_by: str
    dimension: str
    drift_type: str
    risk_level: str
    auto_heal_eligible: bool
    classification_reason: Optional[str] = None
    raw_observation: dict
    reference_version_id: str
    status: str
    resolution_summary: Optional[str] = None
    created_at: str
    updated_at: str

    @staticmethod
    def _to_response(obj: DriftIncident) -> "DriftIncidentResponse":
        return DriftIncidentResponse(
            incident_id=str(obj.incident_id),
            tenant_id=str(obj.tenant_id),
            environment_id=obj.environment_id,
            dataset_id=obj.dataset_id,
            detected_at=obj.detected_at.isoformat(),
            detected_by=obj.detected_by,
            dimension=obj.dimension,
            drift_type=obj.drift_type,
            risk_level=obj.risk_level,
            auto_heal_eligible=obj.auto_heal_eligible,
            classification_reason=obj.classification_reason,
            raw_observation=obj.raw_observation,
            reference_version_id=str(obj.reference_version_id),
            status=obj.status,
            resolution_summary=obj.resolution_summary,
            created_at=obj.created_at.isoformat(),
            updated_at=obj.updated_at.isoformat(),
        )

@router.get("/{incident_id}", response_model=DriftIncidentResponse)
async def get_drift_incident(
    incident_id: str,
    tenant_id: str = Query(...),
    session: AsyncSession = Depends(get_session),
    service: DriftIncidentService = Depends(get_service(DriftIncidentService)),
):
    try:
        incident = await service.get_by_id(session=session, tenant_id=tenant_id, id=incident_id)
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Drift incident not found")
    return DriftIncidentResponse._to_response(incident)

@router.get("/", response_model=List[DriftIncidentResponse])
async def list_drift_incidents(
    tenant_id: str = Query(...),
    environment_id: Optional[str] = Query(None),
    dataset_id: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    session: AsyncSession = Depends(get_session),
    service: DriftIncidentService = Depends(get_service(DriftIncidentService)),
):
    incidents = await service.list_incidents(
        session=session,
        tenant_id=tenant_id,
        environment_id=environment_id,
        dataset_id=dataset_id,
        status=status,
    )
    return [DriftIncidentResponse._to_response(i) for i in incidents]


Python