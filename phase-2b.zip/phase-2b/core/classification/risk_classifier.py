from typing import Dict, Any

class RiskClassifier:
    HIGH_RISK_COLUMNS = {"ssn", "credit_card", "password", "secret"}
    HIGH_RISK_TYPES = {"TYPE_CHANGE", "REMOVED_COLUMN", "CONSTRAINT_CHANGE"}

    def classify(self, incident: Dict[str, Any]) -> str:
        drift_type = incident.get("drift_type", "")
        column = incident.get("column", "")

        if drift_type in self.HIGH_RISK_TYPES:
            return "HIGH"
        if column.lower() in self.HIGH_RISK_COLUMNS:
            return "HIGH"
        if drift_type == "NEW_COLUMN":
            return "LOW"
        return "MEDIUM"


Python