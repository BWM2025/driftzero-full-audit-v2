from typing import Dict, Any
from models.patch_manifest import PatchAction

class ActionBuilder:
    @staticmethod
    def build_add_column(column_def: Dict[str, Any]) -> PatchAction:
        return PatchAction(
            action_type="ADD_COLUMN",
            column_name=column_def["name"],
            column_type=column_def["type"],
            nullable=column_def.get("nullable", True),
            default=column_def.get("default")
        )

    @staticmethod
    def build_type_change(change: Dict[str, Any]) -> PatchAction:
        return PatchAction(
            action_type="ALTER_COLUMN_TYPE",
            column_name=change["column"],
            new_type=change["to"]
        )


Python