from typing import List, Dict, Any
from models.patch_manifest import PatchManifest, PatchAction

class PatchGenerator:
    def generate_patch(self, incidents: List[Dict[str, Any]]) -> PatchManifest:
        actions = []
        for inc in incidents:
            if inc["drift_type"] == "NEW_COLUMN":
                actions.append(PatchAction(
                    action_type="ADD_COLUMN",
                    column_name=inc["column"],
                    column_type=inc.get("to"),
                    nullable=True
                ))
            elif inc["drift_type"] == "REMOVED_COLUMN":
                actions.append(PatchAction(
                    action_type="DROP_COLUMN",
                    column_name=inc["column"]
                ))
        return PatchManifest(actions=actions)


Python