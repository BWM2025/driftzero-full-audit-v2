from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from .cross_env_models import CrossEnvPromotion

class CrossEnvRepository:
    async def create_promotion(self, session: AsyncSession, promotion: CrossEnvPromotion):
        session.add(promotion)
        await session.commit()
        await session.refresh(promotion)
        return promotion

    async def get_by_saga_id(self, session: AsyncSession, saga_id: str):
        result = await session.execute(
            select(CrossEnvPromotion).where(CrossEnvPromotion.saga_id == saga_id)
        )
        return result.scalars().all()


Python