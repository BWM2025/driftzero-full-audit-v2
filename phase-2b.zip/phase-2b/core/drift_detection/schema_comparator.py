from typing import Dict, Any, List

class SchemaComparator:
    def compare(self, before: Dict[str, Any], after: Dict[str, Any]) -> List[Dict]:
        diffs = []

        before_cols = {c["name"]: c for c in before.get("columns", [])}
        after_cols = {c["name"]: c for c in after.get("columns", [])}

        # Removed columns
        for name in before_cols.keys() - after_cols.keys():
            diffs.append({"type": "REMOVED_COLUMN", "column": name})

        # Added columns
        for name in after_cols.keys() - before_cols.keys():
            diffs.append({"type": "NEW_COLUMN", "column": name})

        # Type changes
        for name in before_cols.keys() & after_cols.keys():
            b = before_cols[name]
            a = after_cols[name]
            if b.get("type") != a.get("type"):
                diffs.append({
                    "type": "TYPE_CHANGE",
                    "column": name,
                    "from": b.get("type"),
                    "to": a.get("type")
                })

        return diffs


Python