from typing import List, Dict, Any
from core.drift_detection.schema_comparator import SchemaComparator
from models.drift_incident import DriftIncident
from utils.id_generator import generate_uuid

class DriftDetector:
    def __init__(self):
        self.comparator = SchemaComparator()

    async def detect(
        self,
        tenant_id: str,
        environment_id: str,
        dataset_id: str,
        before: Dict[str, Any],
        after: Dict[str, Any],
    ) -> List[DriftIncident]:
        differences = self.comparator.compare(before, after)
        incidents = []
        for diff in differences:
            incident = DriftIncident(
                incident_id=generate_uuid(),
                tenant_id=tenant_id,
                environment_id=environment_id,
                dataset_id=dataset_id,
                drift_type=diff["type"],
                dimension=diff.get("dimension", "STRUCTURAL"),
                raw_observation=diff,
                detected_at=datetime.utcnow(),
                status="NEW",
            )
            incidents.append(incident)
        return incidents


Python