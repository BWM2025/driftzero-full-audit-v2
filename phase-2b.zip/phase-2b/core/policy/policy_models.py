from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class PolicyRule(BaseModel):
    id: str
    name: str
    dataset_pattern: str
    drift_types: Optional[List[str]] = None
    risk_levels: Optional[List[str]] = None
    action: str  # AUTO_HEAL, REQUIRE_APPROVAL, QUARANTINE, BLOCK
    sandbox_required: bool = True
    canary_required: bool = False
    approvals_required: int = 0

class Policy(BaseModel):
    policy_id: str
    tenant_id: str
    name: str
    description: Optional[str]
    rules: List[PolicyRule]
    enabled: bool = True
    created_at: str
    updated_at: str


Python