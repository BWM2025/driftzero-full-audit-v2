from datetime import datetime, timedelta
from typing import List

class QuarantineManager:
    DEFAULT_QUARANTINE_DAYS = 30

    def should_quarantine(self, incident: dict) -> bool:
        return incident.get("risk_level") == "HIGH" and incident.get("drift_type") in ["TYPE_CHANGE", "REMOVED_COLUMN"]

    def calculate_expiry(self) -> datetime:
        return datetime.utcnow() + timedelta(days=self.DEFAULT_QUARANTINE_DAYS)


Python