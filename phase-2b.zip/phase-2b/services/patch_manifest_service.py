from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.patch_manifest import PatchManifest

class PatchManifestService:
    async def get_by_id(self, session: AsyncSession, patch_id: str) -> Optional[PatchManifest]:
        result = await session.execute(
            select(PatchManifest).where(PatchManifest.patch_manifest_id == patch_id)
        )
        return result.scalar_one_or_none()

    async def list_patches(
        self,
        session: AsyncSession,
        saga_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[PatchManifest]:
        filters = []
        if saga_id:
            filters.append(PatchManifest.drift_saga_id == saga_id)
        if status:
            filters.append(PatchManifest.status == status)

        query = select(PatchManifest)
        if filters:
            query = query.where(*filters)
        result = await session.execute(query)
        return result.scalars().all()


Python