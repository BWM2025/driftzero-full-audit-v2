from sqlalchemy.ext.asyncio import AsyncSession
from core.canary.canary_orchestrator import CanaryOrchestrator

class CanaryService:
    def __init__(self):
        self.orchestrator = CanaryOrchestrator()

    async def start_canary(self, patch_manifest_id: str):
        await self.orchestrator.start(patch_manifest_id)


Python