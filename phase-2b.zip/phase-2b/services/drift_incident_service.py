from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from models.drift_incident import DriftIncident
from .exceptions import NotFoundError

class DriftIncidentService:
    async def get_by_id(self, session: AsyncSession, tenant_id: str, id: str) -> DriftIncident:
        result = await session.execute(
            select(DriftIncident).where(
                and_(DriftIncident.tenant_id == tenant_id, DriftIncident.incident_id == id)
            )
        )
        incident = result.scalar_one_or_none()
        if not incident:
            raise NotFoundError("Drift incident not found")
        return incident

    async def list_incidents(
        self,
        session: AsyncSession,
        tenant_id: str,
        environment_id: Optional[str] = None,
        dataset_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[DriftIncident]:
        filters = [DriftIncident.tenant_id == tenant_id]
        if environment_id:
            filters.append(DriftIncident.environment_id == environment_id)
        if dataset_id:
            filters.append(DriftIncident.dataset_id == dataset_id)
        if status:
            filters.append(DriftIncident.status == status)

        result = await session.execute(select(DriftIncident).where(and_(*filters)))
        return result.scalars().all()


Python