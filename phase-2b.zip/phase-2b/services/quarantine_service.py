from datetime import datetime
from typing import List, Dict, Any, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from models.quarantine_record import QuarantineRecord
from .quarantine_repository import QuarantineRepository, NotFoundError

class QuarantineService:
    def __init__(self, repo: Optional[QuarantineRepository] = None):
        self.repo = repo or QuarantineRepository()

    async def create_quarantine(
        self,
        session: AsyncSession,
        tenant_id: str,
        environment_id: str,
        dataset_id: str,
        incident_ids: List[str],
        reason: Optional[str] = None,
        expires_at: Optional[datetime] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> QuarantineRecord:
        record = QuarantineRecord(
            tenant_id=tenant_id,
            environment_id=environment_id,
            dataset_id=dataset_id,
            incident_ids=incident_ids,
            reason=reason,
            status="ACTIVE",
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return await self.repo.create(session, record)

    async def get_quarantine(
        self,
        session: AsyncSession,
        tenant_id: str,
        quarantine_id: str,
    ) -> QuarantineRecord:
        return await self.repo.get_by_id(session, tenant_id, quarantine_id)

    async def list_quarantines_for_dataset(
        self,
        session: AsyncSession,
        tenant_id: str,
        environment_id: str,
        dataset_id: str,
    ) -> List[QuarantineRecord]:
        return await self.repo.list_for_dataset(session, tenant_id, environment_id, dataset_id)

    async def update_status(
        self,
        session: AsyncSession,
        tenant_id: str,
        quarantine_id: str,
        new_status: str,
    ) -> QuarantineRecord:
        record = await self.repo.get_by_id(session, tenant_id, quarantine_id)
        record.status = new_status
        record.updated_at = datetime.utcnow()
        return await self.repo.update(session, record)


Python