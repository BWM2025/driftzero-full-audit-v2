from sqlalchemy.ext.asyncio import AsyncSession
from core.sandbox.sandbox_executor import SandboxExecutor

class SandboxService:
    def __init__(self):
        self.executor = SandboxExecutor()

    async def trigger_execution(self, patch_manifest_id: str):
        # In production this would publish to Kafka / Temporal
        await self.executor.execute(patch_manifest_id)


Python