from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.policy_decision import PolicyDecision

class PolicyDecisionService:
    async def get_by_id(self, session: AsyncSession, decision_id: str) -> Optional[PolicyDecision]:
        result = await session.execute(
            select(PolicyDecision).where(PolicyDecision.decision_id == decision_id)
        )
        return result.scalar_one_or_none()


Python