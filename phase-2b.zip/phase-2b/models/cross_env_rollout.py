from sqlalchemy import Column, String, JSON, DateTime
from sqlalchemy.dialects.postgresql import UUID
from datetime import datetime
import uuid
from .base import Base

class CrossEnvRollout(Base):
    __tablename__ = "cross_env_rollouts"

    rollout_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    saga_id = Column(UUID(as_uuid=True))
    source_env = Column(String(64))
    target_env = Column(String(64))
    status = Column(String(32))
    started_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    completed_at = Column(DateTime(timezone=True))
    metadata = Column(JSON)


Python