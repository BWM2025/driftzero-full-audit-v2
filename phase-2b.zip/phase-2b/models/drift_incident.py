from sqlalchemy import Column, String, JSON, DateTime, Boolean, Enum, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
from .base import Base

class DriftIncident(Base):
    __tablename__ = "drift_incidents"

    incident_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    environment_id = Column(String(64), nullable=False, index=True)
    dataset_id = Column(String(255), nullable=False, index=True)
    detected_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    detected_by = Column(String(128))
    dimension = Column(String(STRING)
    drift_type = Column(String(64), nullable=False)
    risk_level = Column(String(20), nullable=False)
    auto_heal_eligible = Column(Boolean, default=False)
    classification_reason = Column(String)
    raw_observation = Column(JSON, nullable=False)
    reference_version_id = Column(UUID(as_uuid=True), ForeignKey("temporal_schema_history.schema_version_id"))
    status = Column(String(20), default="NEW")
    resolution_summary = Column(String)
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)

    reference_version = relationship("TemporalSchemaVersion")


Python