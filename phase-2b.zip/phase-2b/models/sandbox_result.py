from sqlalchemy import Column, String, JSON, DateTime, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from datetime import datetime
import uuid
from .base import Base

class SandboxResult(Base):
    __tablename__ = "sandbox_results"

    sandbox_run_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    patch_manifest_id = Column(UUID(as_uuid=True), ForeignKey("patch_manifests.patch_manifest_id"))
    status = Column(String(20))  # PASS / FAIL
    schema_ok = Column(Boolean)
    dq_ok = Column(Boolean)
    perf_ok = Column(Boolean)
    error_message = Column(String)
    completed_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    metadata = Column(JSON)


Python