from sqlalchemy import Column, String, Float, Boolean, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from datetime import datetime
import uuid
from .base import Base

class CanaryResult(Base):
    __tablename__ = "canary_results"

    canary_run_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    patch_manifest_id = Column(UUID(as_uuid=True), ForeignKey("patch_manifests.patch_manifest_id"))
    status = Column(String(20))  # PASS / FAIL
    error_rate = Column(Float)
    anomaly_score = Column(Float)
    downstream_impact = Column(Boolean)
    rollback_triggered = Column(Boolean)
    error_message = Column(String)
    completed_at = Column(DateTime(timezone=True), default=datetime.utcnow)


Python