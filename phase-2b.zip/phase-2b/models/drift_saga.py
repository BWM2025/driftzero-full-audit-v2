from sqlalchemy import Column, String, JSON, DateTime, Enum as SQLEnum, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
from enum import Enum as PyEnum
from .base import Base

class SagaStatus(str, PyEnum):
    IN_PROGRESS = "IN_PROGRESS"
    COMMITTED = "COMMITTED"
    COMPENSATED = "COMPENSATED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

class DriftSaga(Base):
    __tablename__ = "drift_sagas"

    drift_saga_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    environment_id = Column(String(64), nullable=False, index=True)
    dataset_id = Column(String(255), nullable=False, index=True)
    status = Column(SQLEnum(SagaStatus), default=SagaStatus.IN_PROGRESS)
    incident_ids = Column(ARRAY(UUID(as_uuid=True)))
    patch_manifest_id = Column(UUID(as_uuid=True), ForeignKey("patch_manifests.patch_manifest_id"))
    current_step = Column(String(64))
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)
    locked_until = Column(DateTime(timezone=True))

    patch_manifest = relationship("PatchManifest")


Python