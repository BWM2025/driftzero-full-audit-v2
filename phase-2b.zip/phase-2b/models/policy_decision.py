from sqlalchemy import Column, String, JSON, DateTime, Boolean, Integer, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from datetime import datetime
import uuid
from .base import Base

class PolicyDecision(Base):
    __tablename__ = "policy_decisions"

    decision_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    incident_id = Column(UUID(as_uuid=True), ForeignKey("drift_incidents.incident_id"))
    tenant_id = Column(UUID(as_uuid=True), nullable=False)
    environment_id = Column(String(64))
    dataset_id = Column(String(255))
    evaluated_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    action = Column(String(32), nullable=False)  # AUTO_HEAL, QUARANTINE, etc.
    sandbox_required = Column(Boolean, default=True)
    canary_required = Column(Boolean, default=False)
    approvals_required = Column(Integer, default=0)
    decision_context = Column(JSON)
    metadata = Column(JSON)

    incident = relationship("DriftIncident")


Python