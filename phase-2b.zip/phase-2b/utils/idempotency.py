import hashlib
from typing import Any

def generate_idempotency_key(payload: Any) -> str:
    payload_str = str(payload)
    return hashlib.sha256(payload_str.encode()).hexdigest()


Python