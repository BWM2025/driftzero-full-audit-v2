from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from models.drift_saga import DriftSaga

async def acquire_lock(session: AsyncSession, dataset_id: str, holder_id: str) -> bool:
    now = datetime.utcnow()
    expiry = now + timedelta(minutes=5)

    result = await session.execute(
        update(DriftSaga)
        .where(
            (DriftSaga.dataset_id == dataset_id) &
            ((DriftSaga.locked_until < now) | (DriftSaga.locked_until.is_(None)))
        )
        .values(locked_until=expiry, lock_holder_id=holder_id)
        .returning(DriftSaga.drift_saga_id)
    )
    return result.scalar_one_or_none() is not None


Python