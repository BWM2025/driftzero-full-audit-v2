import pytest

@pytest.mark.asyncio
async def test_quarantine_flow():
    pass


Python