import pytest
from httpx import AsyncClient
from api.main import app

@pytest.mark.asyncio
async def test_create_and_get_incident():
    async with AsyncClient(app=app, base_url="http://test") as client:
        # This would be expanded with real DB fixture in full suite
        response = await client.get("/drift-incidents/inc-123")
        assert response.status_code == 404 or response.status_code == 200


Python