import pytest
from core.cross_env.cross_env_service import CrossEnvService

@pytest.mark.asyncio
async def test_promote_saga():
    service = CrossEnvService()
    await service.promote_saga("saga-123", "staging")
    # Assert event published / new saga created in target env


Python