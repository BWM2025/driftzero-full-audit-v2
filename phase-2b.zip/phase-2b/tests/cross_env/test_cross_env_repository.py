import pytest
from core.cross_env.cross_env_repository import CrossEnvRepository
from core.cross_env.cross_env_models import CrossEnvPromotion

@pytest.mark.asyncio
async def test_create_and_retrieve_promotion(db_session):
    repo = CrossEnvRepository()
    promo = CrossEnvPromotion(
        saga_id="saga-999",
        from_env="dev",
        to_env="staging",
        status="IN_PROGRESS"
    )
    created = await repo.create_promotion(db_session, promo)
    retrieved = await repo.get_by_saga_id(db_session, "saga-999")
    assert len(retrieved) == 1
    assert retrieved[0].promotion_id == created.promotion_id


Python