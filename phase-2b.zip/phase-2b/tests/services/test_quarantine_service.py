import pytest
from services.quarantine_service import QuarantineService
from datetime import datetime, timedelta

@pytest.mark.asyncio
async def test_quarantine_expiry_calculation(db_session):
    service = QuarantineService()
    record = await service.create_quarantine(
        session=db_session,
        tenant_id="t1",
        environment_id="dev",
        dataset_id="users",
        incident_ids=["inc-1"]
    )
    assert record.expires_at > datetime.utcnow()


Python