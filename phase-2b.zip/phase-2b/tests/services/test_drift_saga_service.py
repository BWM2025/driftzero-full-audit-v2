import pytest
from services.drift_saga_service import DriftSagaService

@pytest.mark.asyncio
async def test_get_active_saga_exclusivity(db_session):
    service = DriftSagaService()
    saga1 = await service.create_saga(...)  # simplified
    saga2 = await service.get_active_for_dataset(...)
    assert saga2 is None  # only one active saga allowed


Python