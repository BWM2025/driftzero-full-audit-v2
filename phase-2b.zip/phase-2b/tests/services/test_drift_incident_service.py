import pytest
from services.drift_incident_service import DriftIncidentService
from models.drift_incident import DriftIncident
from datetime import datetime

@pytest.mark.asyncio
async def test_list_incidents_filtering(db_session):
    service = DriftIncidentService()
    # Seed data would be inserted via fixture
    incidents = await service.list_incidents(
        session=db_session,
        tenant_id="tenant-1",
        status="NEW"
    )
    assert all(i.status == "NEW" for i in incidents)


Python