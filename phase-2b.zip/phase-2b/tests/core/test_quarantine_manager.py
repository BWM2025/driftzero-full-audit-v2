import pytest
from core.quarantine.quarantine_manager import QuarantineManager

def test_should_quarantine_semantic_change():
    manager = QuarantineManager()
    incident = {"risk_level": "HIGH", "drift_type": "TYPE_CHANGE"}
    assert manager.should_quarantine(incident) is True


Python