import pytest
from core.classification.risk_classifier import RiskClassifier

def test_high_risk_ssn_column():
    classifier = RiskClassifier()
    incident = {"drift_type": "TYPE_CHANGE", "column": "ssn"}
    assert classifier.classify(incident) == "HIGH"

def test_low_risk_new_column():
    classifier = RiskClassifier()
    incident = {"drift_type": "NEW_COLUMN", "column": "new_field"}
    assert classifier.classify(incident) == "LOW"


Python