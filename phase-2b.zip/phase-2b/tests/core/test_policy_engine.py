import pytest
from core.policy.policy_engine import PolicyEngine

@pytest.mark.asyncio
async def test_auto_heal_low_risk():
    engine = PolicyEngine()
    decision = await engine.evaluate({"risk_level": "LOW"})
    assert decision["action"] == "AUTO_HEAL"
    assert decision["sandbox_required"] is False

@pytest.mark.asyncio
async def test_require_approval_high_risk():
    engine = PolicyEngine()
    decision = await engine.evaluate({"risk_level": "HIGH"})
    assert decision["action"] == "REQUIRE_APPROVAL"
    assert decision["canary_required"] is True


Python