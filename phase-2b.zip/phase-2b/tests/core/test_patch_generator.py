import pytest
from core.patch_generation.patch_generator import PatchGenerator

def test_generate_add_column_patch():
    generator = PatchGenerator()
    incidents = [{"drift_type": "NEW_COLUMN", "column": "email"}]
    patch = generator.generate_patch(incidents)
    assert any(a.action_type == "ADD_COLUMN" and a.column_name == "email" for a in patch.actions)


Python