from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime

class DriftIncidentSchema(BaseModel):
    incident_id: str
    tenant_id: str
    environment_id: str
    dataset_id: str
    drift_type: str
    risk_level: str
    dimension: str = "STRUCTURAL"
    raw_observation: Dict[str, Any]
    status: str = "NEW"
    created_at: datetime


Python