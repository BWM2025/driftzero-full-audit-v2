from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class PatchAction(BaseModel):
    action_type: str
    column_name: Optional[str]
    column_type: Optional[str]
    nullable: Optional[bool]
    default: Optional[Any]

class PatchManifestSchema(BaseModel):
    patch_manifest_id: str
    actions: List[PatchAction]
    compensation_ops: Optional[List[PatchAction]] = None
    version: int
    status: str


Python