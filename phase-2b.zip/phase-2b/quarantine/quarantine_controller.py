from fastapi import APIRouter, Depends
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session
from services.quarantine_service import QuarantineService
from models.quarantine_record import QuarantineRecordResponse

router = APIRouter(prefix="/quarantine", tags=["Quarantine"])

@router.get("/", response_model=List[QuarantineRecordResponse])
async def list_quarantines(
    tenant_id: str,
    environment_id: str,
    dataset_id: str,
    session: AsyncSession = Depends(get_session),
    service: QuarantineService = Depends()
):
    records = await service.list_quarantines_for_dataset(session, tenant_id, environment_id, dataset_id)
    return records


Python