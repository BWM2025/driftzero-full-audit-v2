from sqlalchemy import Column, String, BigInteger, JSON, DateTime, Enum as SQLEnum, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from datetime import datetime
import uuid
from enum import Enum as PyEnum
from db import Base

class QuarantineStatus(str, PyEnum):
    ACTIVE = "ACTIVE"
    REPLAYED = "REPLAYED"
    DISCARDED = "DISCARDED"

class QuarantineRecord(Base):
    __tablename__ = "quarantine_records"

    quarantine_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(UUID(as_uuid=True), nullable=False, index=True)
    environment_id = Column(String(64), nullable=False)
    dataset_id = Column(String(255), nullable=False)
    drift_saga_id = Column(UUID(as_uuid=True), ForeignKey("drift_sagas.drift_saga_id"))
    incident_ids = Column(ARRAY(UUID(as_uuid=True)))
    reason = Column(String)
    data_location = Column(String(512))
    volume_estimate = Column(BigInteger)
    status = Column(SQLEnum(QuarantineStatus), default=QuarantineStatus.ACTIVE)
    expires_at = Column(DateTime(timezone=True))
    replay_history = Column(JSON, default=list)
    created_at = Column(DateTime(timezone=True), default=datetime.utcnow)
    updated_at = Column(DateTime(timezone=True), default=datetime.utcnow, onupdate=datetime.utcnow)


Python