# API Reference

Base URL: `https://api.driftzero.yourcompany.com/v1`

All endpoints require Bearer token.

### GET /policies

List all policies.

### POST /policies

Create new policy.

Example: