# Security Whitepaper

## Zero PII Exfiltration Model

- Agent runs in customer VPC
- Only schema metadata sent to control plane
- All PII stays behind customer firewall
- End-to-end encryption in transit (TLS 1.3)

## Compliance

- SOC 2 Type II
- ISO 27001
- HIPAA eligible
- GDPR compliant

## Threat Model

See full threat model in appendix.