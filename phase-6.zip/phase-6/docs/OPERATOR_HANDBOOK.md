# Operator Handbook

## Daily Operations

- Monitor dashboard for active sagas
- Review pending approvals
- Check quarantine volume

## Incident Response

1. High-risk drift detected → auto-quarantined
2. On-call engineer reviews saga
3. Approve or reject patch
4. System auto-commits or rolls back

## Disaster Recovery

All state in PostgreSQL + Temporal — standard backup procedures apply.