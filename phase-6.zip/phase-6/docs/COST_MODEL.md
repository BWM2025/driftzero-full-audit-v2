# Cost Model

### Snowflake
- Storage: $23/TB/month
- Compute: $2/credit
- Dual-write rename: ~15 credits + temporary storage

### Databricks
- DBU: $0.55/hr
- Storage: $0.10/GB/month

### BigQuery
- Query: $6.25/TB processed
- Storage: $0.02/GB/month (active)

### Redshift
- Node-hour: $3.26/hr (ra3.4xlarge)
- Storage: $0.024/GB/month

Full cost estimation API available at `/cost/estimate`