# Enterprise SSO Setup

Supports SAML 2.0 and OIDC.

### Okta

1. Create SAML app
2. Set ACS URL: `https://app.driftzero.com/sso/saml/acs`
3. Enable SCIM provisioning

### Azure AD

1. Enterprise application → SSO → SAML
2. Identifier: `driftzero`
3. Reply URL: `https://app.driftzero.com/sso/saml/acs`

SCIM endpoint: `https://app.driftzero.com/scim/v2`