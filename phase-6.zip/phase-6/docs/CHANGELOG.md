# Changelog

## v1.0.0 — November 27, 2025

- Initial GA release
- Full multi-cloud support
- Terraform provider
- Air-gapped deployment
- Enterprise SSO + SCIM
- Cost estimation engine
- SIEM forwarding