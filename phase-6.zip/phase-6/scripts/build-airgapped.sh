#!/usr/bin/env bash
# DriftZero v1.0 GA — Air-gapped / Offline Installer Bundle Generator
# Fully self-contained, verifiable, enterprise-ready
# Idempotent — safe to re-run

set -euo pipefail

VERSION="${1:-1.0.0}"
BUILD_DATE="$(date -u +"%Y%m%dT%H%M%Z")"
BUNDLE_NAME="driftzero-airgapped-${VERSION}-${BUILD_DATE}"
BUNDLE_DIR="/tmp/${BUNDLE_NAME}"
ARTIFACTS="${BUNDLE_DIR}/artifacts}"
IMAGES="${BUNDLE_DIR}/images"
DOCS="${BUNDLE_DIR}/docs"
VERIFY_SCRIPT="${BUNDLE_DIR}/verify-bundle.sh"

echo "=== DriftZero Air-gapped Bundle Build ==="
echo "Version: ${VERSION} | Build: ${BUILD_DATE}"

rm -rf "${BUNDLE_DIR}"
mkdir -p "${ARTIFACTS}" "${IMAGES}" "${DOCS}"

echo "[1/6] Copying source code..."
cp -a . "${BUNDLE_DIR}/source"
find "${BUNDLE_DIR}/source" -type d -name "__pycache__" -exec rm -rf {} +
find "${BUNDLE_DIR}/source" -type d -name ".git" -exec rm -rf {} +
rm -rf "${BUNDLE_DIR}/source/.venv" "${BUNDLE_DIR}/source/node_modules"

echo "[2/6] Building & exporting Docker images..."
docker build -t driftzero/control-plane:${VERSION} .
docker build -t driftzero/agent:${VERSION} ./agent

docker save driftzero/control-plane:${VERSION} -o "${IMAGES}/control-plane.tar"
docker save driftzero/agent:${VERSION} -o "${IMAGES}/agent.tar"

echo "[3/6] Packaging Helm chart..."
helm package deploy/helm/driftzero-control-plane --destination "${ARTIFACTS}"
mv "${ARTIFACTS}"/driftzero-control-plane-*.tgz "${ARTIFACTS}/helm-chart.tgz"

echo "[4/6] Copying offline documentation..."
cp -r docs/* "${DOCS}/" 2>/dev/null || true
cp README.md LICENSE CHANGELOG.md "${DOCS}/"

echo "[5/6] Generating checksums & SBOM..."
cd "${BUNDLE_DIR}"
find . -type f -exec sha256sum {} \; > "${ARTIFACTS}/SHA256SUMS"
cd source && syft . -o cyclonedx-json > "../${ARTIFACTS}/sbom.cdx.json" || echo "syft not available — SBOM skipped"

echo "[6/6] Creating verification script..."
cat > "${VERIFY_SCRIPT}" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
echo "Verifying DriftZero air-gapped bundle..."
cd "$(dirname "$0")"
sha256sum -c artifacts/SHA256SUMS
echo "Checksums OK"
echo "Bundle verified — ready for offline deployment"
EOF
chmod +x "${VERIFY_SCRIPT}"

echo "Creating final tarball..."
cd /tmp
tar -czf "${BUNDLE_NAME}.tar.gz" "${BUNDLE_NAME}"

echo "=== SUCCESS ==="
echo "Air-gapped bundle: /tmp/${BUNDLE_NAME}.tar.gz"
echo "Size: $(du -h "${BUNDLE_NAME}.tar.gz" | cut -f1)"
echo "Verification: ./${BUNDLE_NAME}/verify-bundle.sh"