#!/usr/bin/env bash
#
# Generate a new Alembic migration with autogenerate + formatting
# Usage: ./scripts/generate-migration.sh "Add new column to policies table"
#

set -euo pipefail

MESSAGE="${1:-}"

if [[ -z "$MESSAGE" ]]; then
    echo "Error: Migration message is required"
    echo "Usage: $0 \"<migration message>\""
    exit 1
fi

echo "Generating migration: $MESSAGE"

# Generate the migration
alembic revision --autogenerate -m "$MESSAGE"

# Find the latest migration file
LATEST_MIGRATION=$(ls -t alembic/versions/*.py | head -n1)

echo "Formatting $LATEST_MIGRATION with black..."
black "$LATEST_MIGRATION"

echo ""
echo "Migration created: $LATEST_MIGRATION"
echo ""
echo "Next steps:"
echo "  1. Review the generated migration"
echo "  2. Test upgrade: alembic upgrade head"
echo "  3. Test downgrade: alembic downgrade -1"
echo "  4. Commit the migration file"
echo ""
echo "Done."