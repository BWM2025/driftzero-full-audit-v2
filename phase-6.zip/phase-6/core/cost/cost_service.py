from typing import Dict, Any
from .estimators.snowflake_cost import SnowflakeCostEstimator
from .estimators.databricks_cost import DatabricksCostEstimator
from .estimators.bigquery_cost import BigQueryCostEstimator
from .estimators.redshift_cost import RedshiftCostEstimator

class CostEstimationService:
    _estimators = {
        "snowflake": SnowflakeCostEstimator,
        "databricks": DatabricksCostEstimator,
        "bigquery": BigQueryCostEstimator,
        "redshift": RedshiftCostEstimator,
    }

    @classmethod
    def estimate(cls, platform: str, patch_manifest: Dict[str, Any], table_size_gb: float) -> Dict[str, Any]:
        estimator_class = cls._estimators.get(platform.lower())
        if not estimator_class:
            return {"error": f"Unsupported platform: {platform}"}
        return estimator_class.estimate(patch_manifest, table_size_gb)

    @classmethod
    def supported_platforms(cls) -> list[str]:
        return list(cls._estimators.keys())