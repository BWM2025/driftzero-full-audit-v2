from decimal import Decimal
from typing import Dict, Any

class BigQueryCostEstimator:
    QUERY_PER_TB = Decimal("6.25")
    STORAGE_ACTIVE_PER_GB_MONTH = Decimal("0.02")

    _TB_SCANNED_ESTIMATES = {
        "ADD_COLUMN": Decimal("0.01"),
        "ALTER_COLUMN_TYPE": Decimal("1.0"),
        "RENAME_COLUMN": Decimal("0.0"),
        "DROP_COLUMN": Decimal("1.0"),
        "ADD_CONSTRAINT": Decimal("1.0"),
        "default": Decimal("0.01")
    }

    @staticmethod
    def estimate(patch_manifest: Dict[str, Any], table_size_gb: float) -> Dict[str, Any]:
        size_tb = Decimal(str(table_size_gb)) / Decimal("1024")
        actions = patch_manifest.get("actions", [])

        total_tb_scanned = Decimal("0")
        breakdown = []

        for action in actions:
            action_type = action.get("action_type", "default")
            tb_scanned = BigQueryCostEstimator._TB_SCANNED_ESTIMATES.get(action_type, BigQueryCostEstimator._TB_SCANNED_ESTIMATES["default"])
            if tb_scanned > 0:
                tb_scanned *= size_tb
            total_tb_scanned += tb_scanned
            breakdown.append({"action": action_type, "tb_scanned": float(tb_scanned)})

        query_cost = total_tb_scanned * BigQueryCostEstimator.QUERY_PER_TB
        storage_monthly = Decimal(str(table_size_gb)) * BigQueryCostEstimator.STORAGE_ACTIVE_PER_GB_MONTH

        return {
            "platform": "bigquery",
            "table_size_tb": float(size_tb),
            "total_one_time_usd": float(query_cost),
            "storage_monthly_usd": float(storage_monthly),
            "tb_processed": float(total_tb_scanned),
            "breakdown": breakdown
        }