from decimal import Decimal
from typing import Dict, Any

class RedshiftCostEstimator:
    NODE_HOURLY = Decimal("3.26")
    STORAGE_PER_GB_MONTH = Decimal("0.024")

    _HOURS_ESTIMATES = {
        "ADD_COLUMN": Decimal("0.1"),
        "ALTER_COLUMN_TYPE": Decimal("2.0"),
        "RENAME_COLUMN": Decimal("3.0"),
        "DROP_COLUMN": Decimal("1.5"),
        "ADD_CONSTRAINT": Decimal("1.0"),
        "default": Decimal("0.1")
    }

    @staticmethod
    def estimate(patch_manifest: Dict[str, Any], table_size_gb: float) -> Dict[str, Any]:
        actions = patch_manifest.get("actions", [])
        total_hours = Decimal("0")
        breakdown = []

        for action in actions:
            action_type = action.get("action_type", "default")
            hours = RedshiftCostEstimator._HOURS_ESTIMATES.get(action_type, RedshiftCostEstimator._HOURS_ESTIMATES["default"])
            total_hours += hours
            breakdown.append({"action": action_type, "node_hours": float(hours)})

        compute_cost = total_hours * RedshiftCostEstimator.NODE_HOURLY
        storage_monthly = Decimal(str(table_size_gb)) * RedshiftCostEstimator.STORAGE_PER_GB_MONTH

        return {
            "platform": "redshift",
            "table_size_gb": float(table_size_gb),
            "total_one_time_usd": float(compute_cost),
            "storage_monthly_usd": float(storage_monthly),
            "node_hours": float(total_hours),
            "breakdown": breakdown
        }