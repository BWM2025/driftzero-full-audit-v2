from decimal import Decimal
from typing import Dict, Any

class DatabricksCostEstimator:
    DBU_PER_HOUR = Decimal("0.55")
    STORAGE_PER_GB_MONTH = Decimal("0.10")

    _DBU_ESTIMATES = {
        "ADD_COLUMN": Decimal("0.5"),
        "ALTER_COLUMN_TYPE": Decimal("5.0"),
        "RENAME_COLUMN": Decimal("8.0"),
        "DROP_COLUMN": Decimal("3.0"),
        "ADD_CONSTRAINT": Decimal("4.0"),
        "default": Decimal("0.5")
    }

    @staticmethod
    def estimate(patch_manifest: Dict[str, Any], table_size_gb: float) -> Dict[str, Any]:
        size_gb = Decimal(str(table_size_gb))
        actions = patch_manifest.get("actions", [])

        total_dbu = Decimal("0")
        storage_increase_gb = Decimal("0")
        breakdown = []

        for action in actions:
            action_type = action.get("action_type", "default")
            dbu = DatabricksCostEstimator._DBU_ESTIMATES.get(action_type, DatabricksCostEstimator._DBU_ESTIMATES["default"])

            if action_type in ("ALTER_COLUMN_TYPE", "DROP_COLUMN"):
                dbu += size_gb * Decimal("0.02")

            if action_type == "RENAME_COLUMN":
                storage_increase_gb += size_gb

            total_dbu += dbu
            breakdown.append({"action": action_type, "dbu": float(dbu)})

        cost_dbu = total_dbu * DatabricksCostEstimator.DBU_PER_HOUR
        storage_monthly = (size_gb + storage_increase_gb) * DatabricksCostEstimator.STORAGE_PER_GB_MONTH

        return {
            "platform": "databricks",
            "table_size_gb": float(size_gb),
            "total_one_time_usd": float(cost_dbu),
            "storage_monthly_usd": float(storage_monthly),
            "dbu_consumed": float(total_dbu),
            "temporary_storage_increase_gb": float(storage_increase_gb),
            "breakdown": breakdown
        }