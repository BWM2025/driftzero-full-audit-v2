from decimal import Decimal
from typing import Dict, Any

class SnowflakeCostEstimator:
    STORAGE_PER_TB_MONTH = Decimal("23.00")
    COMPUTE_PER_CREDIT = Decimal("2.00")

    _CREDIT_ESTIMATES = {
        "ADD_COLUMN": Decimal("0.05"),
        "ALTER_COLUMN_TYPE": Decimal("0.50"),
        "RENAME_COLUMN": Decimal("15.0"),
        "DROP_COLUMN": Decimal("0.10"),
        "ADD_CONSTRAINT": Decimal("0.20"),
        "RENAME_TABLE": Decimal("15.0"),
        "CREATE_TABLE_CLONE": Decimal("0.01"),
        "default": Decimal("0.05")
    }

    @staticmethod
    def estimate(patch_manifest: Dict[str, Any], table_size_gb: float) -> Dict[str, Any]:
        size_tb = Decimal(str(table_size_gb)) / Decimal("1024")
        actions = patch_manifest.get("actions", [])

        compute_credits = Decimal("0")
        storage_increase_tb = Decimal("0")
        breakdown = []

        for action in actions:
            action_type = action.get("action_type", "default")
            credits = SnowflakeCostEstimator._CREDIT_ESTIMATES.get(action_type, SnowflakeCostEstimator._CREDIT_ESTIMATES["default"])

            if action_type in ("ALTER_COLUMN_TYPE", "DROP_COLUMN", "ADD_CONSTRAINT"):
                credits *= size_tb

            if action_type == "RENAME_COLUMN":
                storage_increase_tb += size_tb

            compute_credits += credits
            breakdown.append({
                "action": action_type,
                "compute_credits": float(credits),
                "storage_increase_tb": float(storage_increase_tb)
            })

        compute_cost = compute_credits * SnowflakeCostEstimator.COMPUTE_PER_CREDIT
        storage_cost_monthly = (size_tb + storage_increase_tb) * SnowflakeCostEstimator.STORAGE_PER_TB_MONTH

        return {
            "platform": "snowflake",
            "table_size_tb": float(size_tb),
            "total_one_time_usd": float(compute_cost),
            "storage_monthly_usd": float(storage_cost_monthly),
            "compute_credits": float(compute_credits),
            "temporary_storage_increase_tb": float(storage_increase_tb),
            "breakdown": breakdown
        }