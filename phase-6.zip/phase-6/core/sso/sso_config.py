from pydantic import BaseSettings, AnyUrl, Field
from typing import Optional

class SSOConfig(BaseSettings):
    SAML_METADATA_URL: Optional[AnyUrl] = None
    SAML_ENTITY_ID: Optional[str] = None
    SAML_ACS_URL: Optional[AnyUrl] = None
    SAML_SP_CERT: Optional[str] = None
    SAML_SP_KEY: Optional[str] = None

    OIDC_CLIENT_ID: Optional[str] = None
    OIDC_CLIENT_SECRET: Optional[str] = None
    OIDC_ISSUER_URL: Optional[AnyUrl] = None
    OIDC_REDIRECT_URI: Optional[AnyUrl] = None

    MFA_ENFORCED: bool = False
    MFA_TOTP_ISSUER: str = "DriftZero"
    SCIM_ENABLED: bool = False
    SCIM_AUTH_TOKEN: Optional[str] = None

    class Config:
        env_file = ".env"
        case_sensitive = False

sso_config = SSOConfig()