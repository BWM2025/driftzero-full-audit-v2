from typing import Dict, Any, Optional
from fastapi import HTTPException
from core.auth.jwt_manager import JWTManager
from models.user import User
from sqlalchemy.ext.asyncio import AsyncSession
import uuid

class SSOService:
    async def upsert_user(
        self,
        session: AsyncSession,
        provider: str,
        external_id: str,
        email: str,
        name: Optional[str] = None,
        roles: Optional[list[str]] = None
    ) -> Dict[str, Any]:
        user = await User.get_by_external_id(session, external_id, provider)
        if not user:
            user = User(
                id=uuid.uuid4(),
                tenant_id="default",
                email=email,
                username=email.split("@")[0],
                password_hash="",
                roles=roles or ["viewer"],
                is_active=True,
                external_id=external_id,
                sso_provider=provider
            )
            session.add(user)
            await session.commit()
            await session.refresh(user)

        access = JWTManager.create_access_token(str(user.id), user.tenant_id, user.roles)
        refresh = JWTManager.create_refresh_token(str(user.id), user.tenant_id)
        return {
            "access_token": access,
            "refresh_token": refresh,
            "token_type": "bearer",
            "user_id": str(user.id),
            "email": user.email,
            "roles": user.roles
        }