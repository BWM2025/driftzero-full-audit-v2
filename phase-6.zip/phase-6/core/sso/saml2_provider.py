from onelogin.saml2.auth import OneLogin_Saml2_Auth
from fastapi import Request
from core.sso.sso_config import sso_config
import urllib.parse

class SAML2Provider:
    def _saml_settings(self) -> dict:
        return {
            "strict": True,
            "debug": False,
            "sp": {
                "entityId": sso_config.SAML_ENTITY_ID,
                "assertionConsumerService": {
                    "url": str(sso_config.SAML_ACS_URL),
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
                },
                "x509cert": sso_config.SAML_SP_CERT,
                "privateKey": sso_config.SAML_SP_KEY,
            },
            "idp": {
                "entityId": sso_config.SAML_METADATA_URL,
                "singleSignOnService": {"url": sso_config.SAML_METADATA_URL},
            },
        }

    def prepare_request(self, request: Request) -> dict:
        url = urllib.parse.urlparse(str(request.url))
        return {
            "https": "on" if request.headers.get("x-forwarded-proto") == "https" else "off",
            "http_host": request.headers.get("host"),
            "script_name": request.url.path,
            "get_data": dict(request.query_params),
            "post_data": dict(request.form()) if request.method == "POST" else {}
        }

    def auth(self, request: Request) -> OneLogin_Saml2_Auth:
        return OneLogin_Saml2_Auth(self.prepare_request(request), self._saml_settings())