from fastapi import APIRouter, Depends, HTTPException, Request
from typing import List, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_async_session
from models.user import User
from models.team import Team, TeamMembership
import uuid
from datetime import datetime

scim_router = APIRouter(prefix="/scim/v2")

@scim_router.post("/Users", status_code=201)
async def create_user(payload: Dict[str, Any], request: Request, db: AsyncSession = Depends(get_async_session)):
    email = next(e["value"] for e in payload.get("emails", []) if e.get("primary"))
    user = User(
        id=uuid.uuid4(),
        tenant_id="default",
        email=email,
        username=payload.get("userName", email.split("@")[0]),
        password_hash="",
        is_active=payload.get("active", True),
        external_id=payload.get("externalId"),
        sso_provider="scim"
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    base = str(request.base_url).rstrip("/")
    return {
        "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
        "id": str(user.id),
        "userName": user.email,
        "emails": [{"value": user.email, "primary": True}],
        "active": user.is_active,
        "meta": {
            "resourceType": "User",
            "created": datetime.utcnow().isoformat() + "Z",
            "lastModified": datetime.utcnow().isoformat() + "Z",
            "location": f"{base}/scim/v2/Users/{user.id}"
        }
    }