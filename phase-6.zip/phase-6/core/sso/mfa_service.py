from pyotp import TOTP
from typing import Optional
from models.user import User
from sqlalchemy.ext.asyncio import AsyncSession

class MFAService:
    def generate_totp_secret(self) -> str:
        return TOTP.random_base32()

    def verify_totp(self, secret: str, token: str) -> bool:
        return TOTP(secret).verify(token)

    def totp_uri(self, user: User, secret: str) -> str:
        from core.sso.sso_config import sso_config
        return TOTP(secret).provisioning_uri(name=user.email, issuer_name=sso_config.MFA_TOTP_ISSUER)

    async def enable_totp(self, session: AsyncSession, user_id: str, secret: str):
        user = await session.get(User, user_id)
        user.mfa_secret = secret
        user.mfa_enabled = True
        await session.commit()