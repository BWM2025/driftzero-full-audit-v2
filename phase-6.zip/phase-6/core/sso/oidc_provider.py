from authlib.integrations.starlette_client import OAuth
from fastapi import Request
from core.sso.sso_config import sso_config

class OIDCProvider:
    def __init__(self):
        self.oauth = OAuth()
        self.oauth.register(
            name="oidc",
            client_id=sso_config.OIDC_CLIENT_ID,
            client_secret=sso_config.OIDC_CLIENT_SECRET,
            server_metadata_url=f"{sso_config.OIDC_ISSUER_URL}/.well-known/openid-configuration",
            client_kwargs={"scope": "openid email profile"}
        )

    async def login(self, request: Request):
        redirect_uri = str(sso_config.OIDC_REDIRECT_URI)
        return await self.oauth.oidc.authorize_redirect(request, redirect_uri)

    async def callback(self, request: Request):
        token = await self.oauth.oidc.authorize_access_token(request)
        userinfo = token.get("userinfo") or await self.oauth.oidc.userinfo(token=token)
        return {
            "external_id": userinfo["sub"],
            "email": userinfo["email"],
            "name": userinfo.get("name"),
            "provider": "oidc"
        }