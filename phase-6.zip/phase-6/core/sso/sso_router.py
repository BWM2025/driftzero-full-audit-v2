from fastapi import APIRouter, Depends, Request
from core.sso.sso_service import SSOService
from core.sso.saml2_provider import SAML2Provider
from core.sso.oidc_provider import OIDCProvider
from core.sso.scim_server import scim_router
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_async_session

router = APIRouter(prefix="/sso", tags=["SSO"])

saml = SAML2Provider()
oidc = OIDCProvider()
service = SSOService()

@router.get("/saml/login")
async def saml_login(request: Request):
    auth = saml.auth(request)
    return {"url": auth.login()}

@router.post("/saml/acs")
async def saml_acs(request: Request, db: AsyncSession = Depends(get_async_session)):
    auth = saml.auth(request)
    auth.process_response()
    attrs = auth.get_attributes()
    email = attrs.get("email", [None])[0]
    external_id = attrs.get("uid", [None])[0] or email
    return await service.upsert_user(db, "saml", external_id, email)

@router.get("/oidc/login")
async def oidc_login(request: Request):
    return await oidc.login(request)

@router.get("/oidc/callback")
async def oidc_callback(request: Request, db: AsyncSession = Depends(get_async_session)):
    info = await oidc.callback(request)
    return await service.upsert_user(db, info["provider"], info["external_id"], info["email"], info.get("name"))

router.include_router(scim_router)