import asyncio
import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import aiohttp
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
from opentelemetry.trace import Span
from pydantic import BaseSettings, AnyHttpUrl, Field, validator

logger = logging.getLogger(__name__)

class SIEMConfig(BaseSettings):
    SIEM_PROVIDER: str = Field(default="", description="splunk | datadog | elastic")
    SPLUNK_HEC_URL: Optional[AnyHttpUrl] = None
    # pragma: allowlist secret
    SPLUNK_HEC_TOKEN: Optional[str] = None            # pragma: allowlist secret
    DATADOG_LOG_URL: Optional[AnyHttpUrl] = Field(default="https://http-intake.logs.datadoghq.com/api/v2/logs")
    DATADOG_API_KEY: Optional[str] = None             # pragma: allowlist secret
    ELASTIC_DATASTREAM_URL: Optional[AnyHttpUrl] = None
    ELASTIC_API_KEY: Optional[str] = None             # pragma: allowlist secret

    SIEM_BATCH_SIZE: int = Field(default=100, ge=1, le=1000)
    SIEM_FLUSH_INTERVAL: float = Field(default=5.0, ge=1.0, le=30.0)
    SIEM_RETRY_COUNT: int = Field(default=3, ge=0, le=10)
    SIEM_RETRY_BACKOFF: float = Field(default=1.0, ge=0.1)

    @validator("SIEM_PROVIDER")
    def validate_provider(cls, v: str) -> str:
        v = v.strip().lower()
        if v not in {"splunk", "datadog", "elastic", ""}:
            raise ValueError("SIEM_PROVIDER must be splunk, datadog, elastic or empty")
        return v

    class Config:
        env_file = ".env"
        case_sensitive = False

config = SIEMConfig()

class SIEMForwarder(SpanExporter):
    def __init__(self):
        self._session: Optional[aiohttp.ClientSession] = None
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=50_000)
        self._worker_task: Optional[asyncio.Task] = None
        self._batch: List[Dict[str, Any]] = []

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if not self._session or self._session.closed:
            timeout = aiohttp.ClientTimeout(total=15)
            self._session = aiohttp.ClientSession(timeout=timeout)
        return self._session

    async def _post_batch(self, payload: List[Dict[str, Any]]) -> bool:
        if not config.SIEM_PROVIDER:
            return True

        url: str = ""
        headers: Dict[str, str] = {}
        data: bytes = b""

        if config.SIEM_PROVIDER == "splunk" and config.SPLUNK_HEC_URL and config.SPLUNK_HEC_TOKEN:
            url = str(config.SPLUNK_HEC_URL)
            headers = {"Authorization": f"Splunk {config.SPLUNK_HEC_TOKEN}"}
            data = "\n".join(json.dumps(event) for event in payload).encode()

        elif config.SIEM_PROVIDER == "datadog" and config.DATADOG_API_KEY:
            url = config.DATADOG_LOG_URL or ""
            headers = {
                "Content-Type": "application/json",
                "DD-API-KEY": config.DATADOG_API_KEY
            }
            data = json.dumps(payload).encode()

        elif config.SIEM_PROVIDER == "elastic" and config.ELASTIC_DATASTREAM_URL and config.ELASTIC_API_KEY:
            url = str(config.ELASTIC_DATASTREAM_URL)
            headers = {
                "Authorization": f"ApiKey {config.ELASTIC_API_KEY}",
                "Content-Type": "application/x-ndjson"
            }
            data = "".join(f'{json.dumps(event)}\n' for event in payload).encode()

        else:
            logger.warning("SIEM provider misconfigured — skipping forward")
            return True

        session = await self._ensure_session()
        for attempt in range(config.SIEM_RETRY_COUNT + 1):
            try:
                async with session.post(url, data=data, headers=headers) as resp:
                    if resp.status < 300:
                        return True
                    text = await resp.text()
                    logger.error(f"SIEM forward failed ({resp.status}): {text}")
            except Exception as exc:
                logger.warning(f"SIEM forward attempt {attempt + 1} failed: {exc}")
                if attempt < config.SIEM_RETRY_COUNT:
                    await asyncio.sleep(config.SIEM_RETRY_BACKOFF * (2 ** attempt))
        return False

    async def _worker(self):
        while True:
            try:
                item = await asyncio.wait_for(self._queue.get(), timeout=config.SIEM_FLUSH_INTERVAL)
                self._batch.append(item)

                while len(self._batch) < config.SIEM_BATCH_SIZE and not self._queue.empty():
                    self._batch.append(self._queue.get_nowait())

                if len(self._batch) >= config.SIEM_BATCH_SIZE:
                    await self._post_batch(self._batch)
                    self._batch.clear()

            except asyncio.TimeoutError:
                if self._batch:
                    await self._post_batch(self._batch)
                    self._batch.clear()
            except Exception as exc:
                logger.exception(f"SIEM worker error: {exc}")

    def export(self, spans: List[Span]) -> SpanExportResult:
        if not config.SIEM_PROVIDER:
            return SpanExportResult.SUCCESS

        for span in spans:
            event = {
                "timestamp": datetime.utcnow().isoformat() + "Z",
                "trace_id": f"{span.context.trace_id:032x}",
                "span_id": f"{span.context.span_id:016x}",
                "parent_span_id": f"{span.parent.span_id:016x}" if span.parent else None,
                "name": span.name,
                "kind": str(span.kind),
                "status": span.status.status_code.name,
                "attributes": {k: v for k, v in span.attributes.items()} if span.attributes else {},
                "events": [
                    {"name": e.name, "timestamp": e.timestamp, "attributes": dict(e.attributes or {})}
                    for e in span.events
                ],
                "duration_ms": (span.end_time - span.start_time) / 1_000_000
            }
            try:
                self._queue.put_nowait(event)
            except asyncio.QueueFull:
                logger.warning("SIEM queue full — dropping span")

        if not self._worker_task or self._worker_task.done():
            self._worker_task = asyncio.create_task(self._worker())

        return SpanExportResult.SUCCESS

    def shutdown(self, timeout: Optional[int] = None) -> None:
        if self._worker_task:
            self._worker_task.cancel()
        if self._session:
            asyncio.create_task(self._session.close())

    def force_flush(self, timeout: Optional[int] = None) -> None:
        pass

siem_exporter = SIEMForwarder() if config.SIEM_PROVIDER else None