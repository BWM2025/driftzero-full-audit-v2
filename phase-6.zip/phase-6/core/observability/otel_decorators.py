from functools import wraps
from typing import Any, Callable, Dict, Optional
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from core.observability.tracer import tracer
import logging

logger = logging.getLogger(__name__)

def trace_saga_step(step_name: str) -> Callable:
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            saga_id = kwargs.get("saga_id") or (args[0].saga_id if args and hasattr(args[0], "saga_id") else "unknown")
            with tracer.start_as_current_span(f"saga.{step_name}") as span:
                span.set_attribute("saga.id", saga_id)
                span.set_attribute("saga.step", step_name)
                try:
                    result = await func(*args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as exc:
                    span.record_exception(exc)
                    span.set_status(Status(StatusCode.ERROR, str(exc)))
                    logger.exception("Saga step failed")
                    raise
        return wrapper if "async def" in str(func) else wraps(func)(lambda *a, **k: wrapper(*a, **k))
    return decorator

def trace_executor_action(platform: str) -> Callable:
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args, **kwargs):
            manifest = kwargs.get("patch_manifest", {})
            action = manifest.get("action_type", "unknown")
            with tracer.start_as_current_span(f"executor.{platform}.{action}") as span:
                span.set_attribute("executor.platform", platform)
                span.set_attribute("executor.action_type", action)
                try:
                    result = await func(*args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as exc:
                    span.record_exception(exc)
                    span.set_status(Status(StatusCode.ERROR, str(exc)))
                    raise
        return wrapper
    return decorator

def trace_policy_evaluation(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(self, incident: Dict[str, Any], *args, **kwargs):
        with tracer.start_as_current_span("policy.evaluate") as span:
            span.set_attribute("incident.id", incident.get("incident_id", "unknown"))
            span.set_attribute("incident.drift_type", incident.get("drift_type", "unknown"))
            try:
                result = func(self, incident, *args, **kwargs)
                span.set_status(Status(StatusCode.OK))
                return result
            except Exception as exc:
                span.record_exception(exc)
                span.set_status(Status(StatusCode.ERROR, str(exc)))
                raise
    return wrapper

class TraceContext:
    def __init__(self, name: str, attributes: Optional[Dict[str, Any]] = None):
        self.name = name
        self.attributes = attributes or {}

    def __enter__(self):
        self.span = tracer.start_span(self.name)
        for k, v in self.attributes.items():
            self.span.set_attribute(k, str(v))
        return self.span

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.span.set_status(Status(StatusCode.ERROR, str(exc_val)))
            self.span.record_exception(exc_val)
        else:
            self.span.set_status(Status(StatusCode.OK))
        self.span.end()
        return False