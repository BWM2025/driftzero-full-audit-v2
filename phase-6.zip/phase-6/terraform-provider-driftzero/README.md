# DriftZero Terraform Provider

The official Terraform provider for **DriftZero v1.0 GA** — the enterprise schema drift governance platform.

Enforce schema drift policies, assign approvers, and manage agent configurations declaratively across Snowflake, Databricks, BigQuery, Redshift and more.

## Features

- Full CRUD for `driftzero_policy`
- Manage approval workflows with `driftzero_approver_assignment`
- Configure agents with `driftzero_agent_config`
- Data source `driftzero_policies` for policy lookups

## Requirements

- Terraform >= 1.6.0
- DriftZero control plane v1.0+ (SaaS or self-hosted)

## Installation