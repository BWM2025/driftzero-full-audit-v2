from fastapi import APIRouter, HTTPException
from typing import Dict, Any
from pydantic import BaseModel
from core.cost.cost_service import CostEstimationService

router = APIRouter(prefix="/cost", tags=["Cost Estimation"])

class CostRequest(BaseModel):
    platform: str
    patch_manifest: Dict[str, Any]
    table_size_gb: float

class CostResponse(BaseModel):
    platform: str
    total_one_time_usd: float
    storage_monthly_usd: float
    breakdown: list[Dict[str, Any]]
    details: Dict[str, Any]

@router.post("/estimate", response_model=CostResponse)
async def estimate_cost(request: CostRequest):
    result = CostEstimationService.estimate(
        platform=request.platform,
        patch_manifest=request.patch_manifest.dict(),
        table_size_gb=request.table_size_gb
    )
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return CostResponse(**result)