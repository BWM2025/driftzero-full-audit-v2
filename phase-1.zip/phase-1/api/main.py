Python

import uuid
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from temporalio.client import Client as TemporalClient
from api.dependencies import get_db
from api.middleware.auth import enforce_tenant_and_actor
from api.routes import incidents, sagas, approval, health

app = FastAPI(
    title="DriftZero Control Plane API",
    version="3.3.0",
    description="Control Plane API for DriftZero v3.3",
)

app.include_router(health.router)
app.include_router(incidents.router, prefix="/tenants/{tenant_id}", dependencies=[Depends(enforce_tenant_and_actor)])
app.include_router(sagas.router, prefix="/tenants/{tenant_id}", dependencies=[Depends(enforce_tenant_and_actor)])
app.include_router(approval.router, prefix="/tenants/{tenant_id}", dependencies=[Depends(enforce_tenant_and_actor)])

@app.on_event("startup")
async def startup_event():
    app.state.temporal_client = await TemporalClient.connect("temporal:7233")
