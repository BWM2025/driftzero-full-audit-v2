Python

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from models.policy import Policy
from api.dependencies import get_db

router = APIRouter()

@router.get("/policies", response_model=List[Policy])
def list_policies(tenant_id: str, db: Session = Depends(get_db)):
    policies = db.query(Policy).all()
    return policies
