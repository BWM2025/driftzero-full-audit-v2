Python
Python

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from models.patch_manifest import PatchManifest
from api.dependencies import get_db

router = APIRouter()

@router.get("/patches", response_model=List[PatchManifest])
def list_patches(tenant_id: str, db: Session = Depends(get_db)):
    patches = db.query(PatchManifest).filter(PatchManifest.tenant_id == tenant_id).all()
    return patches

@router.get("/patches/{patch_manifest_id}", response_model=PatchManifest)
def get_patch(patch_manifest_id: uuid.UUID, tenant_id: str, db: Session = Depends(get_db)):
    patch = db.query(PatchManifest).filter(
        PatchManifest.patch_manifest_id == patch_manifest_id,
        PatchManifest.tenant_id == tenant_id
    ).first()
    if not patch:
        raise HTTPException(status_code=404, detail="Patch manifest not found")
    return patch
