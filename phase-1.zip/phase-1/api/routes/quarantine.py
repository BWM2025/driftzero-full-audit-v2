Python

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from models.quarantine_record import QuarantineRecord
from api.dependencies import get_db

router = APIRouter()

@router.get("/quarantine", response_model=List[QuarantineRecord])
def list_quarantine(tenant_id: str, db: Session = Depends(get_db)):
    records = db.query(QuarantineRecord).filter(QuarantineRecord.tenant_id == tenant_id).all()
    return records
