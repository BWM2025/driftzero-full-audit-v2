Python

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from models.drift_saga import DriftSaga
from api.dependencies import get_db

router = APIRouter()

@router.get("/sagas")
def list_sagas(tenant_id: str, db: Session = Depends(get_db)):
    return db.query(DriftSaga).filter(DriftSaga.tenant_id == tenant_id).all()

@router.get("/sagas/{drift_saga_id}")
def get_saga(drift_saga_id: uuid.UUID, tenant_id: str, db: Session = Depends(get_db)):
    saga = db.query(DriftSaga).filter(
        DriftSaga.drift_saga_id == drift_saga_id,
        DriftSaga.tenant_id == tenant_id
    ).first()
    if not saga:
        raise HTTPException(status_code=404, detail="Saga not found")
    return saga
