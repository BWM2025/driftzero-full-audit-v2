Python

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from models.drift_saga import DriftSaga, SagaStatus
from api.dependencies import get_db

router = APIRouter()

@router.post("/sagas/{drift_saga_id}/approve")
async def approve_saga(
    drift_saga_id: uuid.UUID,
    approved: bool,
    comment: str = "",
    tenant_id: str = "",
    db: Session = Depends(get_db)
):
    saga = db.query(DriftSaga).filter(
        DriftSaga.drift_saga_id == drift_saga_id,
        DriftSaga.tenant_id == tenant_id
    ).first()
    if not saga:
        raise HTTPException(status_code=404, detail="Saga not found")
    if saga.status != SagaStatus.IN_PROGRESS:
        raise HTTPException(status_code=400, detail="Saga not awaiting approval")

    client = app.state.temporal_client
    handle = client.get_workflow_handle("DriftSagaWorkflow", drift_saga_id.hex)
    await handle.signal("approval_signal", {"approved": approved, "comment": comment})

    return {"status": "approval recorded"}
