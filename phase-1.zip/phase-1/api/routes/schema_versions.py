Python

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from models.temporal_schema_version import TemporalSchemaVersion
from api.dependencies import get_db

router = APIRouter()

@router.get("/schema-versions", response_model=List[TemporalSchemaVersion])
def list_schema_versions(tenant_id: str, dataset_id: str = None, db: Session = Depends(get_db)):
    query = db.query(TemporalSchemaVersion).filter(TemporalSchemaVersion.tenant_id == tenant_id)
    if dataset_id:
        query = query.filter(TemporalSchemaVersion.dataset_id == dataset_id)
    return query.all()
