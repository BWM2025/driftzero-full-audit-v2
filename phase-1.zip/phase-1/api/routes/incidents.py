Python

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from models.drift_incident import DriftIncident
from api.dependencies import get_db

router = APIRouter()

@router.get("/incidents")
def list_incidents(tenant_id: str, db: Session = Depends(get_db)):
    incidents = db.query(DriftIncident).filter(DriftIncident.tenant_id == tenant_id).all()
    return incidents

@router.get("/incidents/{incident_id}")
def get_incident(incident_id: uuid.UUID, tenant_id: str, db: Session = Depends(get_db)):
    incident = db.query(DriftIncident).filter(
        DriftIncident.incident_id == incident_id,
        DriftIncident.tenant_id == tenant_id
    ).first()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    return incident
