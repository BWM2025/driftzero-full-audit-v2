Python

from fastapi import Request, HTTPException, Header
import jwt
from datetime import datetime, timezone


async def enforce_tenant_and_actor(
    request: Request,
    authorization: str = Header(..., alias="Authorization"),
    x_tenant_id: str = Header(..., alias="X-Tenant-ID"),
):
    try:
        token = authorization.split(" ")[1]
        payload = jwt.decode(token, request.app.state.JWT_SECRET, algorithms=["HS256"])

        if payload.get("exp", 0) < datetime.now(timezone.utc).timestamp():
            raise HTTPException(status_code=401, detail="Token expired")

        if payload.get("tenant_id") != x_tenant_id:
            raise HTTPException(status_code=403, detail="Tenant mismatch")

        request.state.tenant_id = x_tenant_id
        request.state.actor = payload.get("sub", "system")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
