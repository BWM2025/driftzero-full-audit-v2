```markdown
# DriftZero v3.3 — Packaging and Release

This document describes how to build a distributable package and prepare a release.

---

## 1. Release Artifacts

A typical release produces:

- Source archive (`driftzero-v3.3.0-src.tar.gz`)
- Control plane Docker image (`driftzero/control-plane:3.3.0`)
- Agent Docker image (`driftzero/agent:3.3.0`)
- Helm chart (`driftzero-control-plane-3.3.0.tgz`)
- Checksums file (`SHA256SUMS`)

---

## 2. Build Script

The repository includes:

- `scripts/release/build_release.sh`

Example usage:

```bash
chmod +x scripts/release/build_release.sh
scripts/release/build_release.sh 3.3.0


This script is responsible for:
	•	Creating a source tarball
	•	Building Docker images (if Docker is available)
	•	Generating checksums

3. Release Notes
Use the template:
	•	scripts/release/RELEASE_NOTES_TEMPLATE.md
Fill in:
	•	Version
	•	Date
	•	Summary
	•	Changes
	•	Known Issues
	•	Upgrade Notes

4. Tagging
Example git tagging:
text

git tag -a v3.3.0 -m "DriftZero v3.3.0"
git push origin v3.3.0



5. Delivering to a Customer
Options:
	•	Private git repository access
	•	Encrypted archive distributed over a secure channel
	•	Container registry access for images
Always include:
	•	Source archive
	•	README
	•	Docs in docs/
	•	Any environment-specific deployment notes
text
