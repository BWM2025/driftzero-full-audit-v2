```markdown
# DriftZero v3.3 — Operator Guide

This guide is for people operating DriftZero in staging or production.

---

## 1. Core Responsibilities

Operators are responsible for:

- Keeping the control plane healthy (API, DB, Kafka, Temporal).
- Ensuring agents are deployed and connected in each environment.
- Managing policies and reviewing sagas that require approval.
- Monitoring incidents, sagas, and quarantines.

---

## 2. Control Plane Health

### 2.1 Health Endpoint

- URL: `GET /health`

Example:

```bash
curl http://driftzero-api.yourdomain.com/health


Expected response:
JSON

{
  "status": "healthy",
  "timestamp": "2025-11-20T12:34:56+00:00",
  "version": "3.3.0"
}


If status is not healthy, investigate:
	•	Control-plane logs
	•	Database connectivity
	•	Kafka connectivity
	•	Temporal connectivity

3. Authentication and Tenants
All tenant-scoped endpoints require:
	•	Authorization: Bearer <JWT>
	•	X-Tenant-ID: <tenant_id>
JWT must contain a tenant_id claim matching X-Tenant-ID.

4. Monitoring Incidents and Sagas
4.1 List Incidents
text

GET /tenants/{tenant_id}/incidents


4.2 Inspect a Single Incident
text

GET /tenants/{tenant_id}/incidents/{incident_id}


Shows classification, risk level, and raw observation metadata.
4.3 List Sagas
text

GET /tenants/{tenant_id}/sagas


Key fields:
	•	status — IN_PROGRESS, COMMITTED, FAILED, COMPENSATED, CANCELLED
	•	incident_ids
	•	current_patch_manifest_id

5. Approving or Rejecting Sagas
Some policies use REQUIRE_APPROVAL. For those sagas:
Bash

POST /tenants/{tenant_id}/sagas/{drift_saga_id}/approve
Content-Type: application/json

{
  "approved": true,
  "comment": "Reviewed by on-call DBA"
}


Reject example:
JSON

{
  "approved": false,
  "comment": "Suspicious semantic drift, escalate"
}


Effects:
	•	Approved: workflow continues toward sandbox/canary/commit.
	•	Rejected: workflow transitions to a failed or compensated state, depending on design.

6. Agent Operations
See docs/AGENT_DEPLOYMENT.md and docs/AGENT_RUNBOOK.md for full details.
At a high level, operators should:
	•	Ensure one agent per environment (or per infra boundary) is running and healthy.
	•	Monitor connectivity to the control plane.
	•	Rotate any credentials or tokens used by the agent.

7. Quarantine Management
When drift cannot be safely auto-healed:
	•	A QuarantineRecord is created.
	•	Data location and replay history are stored.
Operators should:
	•	Track active quarantines using internal tools (future API/UI).
	•	Coordinate replay or manual fixes according to internal policies.

8. Upgrades
For Helm deployments:
Bash

helm upgrade --install driftzero driftzero/driftzero-control-plane \
  --namespace driftzero \
  -f values-prod.yaml


Checklist:
	1.	Backup the control-plane database.
	2.	Review changelog / release notes.
	3.	Apply the upgrade in staging first.
	4.	Verify:
	◦	/health
	◦	Sample incident / saga behavior
	◦	Agent connectivity
	5.	Roll out to production.

9. Logs and Observability
You should integrate:
	•	API logs (FastAPI / Uvicorn)
	•	Worker logs (Temporal worker)
	•	Agent logs
Into a central logging solution.
Operators should watch for:
	•	Repeated saga failures
	•	Frequent quarantines
	•	Slow sandbox or canary runs
text
