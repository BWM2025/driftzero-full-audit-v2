Markdown

# DriftZero v3.3 — Developer Onboarding

This document helps a new engineer get productive with the DriftZero control plane and agent.

---

## 1. Prerequisites

- Python 3.12
- Docker and docker-compose
- PostgreSQL 15+ (local or via Docker)
- Kafka (via Docker, already wired in `docker-compose.local.yml`)
- Temporal 1.25+ (via Docker, already wired)

---

## 2. Cloning the Repository

```bash
git clone <your-repo-url> driftzero
cd driftzero



3. Python Environment
Create a virtualenv (optional but recommended):
Bash

python3.12 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt



4. Local Stack (Docker Compose)
Run the full local stack:
Bash

docker compose -f docker-compose.local.yml up --build


This starts:
	•	postgres (database)
	•	temporal (workflow engine)
	•	kafka + zookeeper (events)
	•	driftzero-api (FastAPI control plane on http://localhost:8000)

5. Project Layout (High Level)
	•	api/ — FastAPI application, routes, middleware
	•	core/ — policy engine, patch engine, sandbox executor, saga locking
	•	models/ — SQLAlchemy ORM models
	•	temporal/ — activities and worker
	•	workflows/ — Temporal workflow definitions
	•	agent/ — gRPC agent implementation
	•	schemas/ — JSON Schema contracts
	•	proto/ — gRPC protobuf definitions
	•	deploy/ — Helm chart (control plane) and k8s manifests (agent)
	•	terraform/ — optional agent deployment module
	•	docs/ — documentation

6. Running the API Dev Server Manually
To run the API locally without Docker:
Bash

export DATABASE_URL=postgresql://postgres:secret@localhost:5432/driftzero
export JWT_SECRET=change-me-in-production
export KAFKA_BOOTSTRAP_SERVERS=localhost:9092
export TEMPORAL_ADDRESS=localhost:7233

uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload


Make sure PostgreSQL, Kafka, and Temporal are reachable.

7. Temporal Worker
From the project root:
Bash

python -m temporal.worker


This connects to Temporal and listens on driftzero-task-queue.

8. Agent Service
For local development:
Bash

python -m agent.main


Or via Docker:
Bash

cd agent
docker build -t driftzero/agent:3.3.0 .
docker run --rm -p 50051:50051 driftzero/agent:3.3.0



9. Coding Guidelines
	•	Keep business logic inside core/ whenever possible.
	•	Keep models, schemas, and contracts aligned:
	◦	models/ vs schemas/*.json vs openapi.yaml vs proto/.
	•	Avoid silent failures. Always log and propagate errors correctly.
	•	Prefer small, focused modules with tests.

10. Next Steps for Contributors
	1.	Review README.md and this onboarding guide.
	2.	Run the local stack with Docker.
	3.	Explore api/routes/ and core/ to understand the control flow.
	4.	Implement tests under test_harness/ as a major next step.
text

**BATCH 3 of 4 complete** — 10 files, 100% verbatim.

Say **NEXT BATCH** for the final 3 files (31–33).
