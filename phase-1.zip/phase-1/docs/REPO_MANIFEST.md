```markdown
# DriftZero v3.3 — Repository Manifest

This file summarizes the key directories and files included in the DriftZero v3.3 control-plane and agent repository.

For a detailed tree, see `README.md` under "Repository Structure".

---

## Top-Level

- `api/` — FastAPI control plane
- `agent/` — gRPC agent
- `core/` — policy, patch, sandbox, locking
- `models/` — ORM models
- `schemas/` — JSON Schemas
- `proto/` — Protobuf definitions
- `deploy/` — Helm chart (control plane), k8s manifests (agent)
- `terraform/` — example Terraform module for agent
- `scripts/` — release packaging tooling
- `test_harness/` — reserved for Deadly 10 tests
- `docs/` — documentation
- `Dockerfile` — control-plane container
- `agent/Dockerfile` — agent container
- `docker-compose.local.yml` — local stack
- `requirements.txt` — Python dependencies
- `.env.example` — sample environment file
- `README.md` — main readme
- `LICENSE` — license
- `.gitignore` — git ignore rules
