```markdown
# DriftZero Agent — Operator Runbook

Short, practical steps for on-call operators.

---

## 1. Check Agent Status

In Kubernetes:

```bash
kubectl get pods -l app=driftzero-agent -n driftzero


If pods are Running and not restarting repeatedly, the agent is likely healthy.

2. Basic Troubleshooting
2.1 Pod CrashLoopBackOff
Inspect logs:
Bash

kubectl logs <agent-pod-name> -n driftzero


Common issues:
	•	Misconfigured CONTROL_PLANE_ADDRESS
	•	Authentication problems
	•	Network connectivity issues

2.2 Agent Cannot Reach Control Plane
	•	Verify DNS for CONTROL_PLANE_ADDRESS.
	•	Confirm control plane service/ingress is reachable from the cluster.
	•	Check network policies / firewalls.

3. Configuration Changes
To add or change datasets monitored by the agent:
	1.	Edit the ConfigMap or environment variables in deploy/k8s/agent.yaml. 
	2.	Apply the change: Bash    kubectl apply -f deploy/k8s/agent.yaml   
	3.	Verify pods restart with the updated configuration. 

4. Scaling
To increase redundancy:
Bash

kubectl scale deployment driftzero-agent \
  -n driftzero \
  --replicas=3


Ensure the control plane can handle the increased load.

5. When to Escalate Internally
Escalate to an engineering contact if:
	•	Agent pods keep crashing after configuration checks.
	•	Large numbers of patch executions are failing.
	•	Frequent connectivity issues persist after network checks.
text
