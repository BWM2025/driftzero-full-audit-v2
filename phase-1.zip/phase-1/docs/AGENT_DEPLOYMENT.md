```markdown
# DriftZero Agent — Deployment Guide

This document describes how to deploy the DriftZero agent in a customer environment.

---

## 1. Purpose

The agent:

- Runs inside the customer network.
- Connects to underlying databases / warehouses.
- Reports schema snapshots to the control plane.
- Executes patches and manages sandbox datasets.

---

## 2. Configuration

Key settings (typically via environment variables):

- `CONTROL_PLANE_ADDRESS` — gRPC/HTTP endpoint for control plane.
- `AGENT_ID` — logical ID for this agent.
- `AGENT_ENVIRONMENT` — environment label (e.g., `prod`, `staging`).
- `AGENT_DATASETS` — comma-separated list of dataset identifiers or patterns.

These can be mounted via:

- Kubernetes `Secret` + `ConfigMap`
- Docker environment variables
- VM/systemd environment files

---

## 3. Docker Image

Build:

```bash
cd agent
docker build -t driftzero/agent:3.3.0 .


Run:
Bash

docker run --rm \
  -e CONTROL_PLANE_ADDRESS=driftzero-api.yourdomain.com:443 \
  -e AGENT_ID=agent-prod-1 \
  -e AGENT_ENVIRONMENT=prod \
  driftzero/agent:3.3.0



4. Kubernetes Deployment
See deploy/k8s/agent.yaml for:
	•	Deployment
	•	Service
	•	ConfigMap
	•	Secret
Apply:
Bash

kubectl apply -f deploy/k8s/agent.yaml


Update the file to reference your:
	•	Namespace
	•	Control plane endpoint
	•	Credentials

5. Terraform Module (Optional)
terraform/agent/main.tf provides an example of managing agent k8s resources via Terraform.
Configure:
	•	Kubernetes provider
	•	Namespace
	•	Agent image
	•	Environment variables and secrets

6. Health and Monitoring
Monitor:
	•	Pod status / restart count
	•	Logs for:
	◦	Connection errors
	◦	Patch execution failures
	◦	Snapshot reporting errors
Integrate logs into your standard logging stack.

7. Upgrades
To upgrade the agent image:
	1.	Build/push driftzero/agent:<new_version>.
	2.	Update:
	◦	deploy/k8s/agent.yaml
	◦	or Terraform variables
	3.	Apply changes.
	4.	Confirm:
	◦	Pods updated
	◦	No error bursts in logs
text
