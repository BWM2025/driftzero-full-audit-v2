Bash

#!/usr/bin/env bash
set -euo pipefail

VERSION="${1:-}"

if [[ -z "$VERSION" ]]; then
  echo "Usage: $0 <version>"
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
ARTIFACTS_DIR="${ROOT_DIR}/artifacts"
mkdir -p "${ARTIFACTS_DIR}"

echo "Building DriftZero release ${VERSION}"

cd "${ROOT_DIR}"

ARCHIVE_NAME="driftzero-v${VERSION}-src.tar.gz"
tar --exclude='.git' \
    --exclude='artifacts' \
    -czf "${ARTIFACTS_DIR}/${ARCHIVE_NAME}" .

if command -v docker >/dev/null 2>&1; then
  echo "Building Docker images..."

  docker build -t "driftzero/control-plane:${VERSION}" .
  docker build -t "driftzero/agent:${VERSION}" ./agent

  # docker push "driftzero/control-plane:${VERSION}"
  # docker push "driftzero/agent:${VERSION}"
fi

cd "${ARTIFACTS_DIR}"
sha256sum "${ARCHIVE_NAME}" > SHA256SUMS

echo "Artifacts written to: ${ARTIFACTS_DIR}"
echo "Done."
