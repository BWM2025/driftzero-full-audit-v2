Python
Python

from temporalio import activity
from sqlalchemy.orm import Session
from database import SessionLocal
from models.drift_incident import DriftIncident
from models.drift_saga import DriftSaga, SagaStatus
from models.patch_manifest import PatchManifest
from core.patch_engine.engine import PatchEngine
from core.policy.engine import PolicyEngine
from core.sandbox.executor import SandboxExecutor
from agent.client import AgentClient
from core.locking.saga_lock import SagaLockManager


@activity.defn
async def acquire_saga_lock(saga_id: str, tenant_id: str, environment_id: str, dataset_id: str) -> bool:
    db: Session = SessionLocal()
    try:
        return SagaLockManager.acquire_lock(db, saga_id, tenant_id, environment_id, dataset_id)
    finally:
        db.close()


@activity.defn
async def classify_incidents(saga_id: str, incident_ids: list[str]):
    db: Session = SessionLocal()
    try:
        incidents = db.query(DriftIncident).filter(DriftIncident.incident_id.in_(incident_ids)).all()
        return incidents
    finally:
        db.close()


@activity.defn
async def evaluate_policy(saga_id: str):
    db: Session = SessionLocal()
    try:
        saga = db.query(DriftSaga).filter(DriftSaga.drift_saga_id == saga_id).one()
        incident = db.query(DriftIncident).filter(DriftIncident.drift_saga_id == saga_id).first()
        return PolicyEngine.evaluate(incident, db)
    finally:
        db.close()


@activity.defn
async def generate_patch(saga_id: str, strategy_id: str):
    db: Session = SessionLocal()
    try:
        incidents = db.query(DriftIncident).filter(DriftIncident.drift_saga_id == saga_id).all()
        patch = PatchEngine.generate_patch(incidents, strategy_id)
        db.add(patch)
        db.commit()
        return patch
    finally:
        db.close()


@activity.defn
async def execute_sandbox(patch_manifest_id: str):
    db: Session = SessionLocal()
    agent = AgentClient("agent:50051")
    executor = SandboxExecutor(agent)
    try:
        patch = db.query(PatchManifest).filter(PatchManifest.patch_manifest_id == patch_manifest_id).one()
        result = await executor.execute(patch, {"row_limit": 10000})
        return result
    finally:
        db.close()


@activity.defn
async def execute_canary(patch_manifest_id: str):
    return {"passed": True}


@activity.defn
async def commit_patch(patch_manifest_id: str):
    db: Session = SessionLocal()
    try:
        patch = db.query(PatchManifest).filter(PatchManifest.patch_manifest_id == patch_manifest_id).one()
        patch.status = "COMMITTED"
        db.commit()
    finally:
        db.close()


@activity.defn
async def compensate_patch(saga_id: str):
    db: Session = SessionLocal()
    try:
        patch = db.query(PatchManifest).filter(PatchManifest.drift_saga_id == saga_id).first()
        if patch:
            patch.status = "COMPENSATED"
            db.commit()
    finally:
        db.close()


@activity.defn
async def finalize_saga(saga_id: str, status: str):
    db: Session = SessionLocal()
    try:
        saga = db.query(DriftSaga).filter(DriftSaga.drift_saga_id == saga_id).one()
        saga.status = SagaStatus(status)
        db.commit()
    finally:
        db.close()


@activity.defn
async def release_saga_lock(saga_id: str):
    pass
