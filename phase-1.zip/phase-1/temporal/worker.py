Python
Python

import asyncio
from temporalio.worker import Worker
from temporal.client import Client
from temporal.activities import activities

async def main():
    client = await Client.connect("temporal:7233")
    worker = Worker(
        client,
        task_queue="driftzero-task-queue",
        workflows=[DriftSagaWorkflow],
        activities=[
            acquire_saga_lock,
            classify_incidents,
            evaluate_policy,
            generate_patch,
            execute_sandbox,
            execute_canary,
            commit_patch,
            compensate_patch,
            finalize_saga,
            release_saga_lock,
        ],
    )
    print("Temporal worker started")
    await worker.run()


if __name__ == "__main__":
    asyncio.run(main())
