Python

import uuid
import enum
from datetime import datetime, timezone

from sqlalchemy import JSON, Column, DateTime, Enum, String, func
from sqlalchemy.dialects.postgresql import UUID

from .base import Base


class QuarantineStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    REPLAYED = "REPLAYED"
    DISCARDED = "DISCARDED"


class QuarantineRecord(Base):
    __tablename__ = "quarantine_records"

    quarantine_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(String(64), nullable=False)
    environment_id = Column(String(64), nullable=False)
    dataset_id = Column(String(256), nullable=False)
    drift_saga_id = Column(UUID(as_uuid=True), nullable=False)
    incident_ids = Column(JSON, nullable=False, default=list)
    data_location = Column(String, nullable=False)
    reason = Column(String, nullable=False)
    status = Column(Enum(QuarantineStatus), nullable=False, default=QuarantineStatus.ACTIVE)
    replay_history = Column(JSON, nullable=False, default=list)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
