Python

import uuid
import enum
from datetime import datetime, timezone

from sqlalchemy import JSON, Column, DateTime, Enum, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base


class PatchStatus(str, enum.Enum):
    PROPOSED = "PROPOSED"
    SANDBOX_RUNNING = "SANDBOX_RUNNING"
    SANDBOX_FAILED = "SANDBOX_FAILED"
    SANDBOX_PASSED = "SANDBOX_PASSED"
    CANARY_RUNNING = "CANARY_RUNNING"
    CANARY_FAILED = "CANARY_FAILED"
    CANARY_PASSED = "CANARY_PASSED"
    COMMITTED = "COMMITTED"
    COMPENSATION_RUNNING = "COMPENSATION_RUNNING"
    COMPENSATED = "COMPENSATED"
    ABORTED = "ABORTED"


class PatchManifest(Base):
    __tablename__ = "patch_manifests"

    patch_manifest_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    drift_saga_id = Column(UUID(as_uuid=True), nullable=False)
    tenant_id = Column(String(64), nullable=False)
    environment_id = Column(String(64), nullable=False)
    dataset_id = Column(String(256), nullable=False)
    version = Column(Integer, nullable=False, default=1)
    status = Column(Enum(PatchStatus), nullable=False, default=PatchStatus.PROPOSED)
    actions = Column(JSON, nullable=False, default=list)
    compensation_ops = Column(JSON, nullable=False, default=list)
    idempotency_key = Column(String(128), nullable=False, unique=True, index=True)
    preconditions = Column(JSON, nullable=False, default=dict)
    postconditions = Column(JSON, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    created_by = Column(String(128), nullable=False)

    saga = relationship("DriftSaga", back_populates="patch_manifests")
