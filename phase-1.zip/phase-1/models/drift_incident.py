Python

import uuid
import enum
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, Column, DateTime, Enum, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base


class DriftDimension(str, enum.Enum):
    STRUCTURAL = "STRUCTURAL"
    SEMANTIC = "SEMANTIC"
    CONFIGURATION = "CONFIGURATION"


class RiskLevel(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class IncidentStatus(str, enum.Enum):
    NEW = "NEW"
    ATTACHED_TO_SAGA = "ATTACHED_TO_SAGA"
    RESOLVED = "RESOLVED"
    IGNORED = "IGNORED"


class DriftIncident(Base):
    __tablename__ = "drift_incidents"

    incident_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(String(64), nullable=False, index=True)
    environment_id = Column(String(64), nullable=False, index=True)
    dataset_id = Column(String(256), nullable=False, index=True)

    detected_at = Column(DateTime(timezone=True), nullable=False, default=lambda: datetime.now(timezone.utc))
    detected_by = Column(String(128), nullable=False)

    dimension = Column(Enum(DriftDimension), nullable=False)
    drift_type = Column(String(64), nullable=False)
    risk_level = Column(Enum(RiskLevel), nullable=False)
    auto_heal_eligible = Column(Boolean, nullable=False, default=False)

    classification_reason = Column(String, nullable=False)
    raw_observation = Column(JSON, nullable=False)
    reference_version_id = Column(UUID(as_uuid=True), nullable=False)

    status = Column(Enum(IncidentStatus), nullable=False, default=IncidentStatus.NEW)
    drift_saga_id = Column(UUID(as_uuid=True), nullable=True)
    resolution_summary = Column(String, nullable=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    saga = relationship("DriftSaga", back_populates="incidents")
