Python

import uuid
from datetime import datetime, timezone

from sqlalchemy import JSON, Column, DateTime, String, Integer, func
from sqlalchemy.dialects.postgresql import UUID

from .base import Base


class TemporalSchemaVersion(Base):
    __tablename__ = "temporal_schema_versions"

    schema_version_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(String(64), nullable=False, index=True)
    environment_id = Column(String(64), nullable=False, index=True)
    dataset_id = Column(String(256), nullable=False, index=True)
    recorded_at = Column(DateTime(timezone=True), nullable=False, index=True)

    ddl_representation = Column(String, nullable=False)
    logical_schema = Column(JSON, nullable=False)
    constraints = Column(JSON, nullable=False, default=list)
    indexes = Column(JSON, nullable=False, default=list)
    config_snapshot = Column(JSON, nullable=False, default=dict)

    fingerprint = Column(String(64), nullable=False, index=True)
    prev_fingerprint = Column(String(64), nullable=True)

    row_count = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
