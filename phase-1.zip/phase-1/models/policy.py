Python

import uuid
import enum
from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, Column, DateTime, Enum, Integer, String, func
from sqlalchemy.dialects.postgresql import UUID

from .base import Base


class PolicyAction(str, enum.Enum):
    AUTO_HEAL = "AUTO_HEAL"
    AUTO_HEAL_WITH_STRATEGY = "AUTO_HEAL_WITH_STRATEGY"
    QUARANTINE = "QUARANTINE"
    BLOCK = "BLOCK"
    REQUIRE_APPROVAL = "REQUIRE_APPROVAL"
    OBSERVE_ONLY = "OBSERVE_ONLY"


class Policy(Base):
    __tablename__ = "policies"

    policy_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    version = Column(Integer, nullable=False)
    scope_pattern = Column(String(512), nullable=False)
    action = Column(Enum(PolicyAction), nullable=False)
    strategy_id = Column(String(64), nullable=True)
    sandbox_required = Column(Boolean, nullable=False, default=True)
    canary_required = Column(Boolean, nullable=False, default=False)
    conditions = Column(JSON, nullable=False)
    precedence = Column(Integer, nullable=False, default=100)
    enabled = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
