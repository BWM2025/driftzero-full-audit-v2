Python

import uuid
import enum
from datetime import datetime, timezone

from sqlalchemy import JSON, Column, DateTime, Enum, String, func, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from .base import Base


class SagaStatus(str, enum.Enum):
    IN_PROGRESS = "IN_PROGRESS"
    COMMITTED = "COMMITTED"
    COMPENSATED = "COMPENSATED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class DriftSaga(Base):
    __tablename__ = "drift_sagas"

    drift_saga_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tenant_id = Column(String(64), nullable=False, index=True)
    environment_id = Column(String(64), nullable=False, index=True)
    dataset_id = Column(String(256), nullable=False, index=True)
    status = Column(Enum(SagaStatus), nullable=False, default=SagaStatus.IN_PROGRESS)
    incident_ids = Column(JSON, nullable=False, default=list)
    current_patch_manifest_id = Column(UUID(as_uuid=True), nullable=True)
    locked_until = Column(DateTime(timezone=True), nullable=True)
    lock_heartbeat_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    saga_metadata = Column(JSON, nullable=False, default=dict)

    __table_args__ = (
        Index(
            "ix_active_saga_unique",
            "tenant_id",
            "environment_id",
            "dataset_id",
            postgresql_where=(status == SagaStatus.IN_PROGRESS),
            unique=True,
        ),
    )

    incidents = relationship("DriftIncident", back_populates="saga")
    patch_manifests = relationship("PatchManifest", back_populates="saga")
