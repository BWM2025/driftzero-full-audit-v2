Python

def test_06_sandbox_failure_compensates(db_session, sandbox_executor):
    sandbox_executor.force_failure = True
    incident = create_incident(drift_type="type_change", risk="HIGH")
    saga = run_saga(incident)
    assert saga.status == "COMPENSATED"
