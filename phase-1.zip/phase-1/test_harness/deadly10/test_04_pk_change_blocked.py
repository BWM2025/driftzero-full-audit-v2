Python

def test_04_pk_change_blocked(db_session):
    incident = create_incident(drift_type="constraint_change", details={"type": "PK"})
    policy = get_policy(incident)
    assert policy.action == "BLOCK"
