Python

def test_02_type_widening_requires_canary(db_session):
    mark_dataset_critical("payments")
    incident = create_incident(drift_type="type_change", risk="MEDIUM", details={"is_non_lossy_widening": True})
    policy = get_policy(incident)
    assert policy.canary_required is True
