Python

def test_01_additive_column_auto_healed(db_session):
    # Scenario: New nullable column on non-critical table
    incident = create_incident(drift_type="new_column", risk="LOW")
    saga = run_saga(incident)
    assert saga.status == "COMMITTED"
    assert has_action(saga.current_patch_manifest_id, "add_column")
