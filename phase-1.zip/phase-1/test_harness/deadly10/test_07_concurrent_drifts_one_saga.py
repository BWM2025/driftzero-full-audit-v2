Python

def test_07_concurrent_drifts_single_saga(db_session):
    dataset = "test.dataset"
    concurrent_create_incidents(dataset, 2)
    sagas = get_active_sagas(dataset)
    assert len(sagas) == 1
