Python

def test_03_string_to_int_quarantined(db_session):
    incident = create_incident(drift_type="type_change", risk="HIGH", dimension="SEMANTIC")
    policy = get_policy(incident)
    assert policy.action == "REQUIRE_APPROVAL"
    assert policy.strategy_id == "NO_AUTO_HEAL"
