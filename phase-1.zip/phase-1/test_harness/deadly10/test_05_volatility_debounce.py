Python

def test_05_noisy_field_debounced(db_session):
    for _ in range(5):
        create_incident(drift_type="new_column", dataset="temp")
        revert_schema("temp")
    assert incident_count("temp") == 0
