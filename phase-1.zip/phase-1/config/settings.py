Python

import os
from pydantic import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql://postgres:secret@postgres:5432/driftzero")
    JWT_SECRET: str = os.getenv("JWT_SECRET", "change-me-in-production")
    KAFKA_BOOTSTRAP_SERVERS: str = os.getenv("KAFKA_BOOTSTRAP_SERVERS", "kafka:9092")
    TEMPORAL_ADDRESS: str = os.getenv("TEMPORAL_ADDRESS", "temporal:7233")
    AGENT_ENDPOINT: str = os.getenv("AGENT_ENDPOINT", "agent:50051")

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
