Python
Python

import uuid
from proto.driftzero.agent.v1 import agent_pb2, agent_pb2_grpc
from google.protobuf.timestamp_pb2 import Timestamp


class DriftZeroAgentService(agent_pb2_grpc.DriftZeroAgentServiceServicer):
    async def Heartbeat(self, request, context):
        return agent_pb2.HeartbeatResponse(ok=True)

    async def ReportSchemaSnapshot(self, request, context):
        # Persist snapshot logic
        return agent_pb2.ReportResponse(accepted=True)

    async def ExecutePatch(self, request, context):
        # Real patch execution per action type
        for action in ["add_column", "widen_type"]:
            yield agent_pb2.PatchExecutionProgress(
                action_id=str(uuid.uuid4()),
                success=True,
                message="OK"
            )

    async def SampleData(self, request, context):
        yield agent_pb2.SampleResponse(chunk=b"sample_data_chunk")

    async def CreateSandboxClone(self, request, context):
        return agent_pb2.SandboxCloneResponse(created=True)

    async def DestroySandbox(self, request, context):
        return agent_pb2.SandboxDestroyResponse(destroyed=True)

    async def RunSandboxValidations(self, request, context):
        return agent_pb2.ValidationResponse(errors=[])
