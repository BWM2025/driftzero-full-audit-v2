Python
Python

import asyncio
import grpc
from concurrent import futures
from proto.driftzero.agent.v1 import agent_pb2_grpc
from agent.service import DriftZeroAgentService


async def serve():
    server = grpc.aio.server()
    agent_service = DriftZeroAgentService()
    agent_pb2_grpc.add_DriftZeroAgentServiceServicer_to_server(agent_service, server)
    listen_addr = "[::]:50051"
    server.add_insecure_port(listen_addr)
    print(f"Agent listening on {listen_addr}")
    await server.start()
    await server.wait_for_termination()


if __name__ == "__main__":
    asyncio.run(serve())
