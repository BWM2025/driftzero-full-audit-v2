Python

import grpc
import uuid
from proto.driftzero.agent.v1 import agent_pb2, agent_pb2_grpc
from google.protobuf.timestamp_pb2 import Timestamp


class AgentClient:
    def __init__(self, endpoint: str):
        self.channel = grpc.insecure_channel(endpoint)
        self.stub = agent_pb2_grpc.DriftZeroAgentServiceStub(self.channel)

    async def heartbeat(self, agent_id: str):
        request = agent_pb2.HeartbeatRequest(agent_id=agent_id, version="3.3.0")
        return await self.stub.Heartbeat(request)

    async def report_schema_snapshot(self, snapshot):
        request = agent_pb2.SchemaSnapshot(
            dataset_id=snapshot["dataset_id"],
            ddl=snapshot["ddl"],
            logical_schema_json=snapshot["logical_schema_json"],
            observed_at=Timestamp(seconds=int(snapshot["observed_at"].timestamp())),
            fingerprint=snapshot["fingerprint"],
        )
        return await self.stub.ReportSchemaSnapshot(request)

    async def execute_patch(self, patch_manifest_id: uuid.UUID, patch_json: bytes):
        request = agent_pb2.PatchExecutionRequest(
            patch_manifest_id=str(patch_manifest_id),
            patch_manifest_json=patch_json
        )
        async for progress in self.stub.ExecutePatch(request):
            yield progress

    async def create_sandbox_clone(self, source_dataset: str, sandbox_dataset: str, row_limit: int):
        request = agent_pb2.SandboxCloneRequest(
            source_dataset=source_dataset,
            sandbox_dataset=sandbox_dataset,
            row_limit=row_limit
        )
        return await self.stub.CreateSandboxClone(request)

    async def destroy_sandbox(self, sandbox_dataset: str):
        request = agent_pb2.SandboxDestroyRequest(sandbox_dataset=sandbox_dataset)
        return await self.stub.DestroySandbox(request)

    async def run_sandbox_validations(self, sandbox_dataset: str, sample_spec: dict):
        request = agent_pb2.ValidationRequest(sandbox_dataset=sandbox_dataset)
        return await self.stub.RunSandboxValidations(request)
