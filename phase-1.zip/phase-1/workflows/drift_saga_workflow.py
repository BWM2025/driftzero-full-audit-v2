Python

from temporalio import workflow
from datetime import timedelta
import uuid


@workflow.defn(name="DriftSagaWorkflow")
class DriftSagaWorkflow:
    @workflow.run
    async def run(self, tenant_id: str, environment_id: str, dataset_id: str, incident_ids: list[uuid.UUID]):
        saga_id = uuid.uuid4()

        locked = await workflow.execute_activity(
            "acquire_saga_lock",
            saga_id, tenant_id, environment_id, dataset_id,
            start_to_close_timeout=timedelta(seconds=30),
        )
        if not locked:
            raise RuntimeError("Failed to acquire saga lock – another saga active")

        try:
            await workflow.execute_activity("classify_incidents", saga_id, incident_ids, start_to_close_timeout=timedelta(minutes=2))
            policy = await workflow.execute_activity("evaluate_policy", saga_id, start_to_close_timeout=timedelta(seconds=30))
            patch = await workflow.execute_activity("generate_patch", saga_id, policy.strategy_id, start_to_close_timeout=timedelta(minutes=5))

            sandbox_result = await workflow.execute_activity("execute_sandbox", patch.patch_manifest_id, start_to_close_timeout=timedelta(minutes=10))
            if not sandbox_result.passed:
                raise RuntimeError("Sandbox validation failed")

            if policy.canary_required:
                canary_result = await workflow.execute_activity("execute_canary", patch.patch_manifest_id, start_to_close_timeout=timedelta(minutes=30))
                if not canary_result.passed:
                    raise RuntimeError("Canary failed")

            await workflow.execute_activity("commit_patch", patch.patch_manifest_id, start_to_close_timeout=timedelta(minutes=10))
            await workflow.execute_activity("finalize_saga", saga_id, "COMMITTED", start_to_close_timeout=timedelta(seconds=30))

        except Exception:
            await workflow.execute_activity("compensate_patch", saga_id, start_to_close_timeout=timedelta(minutes=10))
            await workflow.execute_activity("finalize_saga", saga_id, "COMPENSATED", start_to_close_timeout=timedelta(seconds=30))
            raise
        finally:
            await workflow.execute_activity("release_saga_lock", saga_id, start_to_close_timeout=time
