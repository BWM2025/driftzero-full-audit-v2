Python

import json
from aiokafka import AIOKafkaProducer
from events.event_envelope import EventEnvelope


class EventProducer:
    def __init__(self, bootstrap_servers: str = "kafka:9092", topic: str = "driftzero-events"):
        self.producer = AIOKafkaProducer(bootstrap_servers=bootstrap_servers)
        self.topic = topic

    async def start(self):
        await self.producer.start()

    async def stop(self):
        await self.producer.stop()

    async def publish(self, event_type: str, payload: dict, tenant_id: str, environment_id: str, dataset_id: str, drift_saga_id: str = None):
        envelope = EventEnvelope(
            event_type=event_type,
            tenant_id=tenant_id,
            environment_id=environment_id,
            dataset_id=dataset_id,
            drift_saga_id=drift_saga_id,
            producer="control-plane",
            payload=payload
        )
        await self.producer.send_and_wait(self.topic, envelope.json().encode("utf-8"))
