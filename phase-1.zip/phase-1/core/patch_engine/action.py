Python

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass(frozen=True)
class PatchAction:
    action_type: str
    column: Optional[str] = None
    new_column: Optional[str] = None
    type: Optional[str] = None
    from_type: Optional[str] = None
    to_type: Optional[str] = None
    nullable: Optional[bool] = None
    default: Optional[Any] = None
    transform_expression: Optional[str] = None
    backfill_expression: Optional[str] = None
    constraint_type: Optional[str] = None
    referenced_dataset: Optional[str] = None
    referenced_columns: Optional[list[str]] = None
    compensation_op: Optional["PatchAction"] = None
    idempotency_key: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}
