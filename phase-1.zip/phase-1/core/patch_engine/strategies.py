Python

from typing import List
from models.drift_incident import DriftIncident
from .action import PatchAction


class SafeAddColumn:
    @staticmethod
    def apply(incident: DriftIncident) -> List[PatchAction]:
        col = incident.raw_observation["new_column"]
        return [
            PatchAction(
                action_type="add_column",
                column=col["name"],
                type=col["type"],
                nullable=True,
                default=col.get("default"),
                idempotency_key=f"add_column_{col['name']}_{incident.incident_id}",
            )
        ]


class TypeWidening:
    @staticmethod
    def apply(incident: DriftIncident) -> List[PatchAction]:
        change = incident.raw_observation["type_change"]
        if not change.get("is_non_lossy_widening", False):
            raise ValueError("TYPE_WIDENING strategy invoked on lossy type change")
        return [
            PatchAction(
                action_type="widen_type",
                column=change["column"],
                from_type=change["from_type"],
                to_type=change["to_type"],
                idempotency_key=f"widen_type_{change['column']}_{incident.incident_id}",
            )
        ]


class ParallelTypedColumnMigration:
    @staticmethod
    def apply(incident: DriftIncident) -> List[PatchAction]:
        change = incident.raw_observation["type_change"]
        new_col = f"{change['column']}_new"
        return [
            PatchAction(
                action_type="add_parallel_typed_column",
                column=change["column"],
                new_column=new_col,
                type=change["to_type"],
                transform_expression=change["transform_sql"],
                idempotency_key=f"parallel_migration_{change['column']}_{incident.incident_id}",
            )
        ]


class SoftDeleteColumn:
    @staticmethod
    def apply(incident: DriftIncident) -> List[PatchAction]:
        col = incident.raw_observation["removed_column"]["name"]
        return [
            PatchAction(
                action_type="soft_delete_column",
                column=col,
                idempotency_key=f"soft_delete_{col}_{incident.incident_id}",
            )
        ]


class ConstraintAddition:
    @staticmethod
    def apply(incident: DriftIncident) -> List[PatchAction]:
        c = incident.raw_observation["new_constraint"]
        return [
            PatchAction(
                action_type="add_constraint",
                constraint_type=c["type"],
                columns=c["columns"],
                referenced_dataset=c.get("referenced_dataset"),
                referenced_columns=c.get("referenced_columns"),
                idempotency_key=f"add_constraint_{c.get('name', c['type'])}_{incident.incident_id}",
            )
        ]


class NoAutoHeal:
    @staticmethod
    def apply(incident: DriftIncident) -> List[PatchAction]:
        return []


STRATEGY_MAP = {
    "SAFE_ADD_COLUMN": SafeAddColumn,
    "TYPE_WIDENING": TypeWidening,
    "PARALLEL_TYPED_COLUMN_MIGRATION": ParallelTypedColumnMigration,
    "SOFT_DELETE_COLUMN": SoftDeleteColumn,
    "CONSTRAINT_ADDITION": ConstraintAddition,
    "NO_AUTO_HEAL": NoAutoHeal,
}
