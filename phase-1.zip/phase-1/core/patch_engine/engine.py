Python

import uuid
from typing import List

from models.drift_incident import DriftIncident
from models.patch_manifest import PatchManifest
from .strategies import STRATEGY_MAP


class PatchEngine:
    @staticmethod
    def generate_patch(incidents: List[DriftIncident], strategy_id: str) -> PatchManifest:
        if not incidents:
            raise ValueError("At least one incident required")

        if strategy_id not in STRATEGY_MAP:
            raise ValueError(f"Unsupported strategy: {strategy_id}")

        strategy = STRATEGY_MAP[strategy_id]
        actions = []
        for incident in incidents:
            actions.extend(strategy.apply(incident))

        return PatchManifest(
            drift_saga_id=incidents[0].drift_saga_id,
            tenant_id=incidents[0].tenant_id,
            environment_id=incidents[0].environment_id,
            dataset_id=incidents[0].dataset_id,
            actions=[a.to_dict() for a in actions],
            idempotency_key=f"patch_{uuid.uuid4().hex}",
            preconditions={"expected_fingerprint": incidents[0].raw_observation["previous_fingerprint"]},
            created_by="patch_engine",
        )
