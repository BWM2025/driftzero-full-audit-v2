Python

import asyncio
from dataclasses import dataclass
from typing import List, Dict

from models.patch_manifest import PatchManifest
from agent.client import AgentClient


@dataclass
class SandboxResult:
    passed: bool
    errors: List[str]
    metrics: Dict[str, int]


class SandboxExecutor:
    def __init__(self, agent_client: AgentClient):
        self.agent = agent_client

    async def execute(self, patch: PatchManifest, sample_spec: dict) -> SandboxResult:
        sandbox_dataset = f"{patch.dataset_id}_sandbox_{patch.patch_manifest_id.hex[:8]}"
        errors = []
        metrics = {"rows_processed": sample_spec.get("row_limit", 0), "conversions_failed": 0, "queries_failed": 0}

        try:
            await self.agent.create_sandbox_clone(patch.dataset_id, sandbox_dataset, sample_spec)

            for action_dict in patch.actions:
                success, msg = await self.agent.apply_patch_action(sandbox_dataset, action_dict)
                if not success:
                    errors.append(f"Action failed in sandbox: {action_dict['action_type']} {action_dict.get('column') or ''} — {msg}")
                    return SandboxResult(passed=False, errors=errors, metrics=metrics)

            validation_errors = await self.agent.run_sandbox_validations(sandbox_dataset, sample_spec)
            errors.extend(validation_errors)
            metrics["queries_failed"] = len(validation_errors)

            passed = len(errors) == 0
            return SandboxResult(passed=passed, errors=errors, metrics=metrics)

        except Exception as exc:
            errors.append(f"Sandbox execution exception: {str(exc)}")
            return SandboxResult(passed=False, errors=errors, metrics=metrics)
        finally:
            try:
                await self.agent.destroy_sandbox(sandbox_dataset)
            except Exception:
                pass  # best-effort cleanup
