Python

import re
import uuid
from typing import Optional

from sqlalchemy.orm import Session
from models.policy import Policy, PolicyAction


class PolicyEngine:
    @staticmethod
    def _matches_scope(dataset_id: str, pattern: str) -> bool:
        """Convert glob-like pattern to regex and match."""
        regex = "^" + re.escape(pattern).replace(r"\*", ".*").replace(r"\?", ".") + "$"
        return bool(re.match(regex, dataset_id))

    @staticmethod
    def evaluate(incident, db: Session) -> Policy:
        """Return the highest-precedence matching policy, or safe default."""
        policies = (
            db.query(Policy)
            .filter(Policy.enabled.is_(True))
            .order_by(Policy.precedence.asc())
            .all()
        )

        for policy in policies:
            if PolicyEngine._matches_scope(incident.dataset_id, policy.scope_pattern):
                return policy

        # Safe default policy when no match is found
        return Policy(
            policy_id=uuid.uuid4(),
            version=0,
            scope_pattern=".*",
            action=PolicyAction.REQUIRE_APPROVAL,
            strategy_id="NO_AUTO_HEAL",
            sandbox_required=True,
            canary_required=True,
            conditions={},
            precedence=999999,
            enabled=True,
        )
