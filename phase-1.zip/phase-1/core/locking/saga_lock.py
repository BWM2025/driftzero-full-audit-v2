Python

import uuid
from datetime import datetime, timezone, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import text


class SagaLockManager:
    LOCK_TIMEOUT = timedelta(minutes=15)

    @staticmethod
    def acquire_lock(db: Session, saga_id: uuid.UUID, tenant_id: str, env_id: str, dataset_id: str) -> bool:
        result = db.execute(
            text("""
                INSERT INTO saga_locks (drift_saga_id, tenant_id, environment_id, dataset_id, locked_until)
                VALUES (:saga_id, :tenant, :env, :dataset, :until)
                ON CONFLICT (tenant_id, environment_id, dataset_id) DO NOTHING
                RETURNING drift_saga_id
            """),
            {
                "saga_id": saga_id,
                "tenant": tenant_id,
                "env": env_id,
                "dataset": dataset_id,
                "until": datetime.now(timezone.utc) + SagaLockManager.LOCK_TIMEOUT,
            },
        )
        acquired = result.fetchone() is not None
        if acquired:
            db.commit()
        return acquired

    @staticmethod
    def extend_heartbeat(db: Session, saga_id: uuid.UUID):
        db.execute(
            text("""
                UPDATE saga_locks
                SET locked_until = :until
                WHERE drift_saga_id = :saga_id
            """),
            {"until": datetime.now(timezone.utc) + SagaLockManager.LOCK_TIMEOUT, "saga_id": saga_id},
        )
        db.commit()







BATCH 1 of 4 – 10 files, 100% verbatim, no changes
