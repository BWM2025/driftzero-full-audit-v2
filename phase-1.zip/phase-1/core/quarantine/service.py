Python

import uuid
import boto3
from datetime import datetime, timezone
from typing import List
from sqlalchemy.orm import Session
from models.quarantine import QuarantineRecord
from models.drift_saga import DriftSaga
from events.producer import EventProducer


class QuarantineService:
    def __init__(self, db: Session, s3_bucket: str, event_producer: EventProducer):
        self.db = db
        self.s3 = boto3.client("s3")
        self.bucket = s3_bucket
        self.events = event_producer

    def create_quarantine(self, saga_id: uuid.UUID, location: str, reason: str, incident_ids: List[uuid.UUID]):
        saga = self.db.query(DriftSaga).filter_by(drift_saga_id=saga_id).one()
        record = QuarantineRecord(
            quarantine_id=uuid.uuid4(),
            tenant_id=saga.tenant_id,
            environment_id=saga.environment_id,
            dataset_id=saga.dataset_id,
            drift_saga_id=saga_id,
            incident_ids=incident_ids,
            data_location=location,
            reason=reason,
            status="ACTIVE",
            created_at=datetime.now(timezone.utc),
        )
        self.db.add(record)
        self.db.commit()

        self.events.publish(
            "QuarantineCreated",
            payload={"quarantine_id": str(record.quarantine_id), "location": location},
            tenant_id=record.tenant_id,
            environment_id=record.environment_id,
            dataset_id=record.dataset_id,
        )

    async def replay(self, quarantine_id: uuid.UUID):
        record = self.db.query(QuarantineRecord).filter_by(quarantine_id=quarantine_id).one()
        if record.status != "ACTIVE":
            return

        try:
            self.s3.head_object(Bucket=self.bucket, Key=record.data_location.lstrip("/"))
        except self.s3.exceptions.ClientError:
            record.reason += " (source missing on replay)"
            record.status = "DISCARDED"
            self.db.commit()
            return

        new_location = f"replayed/{record.dataset_id}/{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        record.replay_history.append({
            "replayed_at": datetime.now(timezone.utc),
            "new_location": new_location,
            "records_processed": None
        })
        record.status = "REPLAYED"
        self.db.commit()

        self.events.publish(
            "QuarantineReplayed",
            payload={"quarantine_id": str(record.quarantine_id), "new_location": new_location},
            tenant_id=record.tenant_id,
            environment_id=record.environment_id,
            dataset_id=record.dataset_id,
        )
