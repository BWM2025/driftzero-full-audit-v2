```markdown
# DriftZero v3.3 — Schema Drift Zero

**Specification Date:** November 19, 2025  
**Version:** 3.3.0  

DriftZero is a schema drift governance platform that detects, classifies, contains, and automatically heals structural schema drift while enforcing strict containment of semantic and high-risk changes across heterogeneous data systems.

--- 

## Table of Contents

- [Executive Summary](#executive-summary)
- [Key System Guarantees](#key-system-guarantees)
- [Architecture Overview](#architecture-overview)
- [Core Concepts](#core-concepts)
- [Repository Structure](#repository-structure)
- [Local Quick Start](#local-quick-start)
- [Production Deployment](#production-deployment)
- [API Overview](#api-overview)
- [Operational Runbook](#operational-runbook)
- [Security & Access Model](#security--access-model)
- [Event Model](#event-model)
- [System Requirements](#system-requirements)
- [Testing — The Deadly 10 Harness](#testing--the-deadly-10-harness)
- [Support & Maintenance](#support--maintenance)
- [License](#license)

--- 

## Executive Summary

DriftZero reduces schema drift risk by providing deterministic, auditable, and reversible schema evolution across:

- Transactional databases  
- Data warehouses  
- Lakehouse formats  
- Streaming platforms  
- File-based sources  
- SaaS APIs  

It combines real-time detection, policy-driven decision making, sandbox validation, optional canary execution, and Temporal-based workflows.

--- 

## Key System Guarantees

| Guarantee                                         | Implementation                                 |
|--------------------------------------------------|-----------------------------------------------|
| ≥96% structural drift auto-healed (stable env)   | `PatchEngine` + `SandboxExecutor`             |
| 100% semantic / high-risk drift contained        | `PolicyEngine` + `QuarantineRecord`           |
| No silent auto-heal of semantic drift            | `NO_AUTO_HEAL` strategy + approval workflow   |
| Closed-loop execution (no fast-path bypass)      | `DriftSagaWorkflow` (Temporal)                |
| One active saga per dataset                      | `SagaLockManager` + partial unique index      |
| Idempotent, reversible patching                  | `PatchManifest.compensation_ops`              |
| No raw customer data exfiltration                | Agent runs in customer VPC                    |
| Tamper-evident audit trail (design-ready)        | Append-only audit log with hash chain design  |

--- 

## Architecture Overview

- **Control Plane**
  - FastAPI HTTP API
  - PostgreSQL for relational state
  - Temporal for workflows (`DriftSagaWorkflow`)
  - Kafka for events (`EventEnvelope`)

- **Data Plane**
  - Lightweight gRPC agent in customer VPC
  - Reports schema snapshots
  - Executes patch actions
  - Manages sandbox datasets

- **Core components**
  - `PolicyEngine` — selects actions (AUTO_HEAL / QUARANTINE / REQUIRE_APPROVAL / BLOCK)
  - `PatchEngine` — generates `PatchManifest` from `DriftIncident` sets
  - `SandboxExecutor` — runs patches against cloned datasets
  - `SagaLockManager` — enforces one active saga per (tenant, env, dataset)

--- 

## Core Concepts

| Concept              | Description |
|----------------------|-------------|
| **DriftIncident**    | A single detected schema drift event for a dataset. |
| **DriftSaga**        | The workflow that coordinates classification, patching, sandbox, canary, commit/compensate. |
| **PatchManifest**    | Declarative patch plan, idempotent and reversible (v1 JSON schema). |
| **Policy**           | Glob-based rules over dataset IDs selecting strategy and gates. |
| **QuarantineRecord** | Persistent record of quarantined data and replay history. |
| **TemporalSchemaVersion** | Point-in-time snapshot of schema structure and fingerprint. |
| **EventEnvelope**    | Canonical event wrapper for Kafka (`driftzero-events`). |

--- 

## Repository Structure

```text
.
├── api/                        # FastAPI control-plane application
├── agent/                      # gRPC agent (data-plane)
├── core/                       # Policy, patch, sandbox, locking engines
├── models/                     # SQLAlchemy ORM models
├── schemas/                    # JSON Schema contracts (v1)
├── proto/                      # Protobuf definitions
├── workflows/                  # DriftSagaWorkflow
├── temporal/                   # Activities & worker
├── events/                     # EventEnvelope + producer
├── openapi.yaml                # Control plane OpenAPI 3.1
├── deploy/helm/                # Production Helm chart
├── docker-compose.local.yml    # Local stack for dev/testing
├── Dockerfile                  # Control-plane container
├── requirements.txt
├── test_harness/deadly10/      # Chaos validation suite
├── README.md
└── LICENSE

License
DriftZero v3.3 — Proprietary License
Copyright © 2025 DriftZero Systems, Inc. All rights reserved.

This software and associated documentation are proprietary to DriftZero Systems, Inc.

Redistribution and use in source and binary forms, with or without modification,
are NOT permitted except with explicit written permission from DriftZero Systems, Inc.

No rights are granted to use DriftZero trademarks, logos, or branding except as
explicitly authorized in writing by DriftZero Systems, Inc.
