from datetime import datetime
from models.audit_log import AuditLog

class ApprovalAuditLogger:
    @staticmethod
    async def log_request(approval_id: str, requested_by: str):
        await AuditLog.create(
            event_type="APPROVAL_REQUESTED",
            entity_id=approval_id,
            actor=requested_by,
        )

    @staticmethod
    async def log_decision(approval_id: str, decision: str, actor: str, reason: str = None):
        await AuditLog.create(
            event_type=f"APPROVAL_{decision.upper()}",
            entity_id=approval_id,
            actor=actor,
            metadata={"reason": reason} if reason else None,
        )


Python