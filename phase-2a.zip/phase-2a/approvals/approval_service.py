from datetime import datetime
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from models.approval_record import ApprovalRecord, ApprovalStatus
from .approval_repository import ApprovalRepository
from .approval_rules import ApprovalRules

class ApprovalService:
    def __init__(self):
        self.repo = ApprovalRepository()

    async def request_approval(
        self,
        session: AsyncSession,
        saga_id: str,
        tenant_id: str,
        requested_by: str,
        metadata: Optional[dict] = None,
    ) -> ApprovalRecord:
        record = ApprovalRecord(
            saga_id=saga_id,
            tenant_id=tenant_id,
            requested_by=requested_by,
            status=ApprovalStatus.PENDING,
            metadata=metadata or {},
        )
        return await self.repo.create(session, record)

    async def approve(
        self,
        session: AsyncSession,
        approval_id: str,
        approved_by: str,
        reason: Optional[str] = None,
    ) -> ApprovalRecord:
        record = await self.repo.get_by_id(session, approval_id)
        record.status = ApprovalStatus.APPROVED
        record.approved_by = approved_by
        record.approved_at = datetime.utcnow()
        record.reason = reason
        return await self.repo.update(session, record)

    async def reject(
        self,
        session: AsyncSession,
        approval_id: str,
        rejected_by: str,
        reason: str,
    ) -> ApprovalRecord:
        record = await self.repo.get_by_id(session, approval_id)
        record.status = ApprovalStatus.REJECTED
        record.approved_by = rejected_by
        record.approved_at = datetime.utcnow()
        record.reason = reason
        return await self.repo.update(session, record)


Python