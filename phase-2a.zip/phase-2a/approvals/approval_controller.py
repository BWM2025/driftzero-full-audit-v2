from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session
from models.approval_record import ApprovalRecordResponse
from .approval_service import ApprovalService

router = APIRouter(prefix="/approvals", tags=["Approvals"])

@router.post("/{saga_id}/request", response_model=ApprovalRecordResponse)
async def request_approval(
    saga_id: str,
    tenant_id: str,
    requested_by: str,
    session: AsyncSession = Depends(get_session),
):
    service = ApprovalService()
    record = await service.request_approval(session, saga_id, tenant_id, requested_by)
    return record

@router.post("/{approval_id}/approve", response_model=ApprovalRecordResponse)
async def approve_request(
    approval_id: str,
    approved_by: str,
    session: AsyncSession = Depends(get_session),
):
    service = ApprovalService()
    return await service.approve(session, approval_id, approved_by)

@router.post("/{approval_id}/reject", response_model=ApprovalRecordResponse)
async def reject_request(
    approval_id: str,
    rejected_by: str,
    reason: str,
    session: AsyncSession = Depends(get_session),
):
    service = ApprovalService()
    return await service.reject(session, approval_id, rejected_by, reason)


Python