from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from models.approval_record import ApprovalRecord

class ApprovalRepository:
    async def create(self, session: AsyncSession, record: ApprovalRecord) -> ApprovalRecord:
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return record

    async def get_by_saga(self, session: AsyncSession, saga_id: str) -> Optional[ApprovalRecord]:
        result = await session.execute(select(ApprovalRecord).where(ApprovalRecord.saga_id == saga_id))
        return result.scalar_one_or_none()


Python