from typing import Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel

class ApprovalStatus(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"

class ApprovalRecord(BaseModel):
    approval_id: str
    saga_id: str
    tenant_id: str
    requested_by: str
    requested_at: datetime
    status: ApprovalStatus = ApprovalStatus.PENDING
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    reason: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

    class Config:
        from_attributes = True


Python