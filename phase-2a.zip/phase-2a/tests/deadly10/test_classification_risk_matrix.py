import pytest
from classification.risk_classifier import RiskClassifier

def test_high_risk_semantic_change():
    classifier = RiskClassifier()
    incident = {"drift_type": "TYPE_CHANGE", "column": "ssn"}
    assert classifier.classify(incident) == "HIGH"


Python