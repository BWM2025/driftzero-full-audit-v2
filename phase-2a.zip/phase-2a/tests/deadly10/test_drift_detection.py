import pytest
from detection.drift_detector import DriftDetector

@pytest.mark.asyncio
async def test_detect_column_removal():
    detector = DriftDetector()
    before = {"columns": [{"name": "id"}, {"name": "deleted_col"}]}
    after = {"columns": [{"name": "id"}]}
    incidents = await detector.detect("t1", "dev", "d1", before, after)
    assert any(i.drift_type == "REMOVED_COLUMN" for i in incidents)


Python