import pytest
from policy.policy_engine import PolicyEngine

@pytest.mark.asyncio
async def test_auto_heal_low_risk():
    engine = PolicyEngine()
    incident = {"risk_level": "LOW", "drift_type": "NEW_COLUMN"}
    decision = await engine.evaluate(incident)
    assert decision.action == "AUTO_HEAL"