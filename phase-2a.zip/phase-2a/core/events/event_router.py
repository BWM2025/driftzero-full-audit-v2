from typing import Callable
from .event_models import EventEnvelope

class EventRouter:
    def __init__(self):
        self.handlers: dict[str, Callable] = {}

    def register(self, event_type: str, handler: Callable):
        self.handlers[event_type] = handler

    async def route(self, event: EventEnvelope):
        handler = self.handlers.get(event.event_type)
        if handler:
            await handler(event)


JSON