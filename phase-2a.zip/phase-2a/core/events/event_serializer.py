import json
from datetime import datetime
from .event_models import EventEnvelope

class EventSerializer:
    @staticmethod
    def serialize(event: EventEnvelope) -> str:
        return event.json()

    @staticmethod
    def deserialize(data: str) -> EventEnvelope:
        return EventEnvelope.parse_raw(data)


Python