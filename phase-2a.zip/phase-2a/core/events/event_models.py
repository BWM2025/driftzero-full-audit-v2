from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime
a
class EventEnvelope(BaseModel):
    event_id: str
    event_type: str
    source: str
    timestamp: datetime
    tenant_id: str
    environment_id: str
    dataset_id: str
    payload: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None

class DriftDetectedEvent(BaseModel):
    incident_id: str
    drift_type: str
    risk_level: str
    schema_before: Dict[str, Any]
    schema_after: Dict[str, Any]
    detected_at: datetime


Python