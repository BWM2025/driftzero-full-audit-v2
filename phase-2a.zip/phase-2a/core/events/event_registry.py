from typing import Dict, Type
from .event_models import EventEnvelope

class EventRegistry:
    _registry: Dict[str, Type] = {}

    @classmethod
    def register(cls, event_type: str):
        def decorator(event_class):
            cls._registry[event_type] = event_class
            return event_class
        return decorator

    @classmethod
    def get_event_class(cls, event_type: str):
        return cls._registry.get(event_type)


Python