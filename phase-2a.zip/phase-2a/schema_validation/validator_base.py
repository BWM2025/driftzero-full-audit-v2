from abc import ABC, abstractmethod
from typing import Any, Dict, List

class ValidationError(Exception):
    def __init__(self, message: str, path: List[str] = None):
        self.message = message
        self.path = path or []
        super().__init__(self.message)

class ValidatorBase(ABC):
    @abstractmethod
    def validate(self, data: Dict[str, Any]) -> None:
        pass


Python