from jsonschema import Draft202012Validator

class Draft2020Adapter:
    @staticmethod
    def validate(schema: dict, instance: dict):
        validator = Draft202012Validator(schema)
        validator.validate(instance)


Python