from jsonschema import Draft202012Validator, ValidationError
from .event_schema_loader import EventSchemaLoader

class EventSchemaValidator:
    def __init__(self):
        self.loader = EventSchemaLoader()

    def validate(self, event_type: str, payload: dict):
        schema = self.loader.load(event_type)
        validator = Draft202012Validator(schema)
        errors = list(validator.iter_errors(payload))
        if errors:
            raise ValidationError(f"Event {event_type} validation failed: {errors[0].message}")


Python