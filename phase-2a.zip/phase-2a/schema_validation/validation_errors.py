from typing import List, Any

class ValidationError(Exception):
    def __init__(self, message: str, path: List[str] = None):
        self.message = message
        self.path = path or []
        super().__init__(f"Validation error at {'/'.join(map(str, path))}: {message}")

class SchemaValidationError(Exception):
    def __init__(self, errors: List[ValidationError]):
        self.errors = errors
        messages = "; ".join(str(e) for e in errors)
        super().__init__(f"Schema validation failed: {messages}")


Python