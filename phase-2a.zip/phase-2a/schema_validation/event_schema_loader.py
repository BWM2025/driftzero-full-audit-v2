import json
import os
from typing import Dict

class EventSchemaLoader:
    def __init__(self, schema_dir: str = "schemas/events"):
        self.schema_dir = schema_dir
        self.schemas = {}

    def load(self, event_type: str) -> Dict:
        if event_type not in self.schemas:
            path = os.path.join(self.schema_dir, f"{event_type}.json")
            with open(path) as f:
                self.schemas[event_type] = json.load(f)
        return self.schemas[event_type]


Python