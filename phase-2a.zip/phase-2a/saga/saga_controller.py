from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session
from models.drift_saga import DriftSagaResponse
from .saga_orchestrator import SagaOrchestrator

router = APIRouter(prefix="/sagas", tags=["Sagas"])

@router.post("/", response_model=DriftSagaResponse)
async def create_saga(
    request: dict,
    session: AsyncSession = Depends(get_session),
):
    orch = SagaOrchestrator()
    saga = await orch.create_saga(
        session,
        request["tenant_id"],
        request["environment_id"],
        request["dataset_id"],
        request["incident_ids"],
    )
    return saga


BATCH 4/5 COMPLETE
Say NEXT for Batch 5 (Files 37–44).
BATCH 5/5 — Files 37–44 — VERBATIM FROM YOUR ORIGINAL 44-FILE BASELINE
FINAL BATCH — COMPLETE
Python