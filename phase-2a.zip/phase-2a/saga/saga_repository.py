from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from models.drift_saga import DriftSaga

class SagaRepository:
    async def create(self, session: AsyncSession, saga: DriftSaga) -> DriftSaga:
        session.add(saga)
        await session.commit()
        await session.refresh(saga)
        return saga

    async def get_active_for_dataset(
        self, session: AsyncSession, tenant_id: str, env: str, dataset: str
    ) -> Optional[DriftSaga]:
        result = await session.execute(
            select(DriftSaga).where(
                (DriftSaga.tenant_id == tenant_id) &
                (DriftSaga.environment_id == env) &
                (DriftSaga.dataset_id == dataset) &
                (DriftSaga.status == "IN_PROGRESS")
            )
        )
        return result.scalar_one_or_none()


Python