class SagaProgressTracker:
    def __init__(self):
        self.steps = {
            "DETECT_DRIFT": False,
            "CLASSIFY_INCIDENTS": False,
            "EVALUATE_POLICY": False,
            "AWAIT_APPROVAL": False,
            "GENERATE_PATCH": False,
            "EXECUTE_SANDBOX": False,
            "EXECUTE_CANARY": False,
            "COMMIT_PATCH": False,
            "FINALIZE": False,
        }

    def mark_complete(self, step: str):
        if step in self.steps:
            self.steps[step] = True

    def is_complete(self) -> bool:
        return all(self.steps.values())


Python