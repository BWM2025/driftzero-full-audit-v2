from enum import Enum
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel

class SagaStatus(str, Enum):
    IN_PROGRESS = "IN_PROGRESS"
    COMMITTED = "COMMITTED"
    COMPENSATED = "COMPENSATED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

class DriftSaga(BaseModel):
    drift_saga_id: str
    tenant_id: str
    environment_id: str
    dataset_id: str
    status: SagaStatus
    incident_ids: List[str]
    patch_manifest_id: Optional[str] = None
    current_step: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    locked_until: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None

    class Config:
        from_attributes = True


Python