from datetime import datetime, timedelta
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from models.drift_saga import DriftSaga, SagaStatus
from .saga_repository import SagaRepository
from .saga_state_machine import STEP_SEQUENCE

class SagaOrchestrator:
    def __init__(self):
        self.repo = SagaRepository()

    async def create_saga(self, session: AsyncSession, tenant_id: str, env: str, dataset: str, incident_ids: List[str]) -> DriftSaga:
        saga = DriftSaga(
            tenant_id=tenant_id,
            environment_id=env,
            dataset_id=dataset,
            status=SagaStatus.IN_PROGRESS,
            incident_ids=incident_ids,
            current_step=STEP_SEQUENCE[0],
        )
        return await self.repo.create(session, saga)

    async def advance_step(self, session: AsyncSession, saga_id: str) -> DriftSaga:
        saga = await self.repo.get_by_id(session, saga_id)
        current_idx = STEP_SEQUENCE.index(saga.current_step)
        if current_idx + 1 < len(STEP_SEQUENCE):
            saga.current_step = STEP_SEQUENCE[current_idx + 1]
        else:
            saga.status = SagaStatus.COMMITTED
        return await self.repo.update(session, saga)


Python