class SagaException(Exception):
    pass

class SagaLockedError(SagaException):
    def __init__(self, dataset_id: str):
        super().__init__(f"Dataset {dataset_id} is currently locked by an active saga")

class SagaNotFoundError(SagaException):
    def __init__(self, saga_id: str):
        super().__init__(f"Saga {saga_id} not found")


Python