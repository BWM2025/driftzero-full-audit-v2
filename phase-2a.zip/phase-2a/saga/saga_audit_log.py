from datetime import datetime
from models.audit_log import AuditLog

class SagaAuditLogger:
    @staticmethod
    async def log_step(saga_id: str, step: str, status: str, details: dict = None):
        await AuditLog.create(
            event_type=f"SAGA_{step}_{status}",
            entity_id=saga_id,
            metadata=details or {},
        )


Python