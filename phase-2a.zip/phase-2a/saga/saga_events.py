from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime

class SagaEvent(BaseModel):
    event_id: str
    saga_id: str
    event_type: str
    timestamp: datetime
    payload: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None


Python