from typing import List

class QuarantineRules:
    @staticmethod
    def requires_quarantine(risk_level: str, lineage_critical: bool = False) -> bool:
        if risk_level == "HIGH":
            return True
        if risk_level == "MEDIUM" and lineage_critical:
            return True
        return False


Python