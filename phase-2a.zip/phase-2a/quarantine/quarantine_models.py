from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from enum import Enum

class QuarantineStatus(str, Enum):
    ACTIVE = "ACTIVE"
    "
    RELEASED = "RELEASED"
    EXPIRED = "EXPIRED"

class QuarantineRecord(BaseModel):
    quarantine_id: str
    tenant_id: str
    environment_id: str
    dataset_id: str
    incident_ids: List[str]
    reason: Optional[str] = None
    status: QuarantineStatus = QuarantineStatus.ACTIVE
    created_at: datetime
    updated_at: datetime
    expires_at: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None

    class Config:
        from_attributes = True


Python