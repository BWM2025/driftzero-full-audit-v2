from .quarantine_rules import QuarantineRules

class QuarantineEvaluator:
    @staticmethod
    def evaluate(risk_level: str, lineage_critical: bool = False, volatility_level: str = None) -> bool:
        if QuarantineRules.requires_quarantine(risk_level, lineage_critical):
            return True
        if volatility_level == "HIGH" and risk_level in ("MEDIUM", "HIGH"):
            return True
        return False


Python