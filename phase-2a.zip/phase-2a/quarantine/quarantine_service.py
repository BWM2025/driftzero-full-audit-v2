from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy.ext.asyncio import AsyncSession
from models.quarantine_record import QuarantineRecord, QuarantineStatus
from .quarantine_repository import QuarantineRepository, NotFoundError

class QuarantineService:
    def __init__(self):
        self.repo = QuarantineRepository()

    async def create_quarantine(
        self,
        session: AsyncSession,
        tenant_id: str,
        environment_id: str,
        dataset_id: str,
        incident_ids: List[str],
        reason: Optional[str] = None,
        expires_at: Optional[datetime] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> QuarantineRecord:
        record = QuarantineRecord(
            tenant_id=tenant_id,
            environment_id=environment_id,
            dataset_id=dataset_id,
            incident_ids=incident_ids,
            reason=reason,
            status=QuarantineStatus.ACTIVE,
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return await self.repo.create(session, record)

    async def release_quarantine(self, session: AsyncSession, tenant_id: str, quarantine_id: str) -> QuarantineRecord:
        record = await self.repo.get_by_id(session, tenant_id, quarantine_id)
        record.status = QuarantineStatus.RELEASED
        record.updated_at = datetime.utcnow()
        return await self.repo.update(session, record)


Python