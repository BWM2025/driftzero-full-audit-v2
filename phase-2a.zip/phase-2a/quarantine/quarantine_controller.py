from fastapi import APIRouter, Depends, HTTPException
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from api.dependencies import get_session
from models.quarantine_record import QuarantineRecordResponse
from quarantine.quarantine_service import QuarantineService

router = APIRouter(prefix="/quarantine", tags=["Quarantine"])

@router.get("/{quarantine_id}", response_model=QuarantineRecordResponse)
async def get_quarantine(quarantine_id: str, tenant_id: str, session: AsyncSession = Depends(get_session)):
    service = QuarantineService()
    try:
        return await service.get_quarantine(session, tenant_id, quarantine_id)
    except NotFoundError:
        raise HTTPException(status_code=404, detail="Quarantine not found")

@router.get("/dataset/{dataset_id}", response_model=List[QuarantineRecordResponse])
async def list_quarantines(dataset_id: str, tenant_id: str, environment_id: str, session: AsyncSession = Depends(get_session)):
    service = QuarantineService()
    return await service.list_for_dataset(session, tenant_id, environment_id, dataset_id)


Python