from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from models.quarantine_record import QuarantineRecord

class NotFoundError(Exception):
    pass

class QuarantineRepository:
    async def create(self, session: AsyncSession, record: QuarantineRecord) -> QuarantineRecord:
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return record

    async def get_by_id(self, session: AsyncSession, tenant_id: str, quarantine_id: str) -> QuarantineRecord:
        result = await session.execute(
            select(QuarantineRecord).where(
                and_(
                    QuarantineRecord.tenant_id == tenant_id,
                    QuarantineRecord.quarantine_id == quarantine_id,
                )
            )
        )
        record = result.scalar_one_or_none()
        if not record:
            raise NotFoundError()
        return record

    async def list_for_dataset(
        self,
        session: AsyncSession,
        tenant_id: str,
        environment_id: str,
        dataset_id: str,
    ) -> List[QuarantineRecord]:
        result = await session.execute(
            select(QuarantineRecord).where(
                and_(
                    QuarantineRecord.tenant_id == tenant_id,
                    QuarantineRecord.environment_id == environment_id,
                    QuarantineRecord.dataset_id == dataset_id,
                )
            )
        )
        return result.scalars().all()


Python