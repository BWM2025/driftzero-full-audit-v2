import { DriftRiskHeatmap } from '@/components/DriftHeatmap';

export default function PredictivePage() {
  const mockData = [
    { dataset: "users", day: "Mon", risk_score: 0.3 },
    { dataset: "orders", day: "Tue", risk_score: 0.8 },
    // ...
  ];

  return (
    <div>
      <h1>Predictive Drift Risk</h1>
      <DriftRiskHeatmap data={mockData} />
    </div>
  );
}


YAML