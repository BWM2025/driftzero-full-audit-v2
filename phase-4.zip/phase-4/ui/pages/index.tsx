import { useQuery } from '@tanstack/react-query';

export default function Home() {
  const { data } = useQuery(['health'], () => 
    fetch('/api/health').then(res => res.json())
  );

  return (
    <div className="p-8">
      <h1 className="text-4xl font-bold mb-8">DriftZero Operator Console</h1>
      <div className="grid grid-cols-4 gap-6">
        <div className="bg-blue-100 p-6 rounded">Drift Incidents: 12</div>
        <div className="bg-yellow-100 p-6 rounded">Active Sagas: 3</div>
        <div className="bg-red-100 p-6 rounded">High Risk: 1</div>
        <div className="bg-green-100 p-6 rounded">Auto-Healed: 47</div>
      </div>
    </div>
  );
}


tsx