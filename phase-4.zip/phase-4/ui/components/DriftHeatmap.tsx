import { ResponsiveContainer, Heatmap } from 'recharts';

export function DriftRiskHeatmap({ data }) {
  return (
    <ResponsiveContainer width="100%" height={400}>
      <Heatmap
        data={data}
        xAxis={{ dataKey: "dataset" }}
        yAxis={{ dataKey: "day" }}
        valueKey="risk_score"
        color={{ low: "#10b981", high: "#ef4444" }}
      />
    </ResponsiveContainer>
  );
}


tsx