import Link from 'next/link';

export default function Sidebar() {
  return (
    <div className="w-64 bg-gray-900 text-white h-screen p-6">
      <h1 className="text-2xl font-bold mb-10">DriftZero</h1>
      <nav className="space-y-4">
        <Link href="/" className="block py-2 px-4 rounded hover:bg-gray-700">Dashboard</Link>
        <Link href="/incidents" className="block py-2 px-4 rounded hover:bg-gray-700">Drift Incidents</Link>
        <Link href="/sagas" className="block py-2 px-4 rounded hover:bg-gray-700">Active Sagas</Link>
        <Link href="/predictive" className="block py-2 px-4 rounded hover:bg-gray-700">Predictive Risk</Link>
        <Link href="/quarantine" className="block py-2 px-4 rounded hover:bg-gray-700">Quarantine</Link>
        <Link href="/approvals" className="block py-2 px-4 rounded hover:bg-gray-700">Approvals</Link>
        <Link href="/cost" className="block py-2 px-4 rounded hover:bg-gray-700">Cost & Usage</Link>
      </nav>
    </div>
  );
}


tsx