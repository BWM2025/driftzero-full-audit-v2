import { useMutation, useQueryClient } from '@tanstack/react-query';

export function ApprovalQueue() {
  const queryClient = useQueryClient();
  const approve = useMutation(
    (id: string) => fetch(`/api/approvals/${id}/approve`, { method: 'POST' }),
    { onSuccess: () => queryClient.invalidateQueries(['approvals']) }
  );

  return (
    <div>
      <h2>Pending Approvals</h2>
      {/* list items with approve/reject buttons */}
    </div>
  );
}


YAML