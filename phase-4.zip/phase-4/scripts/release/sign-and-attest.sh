#!/usr/bin/env bash
set -euo pipefail

IMAGE=ghcr.io/driftzero/control-plane:v3.3.0

echo "Signing image..."
cosign sign --yes $IMAGE

echo "Generating and attaching SBOM..."
cosign attest --predicate sbom.json --type cyclonedx --yes $IMAGE

echo "Image signed and attested: $IMAGE"


YAML