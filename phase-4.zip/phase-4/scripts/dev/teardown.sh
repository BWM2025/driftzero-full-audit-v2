#!/usr/bin/env bash
kind delete cluster --name driftzero-dev
docker compose -f docker-compose.local.yml down -v


text