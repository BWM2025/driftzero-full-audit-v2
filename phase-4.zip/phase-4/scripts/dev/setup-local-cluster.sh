#!/usr/bin/env bash
set -euo pipefail

kind create cluster --name driftzero-dev
kubectl create namespace driftzero
kubectl apply -f deploy/k8s/
docker compose -f docker-compose.local.yml up -d
echo "Local cluster ready — API at http://localhost:8000"


YAML