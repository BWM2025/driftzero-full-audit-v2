from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from schemas.v1.governance import GovernanceEvaluateRequest, GovernanceResponse
from api.dependencies import get_async_session
from api.dependencies.rate_limiter import rate_limit_write
from core.governance.service import GovernanceService

router = APIRouter(prefix="/governance", tags=["Governance"])

@router.post("/evaluate", response_model=GovernanceResponse)
async def evaluate_governance(
    request: GovernanceEvaluateRequest,
    db: AsyncSession = Depends(get_async_session),
    _ = Depends(rate_limit_write()),
):
    service = GovernanceService(db)
    return await service.evaluate(request)
    return await service.evaluate(request)


Python