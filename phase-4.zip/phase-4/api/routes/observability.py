from fastapi import APIRouter
from core.observability.replay_buffer import replay_buffer

router = APIRouter(prefix="/observability", tags=["Observability"])

@router.get("/events/replay")
async def replay_events():
    return {"events": replay_buffer.get_all()}


Python