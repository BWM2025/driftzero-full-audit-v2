import structlog
import logging

def configure_structlog():
    structlog.configure(
        processors=[
            structlog.processors.JSONRenderer()
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
    )
    logging.basicConfig(
        format="%(message)s",
        level=logging.INFO,
    )
    print("[LOGGING] Structured JSON logging enabled")


Python