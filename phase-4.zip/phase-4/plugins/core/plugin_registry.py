from typing import Dict
from .plugin_base import DriftZeroPlugin

class PluginRegistry:
    _plugins: Dict[str, DriftZeroPlugin] = {}

    @classmethod
    def register(cls, plugin: DriftZeroPlugin):
        key = f"{plugin.name()}-{plugin.version()}"
        cls._plugins[key] = plugin

    @classmethod
    def get_all(cls) -> list[DriftZeroPlugin]:
        return list(cls._plugins.values())


Batch 2/14 complete
10 files delivered 100% verbatim.
Please reply “BATCH 3/14” for the next 10 files.
We are locked in and moving fast.
────────────────────────────────────────
BATCH 3/14 (Files 215–224)
────────────────────────────────────────
Python