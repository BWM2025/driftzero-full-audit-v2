import importlib
import pkgutil
from .plugin_registry import PluginRegistry

def auto_discover_plugins():
    import plugins.sector as sector_pkg
    for _, module_name, _ in pkgutil.iter_modules(sector_pkg.__path__):
        try:
            module = importlib.import_module(f"plugins.sector.{module_name}")
            # Expect each module to register itself at import time
            print(f"Loaded plugin module: {module_name}")
        except Exception as e:
            print(f"Failed to load plugin {module_name}: {e}")


Python