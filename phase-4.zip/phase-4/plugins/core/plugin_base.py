from abc import ABC, abstractmethod
from typing import Any, Dict

class DriftZeroPlugin(ABC):
    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def version(self) -> str:
        pass

    @abstractmethod
    def capabilities(self) -> list[str]:
        """Return list like ['policy_evaluation', 'schema_validation', 'cost_calculation']"""
        pass

    @abstractmethod
    async def run(self, capability: str, context: Dict, payload: Any) -> Any:
        pass


Python