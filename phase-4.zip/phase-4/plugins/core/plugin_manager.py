from typing import List, Dict, Any
from .plugin_registry import PluginRegistry
from .plugin_base import DriftZeroPlugin

class PluginManager:
    def __init__(self):
        self.plugins = PluginRegistry.get_all()

    async def execute_capability(self, capability: str, context: Dict, payload: Any) -> List[Any]:
        results = []
        for plugin in self.plugins:
            if capability in plugin.capabilities():
                try:
                    result = await plugin.run(capability, context, payload)
                    results.append({"plugin": plugin.name(), "result": result})
                except Exception as e:
                    results.append({"plugin": plugin.name(), "error": str(e)})
        return results


Python