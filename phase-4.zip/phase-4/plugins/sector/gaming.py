from plugins.core.plugin_base import DriftZeroPlugin

class GamingSectorPlugin(DriftZeroPlugin):
    def name(self) -> str:
        return "gaming-sector"

    def version(self) -> str:
        return "1.0.0"

    def capabilities(self) -> list[str]:
        return ["player_id_protection"]

    async def run(self, capability: str, context: dict, payload: dict) -> dict:
        if payload.get("column") == "player_id":
            return {"anonymize": True}
        return {"anonymize": False}


Python