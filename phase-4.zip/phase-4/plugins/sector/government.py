from plugins.core.plugin_base import DriftZeroPlugin

class GovernmentSectorPlugin(DriftZeroPlugin):
    def name(self) -> str:
        return "government-sector"

    def version(self) -> str:
        return "1.0.0"

    def capabilities(self) -> list[str]:
        return ["data_residency_check"]

    async def run(self, capability: str, context: dict, payload: dict) -> dict:
        allowed_regions = context.get("allowed_regions", ["us-gov-west"])
        actual_region = payload.get("region")
        return {"compliant": actual_region in allowed_regions}


Python