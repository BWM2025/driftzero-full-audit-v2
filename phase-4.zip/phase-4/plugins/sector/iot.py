from plugins.core.plugin_base import DriftZeroPlugin

class IoTSectorPlugin(DriftZeroPlugin):
    def name(self) -> str:
        return "iot-sector"

    def version(self) -> str:
        return "1.0.0"

    "

    def capabilities(self) -> list[str]:
        return ["device_schema_validation"]

    async def run(self, capability: str, context: dict, payload: dict) -> dict:
        required_fields = {"device_id", "timestamp", "firmware_version"}
        actual = set(payload.get("columns", []))
        missing = required_fields - actual
        return {"valid": len(missing) == 0, "missing": list(missing)}


Python