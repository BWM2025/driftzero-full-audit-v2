from plugins.core.plugin_base import DriftZeroPlugin

class ScientificSectorPlugin(DriftZeroPlugin):
    def name(self) -> str:
        return "scientific-sector"

    def version(self) -> str:
        return "1.0.0"

    def capabilities(self) -> list[str]:
        return ["precision_validation"]

    async def run(self, capability: str, context: dict, payload: dict) -> dict:
        if payload.get("type") in {"float", "double"} and payload.get("precision") is None:
            return {"warning": "High-precision scientific data should declare precision"}
        return {"valid": True}


Python