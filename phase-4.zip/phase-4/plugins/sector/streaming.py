from plugins.core.plugin_base import DriftZeroPlugin

class StreamingSectorPlugin(DriftZeroPlugin):
    def name(self) -> str:
        return "streaming-sector"

    def version(self) -> str:
        return "1.0.0"

    def capabilities(self) -> list[str]:
        return ["schema_compatibility_check"]

    async def run(self, capability: str, context: dict, payload: dict) -> dict:
        from_to = payload.get("compatibility")
        if from_to == "BACKWARD":
            return {"allowed": True}
        return {"allowed": False, "required": "FULL"}


Python