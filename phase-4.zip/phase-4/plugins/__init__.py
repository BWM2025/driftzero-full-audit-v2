from .core.plugin_loader import auto_discover_plugins

# Auto-register all sector plugins on import
auto_discover_plugins()


Python