from temporalio import worker
from workflows.drift_saga_workflow import DriftSagaWorkflow
from activities import *

async def main():
    client = await Client.connect("localhost:7233")
    worker_instance = worker.Worker(
        client,
        task_queue="driftzero-task-queue",
        workflows=[DriftSagaWorkflow],
        activities=[
            detect_drift,
            classify_incident,
            generate_patch,
            execute_sandbox,
            execute_canary,
            commit_patch,
        ],
    )
    await worker_instance.run()


Python