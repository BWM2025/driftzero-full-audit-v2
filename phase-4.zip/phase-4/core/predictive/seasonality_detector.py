from typing import List
import numpy as np
from scipy.fft import fft

def detect_seasonality(series: List[float]) -> dict:
    N = len(series)
    if N < 2:
        return {"period": None, "strength": 0.0}
    freqs = np.abs(fft(series)[:N//2])
    freqs[0] = 0
    dominant_freq = np.argmax(freqs)
    period = N / dominant_freq if dominant_freq != 0 else None
    strength = freqs[dominant_freq] / freqs.sum()
    return {"period": int(period) if period else None, "strength": float(strength)}


Python