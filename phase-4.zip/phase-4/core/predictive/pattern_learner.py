from typing import List, Dict
from collections import Counter

def extract_patterns(series: List[float], window: int = 7) -> Dict[str, int]:
    patterns = []
    for i in range(len(series) - window + 1):
        segment = tuple(round(x, 3) for x in series[i:i+window])
        patterns.append(segment)
    return dict(Counter(patterns))


Python