from __future__ import annotations

def score_to_level(score: float) -> str:
    """Convert normalized risk score [0.0, 1.0] to risk band."""
    if score >= 0.9:
        return "CRITICAL"
    if score >= 0.7:
        return "HIGH"
    if score >= 0.4:
        return "MEDIUM"
    return "LOW"


Python