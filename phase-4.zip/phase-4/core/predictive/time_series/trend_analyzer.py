from typing import List, Optional
import numpy as np
from scipy.stats import linregress

def detect_trend(series: List[float], min_length: int = 10) -> Optional[dict]:
    if len(series) < min_length:
        return None
    x = np.arange(len(series))
    slope, intercept, r_value, _, _ = linregress(x, series)
    return {
        "slope": float(slope),
        "r_squared": float(r_value ** 2),
        "strength": "strong" if abs(r_value) > 0.7 else "moderate" if abs(r_value) > 0.4 else "weak"
    }


Python