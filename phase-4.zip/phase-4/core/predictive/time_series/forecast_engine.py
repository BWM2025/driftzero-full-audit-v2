from typing import List
from statsmodels.tsa.holtwinters import ExponentialSmoothing

def exponential_smoothing_forecast(series: List[float], steps: int = 12) -> List[float]:
    model = ExponentialSmoothing(series, trend="add", seasonal="add", seasonal_periods=12)
    fit = model.fit()
    return fit.forecast(steps).tolist()


Python