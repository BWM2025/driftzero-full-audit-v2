from typing import List
import ruptures as rpt

def detect_changepoints(series: List[float], max_points: int = 3) -> List[int]:
    if len(series) < 10:
        return []
    algo = rpt.Pelt(model="rbf").fit(np.array(series))
    return algo.predict(pen=10)[:-1]


Python