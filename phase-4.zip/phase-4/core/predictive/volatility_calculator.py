from typing import List
from datetime import datetime, timedelta

def calculate_volatility(incidents: List[dict], days: int = 30) -> float:
    cutoff = datetime.utcnow() - timedelta(days=days)
    recent = [i for i in incidents if i["detected_at"] > cutoff]
    if not recent:
        return 0.0
    return len(recent) / days


Python