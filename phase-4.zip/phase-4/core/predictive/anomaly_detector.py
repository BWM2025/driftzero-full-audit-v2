from typing import List
import numpy as np

def z_score_anomalies(series: List[float], threshold: float = 3.0) -> List[int]:
    arr = np.array(series)
    z = np.abs((arr - arr.mean()) / arr.std())
    return np.where(z > threshold)[0].tolist()


Python