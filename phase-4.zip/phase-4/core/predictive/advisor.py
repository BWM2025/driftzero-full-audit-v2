from __future__ import annotations
from typing import List, Dict, Any, Optional
from .insight_assembler import assemble_insights
from .risk_level_policy import score_to_level

class PredictiveDriftAdvisor:
    def __init__(self, model_version: str = "rules-only-v1"):
        self.model_version = model_version

    def build_summary(
        self,
        risk_scores: List[float] | None = None,
        top_contributing_features: List[str] | None = None,
        anomaly_series: List[float] | None = None,
        changepoint_series: List[float] | None = None,
        seasonality_series: List[float] | None = None,
        seasonality_period: int | None = None,
        change_intervals_minutes: List[float] | None = None,
        partition_scores: Dict[str, float] | None = None,
    ) -> Dict[str, Any]:
        avg_risk = sum(risk_scores or [0.0]) / max(1, len(risk_scores or [1]))
        risk_level = score_to_level(avg_risk)

        return {
            "model_version": self.model_version,
            "risk_score": round(avg_risk, 4),
            "risk_level": risk_level,
            "top_features": top_contributing_features or [],
            "anomalies_detected": len(anomaly_series or []),
            "changepoints": changepoint_series or [],
            "seasonality_period": seasonality_period,
            "forecast_next_30d": forecast[:30] if forecast else [],
            "recommendation": self._recommend_action(risk_level),
        }

    def _recommend_action(self, level: str) -> str:
        mapping = {
            "CRITICAL": "IMMEDIATE_QUARANTINE",
            "HIGH": "REQUIRE_APPROVAL_WITH_SANDBOX",
            "MEDIUM": "SANDBOX_ONLY",
            "LOW": "AUTO_HEAL",
        }
        return mapping.get(level, "MONITOR")


Python