from typing import List, Dict

def predict_schema_changes(history: List[Dict]) -> Dict:
    if not history:
        return {"probability": 0.0, "predicted_fields": []}
    recent = history[-10:]
    change_rate = sum(1 for i in range(1, len(recent)) if recent[i] != recent[i-1]) / max(1, len(recent)-1)
    return {"probability": min(1.0, change_rate * 3), "recent_change_rate": change_rate}


Python