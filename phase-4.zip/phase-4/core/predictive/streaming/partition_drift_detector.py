from typing import Dict

def detect_partition_drift(current: Dict[str, float], baseline: Dict[str, float]) -> float:
    if not baseline:
        return 0.0
    distances = [abs(current.get(k, 0) - b) for k, b in baseline.items()]
    return sum(distances) / len(distances) if distances else 0.0


Python