from fastapi import APIRouter, Depends
from typing import Dict
from .prediction_service import PredictionService

router = APIRouter(prefix="/predictive", tags=["Predictive"])

@router.get("/risk/{tenant_id}/{dataset_id}")
async def get_drift_prediction(tenant_id: str, dataset_id: str):
    service = PredictionService()
    return await service.predict_for_dataset(tenant_id, dataset_id)


Python