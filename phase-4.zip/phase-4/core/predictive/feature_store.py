from typing import Dict, List
from datetime import datetime
import uuid

class InMemoryFeatureStore:
    def __init__(self):
        self.store: Dict[str, dict] = {}

    def save_vector(self, tenant_id: str, dataset_id: str, features: dict):
        key = f"{tenant_id}:{dataset_id}"
        self.store[key] = {
            "features": features,
            "generated_at": datetime.utcnow(),
            "vector_id": str(uuid.uuid4())
        }

    def get_latest(self, tenant_id: str, dataset_id: str) -> dict | None:
        return self.store.get(f"{tenant_id}:{dataset_id}")


Python