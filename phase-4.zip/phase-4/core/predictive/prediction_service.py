from .advisor import PredictiveDriftAdvisor
from .feature_store import InMemoryFeatureStore

class PredictionService:
    def __init__(self):
        self.advisor = PredictiveDriftAdvisor()
        self.feature_store = InMemoryFeatureStore()

    async def predict_for_dataset(self, tenant_id: str, dataset_id: str) -> dict:
        vector = self.feature_store.get_latest(tenant_id, dataset_id)
        if not vector:
            return {"risk_level": "UNKNOWN", "risk_score": 0.5}
        # In real system we would run ML inference here
        summary = self.advisor.build_summary(risk_scores=[0.3, 0.4, 0.2])
        return summary


Python