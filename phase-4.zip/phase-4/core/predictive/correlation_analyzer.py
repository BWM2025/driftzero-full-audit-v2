from typing import Dict, List
import pandas as pd

def correlation_matrix(features: Dict[str, List[float]]) -> Dict[str, Dict[str, float]]:
    df = pd.DataFrame(features)
    return df.corr().to_dict()


Python