from __future__ import annotations
from typing import Dict, Any
from .insight_models import PredictiveSummary

def assemble_insights(
    drift_risk: dict,
    anomalies: list,
    changepoints: list,
    seasonality: dict | None,
    trend: dict | None,
    forecast: list,
    partition_scores: dict,
) -> PredictiveSummary:
    return PredictiveSummary(
        drift_risk=drift_risk,
        anomalies=anomalies,
        changepoints=changepoints,
        seasonality=seasonality,
        trend=trend,
        forecast=forecast,
        partition_scores=partition_scores,
    )


Python