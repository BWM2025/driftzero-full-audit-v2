from plugins.core.plugin_manager import PluginManager
from plugins.core.plugin_base import DriftZeroPlugin

class PluginGovernor:
    def __init__(self):
        self.manager = PluginManager()

    async def evaluate_with_plugins(self, tenant_id: str, environment_id: str, dataset_id: str, sector: str, payload: dict) -> dict:
        context = {
            "tenant_id": tenant_id,
            "environment_id": environment_id,
            "dataset_id": dataset_id,
            "sector": sector,
        }
        results = await self.manager.execute_capability("policy_evaluation", context, payload)
        # Aggregate results – first critical finding wins
        for res in results:
            if res.get("risk_level") == "CRITICAL":
                return res
        return {"risk_level": "LOW", "source": "fallback"}


Python