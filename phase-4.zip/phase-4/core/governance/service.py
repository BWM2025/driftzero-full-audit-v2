from .plugin_governor import PluginGovernor
from core.predictive.advisor import PredictiveDriftAdvisor

class GovernanceService:
    def __init__(self):
        self.predictive = PredictiveDriftAdvisor()
        self.plugins = PluginGovernor()

    async def evaluate(self, tenant_id: str, env: str, dataset: str, sector: str, change_payload: dict) -> dict:
        # 1. Predictive layer
        pred = {"risk_level": "MEDIUM"}  # placeholder

        # 2. Plugin layer
        plugin_result = await self.plugins.evaluate_with_plugins(tenant_id, env, dataset, sector, change_payload)

        # 3. Final decision (predictive + plugins + rules)
        final_risk = plugin_result.get("risk_level", pred["risk_level"])
        return {"recommended_action": self._map_to_action(final_risk), "details": plugin_result}

    def _map_to_action(self, level: str) -> str:
        return {
            "CRITICAL": "BLOCK",
            "HIGH": "REQUIRE_APPROVAL",
            "MEDIUM": "SANDBOX",
            "LOW": "AUTO_HEAL"
        }.get(level, "MONITOR")