from prometheus_client import Gauge

DRIFT_RISK_GAUGE = Gauge("driftzero_predictive_risk_score", "Current predictive risk", ["tenant_id", "dataset_id"])

def update_risk_metric(tenant_id: str, dataset_id: str, score: float):
    DRIFT_RISK_GAUGE.labels(tenant_id=tenant_id, dataset_id=dataset_id).set(score)


Python