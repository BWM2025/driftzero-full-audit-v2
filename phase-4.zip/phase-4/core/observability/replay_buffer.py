from collections import deque
from threading import RLock

class ReplayBuffer:
    def __init__(self, max_size: int = 10_000):
        self.max_size = max_size
        self.buffer = deque(maxlen=max_size)
        self._lock = RLock()

    def append(self, event: dict):
        with self._lock:
            self.buffer.append(event)

    def get_all(self) -> list[dict]:
        with self._lock:
            return list(self.buffer)

replay_buffer = ReplayBuffer()


Python