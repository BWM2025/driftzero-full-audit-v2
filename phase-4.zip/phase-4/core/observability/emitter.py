import time
from .replay_buffer import replay_buffer

def current_time_ms() -> int:
    return int(time.time() * 1000)

def emit_governance_decision(decision: dict):
    event = {
        "event_type": "governance_decision",
        "timestamp_ms": current_time_ms(),
        "tenant_id": decision["tenant_id"],
        "dataset_id": decision["dataset_id"],
        "risk_level": decision.get("risk_level"),
        "action": decision.get("recommended_action"),
        "source": "governor"
    }
    replay_buffer.append(event)


Python