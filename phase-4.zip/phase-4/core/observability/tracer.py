from opentelemetry import trace
tracer = trace.get_tracer(__name__)

def traced(fn):
    async def wrapper(*args, **kwargs):
        with tracer.start_as_current_span(fn.__name__):
            return await fn(*args, **kwargs)
    return wrapper


Python