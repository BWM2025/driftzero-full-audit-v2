from fastapi import Depends, HTTPException, Security
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer()

async def verify_jwt(credentials: HTTPAuthorizationCredentials = Security(security)):
    token = credentials.credentials
    # In real system: validate RS256 JWT and extract tenant_id
    if token != "valid-token":
        raise HTTPException(401, "Invalid token")
    return {"tenant_id": "demo-tenant"}


Python