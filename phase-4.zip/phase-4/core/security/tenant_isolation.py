from sqlalchemy import text

def enforce_row_level_security(session, tenant_id: str):
    session.execute(text(f"SET SESSION driftzero.tenant_id = '{tenant_id}'"))


Python