def calculate_monthly_cost(usage_stats: dict) -> float:
    base = 995.0
    per_dataset = 25.0
    datasets = usage_stats.get("active_datasets", 0)
    return base + (datasets * per_dataset)


Python