from collections import defaultdict
from datetime import datetime

class UsageTracker:
    def __init__(self):
        self.events = defaultdict(int)

    def record_drift_event(self, tenant_id: str):
        key = f"{tenant_id}:{datetime.utcnow().date()}"
        self.events[key] += 1


Python