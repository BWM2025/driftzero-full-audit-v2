import psutil
from datetime import datetime

def log_resource_usage():
    cpu = psutil.cpu_percent()
    mem = psutil.virtual_memory().percent
    print(f"[COST] CPU: {cpu}% MEM: {mem}% @ {datetime.utcnow()}")


Python