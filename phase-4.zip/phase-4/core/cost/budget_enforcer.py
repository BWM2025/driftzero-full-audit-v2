class BudgetEnforcer:
    def __init__(self, monthly_limit: float = 5000.0):
        self.limit = monthly_limit

    def check_budget(self, spent: float) -> str:
        if spent > self.limit * 0.9:
            return "WARNING"
        if spent > self.limit:
            return "BREACH"
        return "OK"


Python