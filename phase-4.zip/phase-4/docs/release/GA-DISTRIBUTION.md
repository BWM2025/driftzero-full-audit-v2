# DriftZero v3.3.0 — Distribution

- Container: ghcr.io/driftzero/control-plane:v3.3.0
- Agent: ghcr.io/driftzero/agent:v3.3.0
- SBOM + Cosign signature
- Helm chart v2 (coming Q2 2025)
- Full documentation bundle included


Markdown