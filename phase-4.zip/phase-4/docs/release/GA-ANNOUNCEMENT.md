# DriftZero v3.3.0 — Now Generally Available

After 18 months of development, DriftZero v3.3.0 is now Generally Available.

Key achievements:
• Predictive drift prevention (not just reaction)
• Full sector-aware governance via plugin framework
• Enterprise-grade operator UI
• Streaming platform support (Kafka)
• Cost transparency and chargeback
• Chaos-engineered resilience
• Signed, SBOM-attested container images

Get started today:
kubectl apply -f https://raw.githubusercontent.com/driftzero/deploy/main/v3.3.0.yaml


Markdown