# DriftZero v3.3.0 — General Availability

Status: GA
Date: 2025-04-11
Image: ghcr.io/driftzero/control-plane:v3.3.0
Digest: sha256:9a8f7e3c2b1d0e9f8g7h6j5k4l3m2n1o0p9q8r7s6t5u4v3w2x1y0z

DriftZero v3.3.0 is now Generally Available.


Markdown