# DriftZero v3.3 — Release Notes

GA: 2025-04-11
- Full plugin framework with 10 sector plugins
- Predictive + sector + policy orchestration
- Observability v2 with replay buffer
- Chaos-tested resilience
- Signed, SBOM-attested images
- Operator UI (React)
- Cost & quota management
- Streaming governance (Kafka)


Markdown