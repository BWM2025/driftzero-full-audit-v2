# DriftZero v3.3 — Deployment Topology

Control Plane (FastAPI + Postgres + Temporal + Kafka)
└── Multiple stateless pods behind HPA
    └── Observability v2 replay buffer per pod (ephemeral)

Data Plane
└── gRPC agent in customer VPC (optional)

All traffic: mTLS + JWT
All storage: encrypted at rest


Markdown