# DriftZero v3.3 — Production Hardening Guide

- Run as non-root (Dockerfile)
- No secrets in image
- All plugins registered at startup (no runtime loading)
- Replay buffer bounded (10,000 events)
- All decisions immutable in observability v2
- Image signed with Cosign + SBOM
- No dynamic code execution
- All external calls through allow-listed connectors


Markdown