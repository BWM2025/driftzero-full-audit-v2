# DriftZero v3.3 — SRE Runbook

Rolling restart:
kubectl rollout restart deployment/driftzero-api -n driftzero

Plugin failure spike → check /observability/alerts

Rollback:
kubectl rollout undo deployment/driftzero-api -n driftzero

Emergency quarantine all:
POST /admin/quarantine-all with master key


Markdown