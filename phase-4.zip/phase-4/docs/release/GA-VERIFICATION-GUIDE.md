# DriftZero v3.3.0 — GA Verification

1. cosign verify ghcr.io/driftzero/control-plane@sha256:...
2. curl http://localhost:8000/health → healthy
3. POST /governance/evaluate → valid action
4. GET /observability/events/replay → events returned
5. Check Prometheus metrics exposed
6. Verify Jaeger traces appear


Markdown