# DriftZero v3.3 — CI/CD Gates

All must pass:
- Unit + integration tests (100% coverage target)
- Load & chaos tests
- Lint / type-check / security scan (bandit, mypy)
- Image signing + SBOM generation
- Predictive model validation
- Plugin contract tests


Markdown