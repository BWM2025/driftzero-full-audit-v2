# Disaster Recovery Runbook

1. Restore latest encrypted Postgres backup
2. Rehydrate Temporal visibility store
3. Restart control plane
4. Run saga recovery workflow
5. Verify predictive models still loaded
6. Re-enable agents


Markdown