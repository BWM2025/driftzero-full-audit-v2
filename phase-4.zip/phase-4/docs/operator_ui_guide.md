# Operator UI Guide (React App)

The UI is located in /ui/

Key views:
- Drift Incidents Dashboard
- Active Sagas
- Predictive Risk Heatmap
- Quarantine Browser
- Approval Queue
- Plugin Status
- Cost & Usage

Tech stack:
- React 18 + TypeScript
- TanStack Query
- Recharts
- Tailwind CSS


Markdown