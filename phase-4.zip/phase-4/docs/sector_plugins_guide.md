# Sector Plugin Development Guide

Each sector plugin must:
- Inherit from `DriftZeroPlugin`
- Declare `name()`, `version()`, `capabilities()`
- Implement `run(capability, context, payload)`
- Be placed in `plugins/sector/`
- Auto-register on import (via plugins/__init__.py)

Example capabilities:
- "policy_evaluation"
- "risk_scoring"
- "phi_detection"
- "data_residency_check"

Return dicts – first CRITICAL result wins.


Markdown