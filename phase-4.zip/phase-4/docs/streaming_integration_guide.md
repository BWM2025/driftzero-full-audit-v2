# Streaming Platforms Integration

Currently supported:
- Kafka (Schema Registry sync)
- Pulsar (future)
- Kinesis (future)

DriftZero treats streaming topics as first-class datasets:
- Schema evolution governance
- Consumer lag → risk factor
- Backward compatibility enforcement


Markdown