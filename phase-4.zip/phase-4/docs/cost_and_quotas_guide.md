# Cost Management & Chargeback

DriftZero tracks:
- Active datasets per tenant
- Drift events processed
- Sandbox/Canary executions
- Storage used for quarantines

Base: $995/mo
Per dataset: $25/mo

Budget alerts at 90%, hard stop at 120% (configurable)


Markdown