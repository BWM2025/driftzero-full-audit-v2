# Security & Compliance

- All traffic TLS 1.3
- JWT bearer tokens (RS256)
- Tenant isolation at DB level (ROW LEVEL SECURITY)
- No raw data leaves customer VPC
- All decisions immutable & hash-chained
- All plugins sandboxed
- Image signing + SBOM


Markdown