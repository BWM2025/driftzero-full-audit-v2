# DriftZero v3.3 — Architecture Overview


+------------------+
|  Operator UI (React)           |
+--------+---------+
|
+-------------v--------------+
|   FastAPI Control Plane       |
|  - Governance Service        |
|  - Predictive Advisor         |
|  - Plugin Engine             |
+-------------+--------------+
|
+--------------------+---------------------+
|                    |                     |
+---------v------+   +--------v--------+   +-------v--------+
| Temporal       |   | PostgreSQL      |   | Kafka          |
| Workflows      |   | State + History  |   | Events         |
+---------+------------+   +--------+--------+   +-------+--------+
|                          |                     |
|                          |                     |
|                +---------v----------+          |
+--------------->|   gRPC Agent       +----------+
| (in customer VPC)  |
+---------------------+
text

All decisions are predictive + plugin + policy orchestrated.
All state is immutable and auditable.
Zero trust – agent never sees raw data.


Python