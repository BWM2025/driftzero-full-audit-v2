# Observability Guide

Metrics: http://localhost:8001/metrics
Traces: Jaeger at http://localhost:16686
Logs: JSON structured logs on stdout
Replay buffer: GET /observability/events/replay


Python