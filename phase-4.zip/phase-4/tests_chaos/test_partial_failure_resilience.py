from unittest.mock import patch
from core.governance.plugin_governor import PluginGovernor
from core.plugins.results import PluginResult

def test_governor_continues_on_plugin_failure():
    class FailingRunner:
        def run_for_capability(self, cap, ctx, payload):
            if cap == "policy_evaluation":
                return [PluginResult.failed("policy.drift.adapter.v1", "crash")]
            return PluginGovernor().runner.run_for_capability(cap, ctx, payload)

    governor = PluginGovernor(runner=FailingRunner())
    result = governor.evaluate("t", "e", "d", "generic", {"risk_score": 0.7})
    assert result.decision.recommended_action == "ALLOW"  # falls back to predictive only


Python