from core.observability.replay_buffer import replay_buffer
from core.observability.emitter import emit_governance_decision
from core.governance.models import GovernanceDecision

def test_buffer_caps_at_10000():
    replay_buffer.buffer.clear()
    replay_buffer.max_size = 10000
    decision = GovernanceDecision(tenant_id="t", environment_id="e", dataset_id="d",
                                 risk_level="LOW", risk_score=0.1, breaking_change_probability=0.0,
                                 dataset_is_critical=False, sector="generic", recommended_action="ALLOW")
    for _ in range(15000):
        emit_governance_decision(decision)
    assert len(replay_buffer.buffer) == 10000


Python