import asyncio
from core.governance.service import GovernanceService

async def single_call():
    service = GovernanceService()
    return service.evaluate("t", "e", "d", "generic", {"risk_score": 0.5})

def test_500_concurrent_no_crash():
    loop = asyncio.new_event_loop()
    tasks = [single_call() for _ in range(500)]
    results = loop.run_until_complete(asyncio.gather(*tasks, return_exceptions=True))
    exceptions = [r for r in results if isinstance(r, Exception)]
    assert len(exceptions) == 0


Markdown