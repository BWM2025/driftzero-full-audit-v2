from core.sandbox.sandbox_executor import SandboxExecutor

async def execute_sandbox(patch_manifest_id: str):
    executor = SandboxExecutor()
    return await executor.execute(patch_manifest_id)


Python