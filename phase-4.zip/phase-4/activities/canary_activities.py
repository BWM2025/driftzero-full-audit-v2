from core.canary.canary_orchestrator import CanaryOrchestrator

async def execute_canary(patch_manifest_id: str):
    orch = CanaryOrchestrator()
    return await orch.start(patch_manifest_id)


Python