import random
import os
import signal

def simulate_pod_kill():
    print("[CHAOS] Simulating pod death...")
    os.kill(os.getpid(), signal.SIGTERM)


Python