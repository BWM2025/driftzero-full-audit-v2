import asyncio

async def simulate_partition():
    print("[CHAOS] Network partition active for 30s")
    await asyncio.sleep(30)
    print("[CHAOS] Partition healed")


Python