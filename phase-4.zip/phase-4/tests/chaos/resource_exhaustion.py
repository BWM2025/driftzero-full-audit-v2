import psutil
import pytest

@pytest.mark.skipif(psutil.virtual_memory().total < 8e9, reason="needs >8GB RAM")
def test_memory_pressure_graceful():
    # Allocate until near OOM
    leak = []
    try:
        while True:
            leak.append("x" * 10_000_000)
    except MemoryError:
        print("[CHAOS] Memory exhausted – checking graceful degradation")


Python