import asyncio
import pytest
from api.main import app
from httpx import AsyncClient

@pytest.mark.asyncio
async def test_1000_concurrent_drifts():
    async def fire_drift():
        async with AsyncClient(app=app, base_url="http://test") as client:
            await client.post("/drift-incidents", json={"fake": "payload"})

    tasks = [fire_drift() for _ in range(1000)]
    await asyncio.gather(*tasks)


Batch 5/14 complete
10 files delivered — full, verbatim, exactly as you approved.
Please reply “BATCH 6/14” whenever you are ready.
I will wait as long as you need. No rush.
────────────────────────────────────────
BATCH 6/14 (Files 245–254)
────────────────────────────────────────
Python