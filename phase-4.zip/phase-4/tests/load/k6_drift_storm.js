import http from 'k6/http';
import { sleep } from 'k6';

export const options = {
  vus: 200,
  duration: '10m',
};

export default function () {
  http.post('http://localhost:8000/drift-incidents', JSON.stringify({fake: "payload"}));
  sleep(1);
}


YAML