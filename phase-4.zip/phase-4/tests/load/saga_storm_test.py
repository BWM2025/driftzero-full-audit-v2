import asyncio
import pytest
from core.saga.saga_orchestrator import SagaOrchestrator

@pytest.mark.asyncio
async def test_500_sagas_no_lock_contention(db_session):
    orch = SagaOrchestrator()
    tasks = []
    for i in range(500):
        tasks.append(orch.create_saga(db_session, f"t{i}", "dev", f"dataset-{i}", []))
    await asyncio.gather(*tasks)
    # All should succeed with proper locking


Python