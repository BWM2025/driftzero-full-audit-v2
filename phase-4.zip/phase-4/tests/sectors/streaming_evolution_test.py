from plugins.sector.streaming import StreamingSectorPlugin

def test_backward_compatibility_enforced():
    plugin = StreamingSectorPlugin()
    result = plugin.run("schema_compatibility_check", {}, {"compatibility": "FORWARD"})
    assert result["allowed"] is False


Python