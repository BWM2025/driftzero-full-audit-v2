from plugins.sector.healthcare import HealthcareSectorPlugin

def test_phi_detection():
    plugin = HealthcareSectorPlugin()
    result = plugin.run("phi_detection", {}, {"column": "mrn"})
    assert result["contains_phi"] is True


Python