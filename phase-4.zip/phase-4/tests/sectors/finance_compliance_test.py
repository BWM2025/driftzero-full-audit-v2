from plugins.sector.finance import FinanceSectorPlugin

def test_pci_column_triggers_critical():
    plugin = FinanceSectorPlugin()
    result = plugin.run("risk_scoring", {}, {"column": "credit_card_number"})
    assert result["risk_level"] == "CRITICAL"


Python