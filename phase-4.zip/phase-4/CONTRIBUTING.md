# Contributing to DriftZero

Thank you for your interest!

1. Fork the repo
2. Create a feature branch
3. Write tests
4. Run `ruff . && mypy . && pytest`
5. Open PR with clear description

All contributions are under MIT license.


text