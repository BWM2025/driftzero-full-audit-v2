def check_pulsar_compatibility(old_schema: dict, new_schema: dict) -> str:
    # Pulsar uses Avro under the hood
    return "BACKWARD" if new_schema.get("fields")[-1].get("default") is not None else "NONE"


Python

# 312.github/workflows/load-test.yml
name: Load Test

on:
  schedule:
    - cron: '0 2 * * *'  # daily at 2am

jobs:
  load:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Run k6 load test
        uses: grafana/k6-action@v0.3.0
        with:
          filename: tests/load/k6_drift_storm.js


YAML