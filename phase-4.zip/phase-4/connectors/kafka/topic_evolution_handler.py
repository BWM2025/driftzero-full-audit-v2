def is_backward_compatible(old_schema: dict, new_schema: dict) -> bool:
    # Simplified Avro compatibility check
    return True  # real implementation would use Schema Registry API


Python