import aiohttp

async def sync_with_schema_registry(subject: str, schema: dict):
    async with aiohttp.ClientSession() as session:
        async with session.post(
            "http://schema-registry:8081/subjects/test-value/versions",
            json={"schema": str(schema)}
        ) as resp:
            return await resp.json()


Python