# Contributor Covenant Code of Conduct v2.1

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

Full text: https://www.contributor-covenant.org/version/2/1/code_of_conduct/