# Security Policy

**Reporting a Vulnerability**  
Email: security@driftzero.io  
PGP: https://driftzero.io/security-pgp.key  
SLA: 24h for critical — 72h for high

**Bug Bounty**  
$5,000 – $100,000 — scope: *.driftzero.io

**Supported Versions**  
- v3.3.x — full support  
- v3.2.x — security fixes only