# DriftZero Enterprise Hardening Guide

Validated for: PCI DSS 4.0 · HIPAA · SOC2 Type II · FedRAMP Moderate

1. **Secrets** — Vault / AWS SM / GCP SM only — never in repo  
2. **Network** — Private subnet + ALB WAF + mTLS agent traffic  
3. **RLS Verification**