# DriftZero Runbook — SRE Edition

### SEV-1: Schema Drift in Production
1. Alert → PagerDuty → #driftzero-oncall  
2. Check `/v1/approvals/queue` → approve/reject  
3. Verify compensation ran  
4. Post-mortem → add sector plugin if needed

### Disaster Recovery (RPO < 5 min, RTO < 30 min)