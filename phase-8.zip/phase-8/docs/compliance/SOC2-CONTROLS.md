| SOC2 Control | DriftZero Feature                        | Evidence Location                    |
|--------------|------------------------------------------|--------------------------------------|
| CC6.1        | Logical access controls                  | RLS + JWT + MFA                     |
| CC6.6        | Authentication mechanisms                | TOTP + SAML 2.0 + OIDC + SCIM       |
| CC7.2        | Incident monitoring                      | Immutable audit + SIEM forwarding   |
| CC8.1        | Change management                        | Temporal saga + approval quorum     |
| A1.2         | Encryption at rest                       | Fernet field-level encryption       |