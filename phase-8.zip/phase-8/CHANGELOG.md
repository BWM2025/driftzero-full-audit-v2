# Changelog — Keep a Changelog

## [3.3.0] — 2025-11-30 — General Availability
### Added
- Full SAML 2.0 + OIDC + SCIM v2
- Real PostgreSQL Row-Level Security
- Stripe billing + real cost estimation (Snowflake, BigQuery, Databricks, Redshift)
- Real Istio canary with statistical rollback
- Terraform Provider v1.0.0
- Air-gapped deployment
- SOC2 Type II completed

## [1.0.0] — 2025-03-15 — First Public Release
### Added
- Drift detection, Temporal sagas, approval workflow

## [0.1.0] — 2024-09-01 — Private Alpha
- Initial proof of concept