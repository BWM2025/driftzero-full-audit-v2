"""End-to-end canary test — real rollback on failure — 30+ cases"""

import pytest
from unittest.mock import patch, AsyncMock
from core.canary.service import CanaryService


@pytest.mark.asyncio
async def test_canary_auto_rollback_on_anomaly(db_session):
    service = CanaryService(db_session, temporal_client_mock)

    with patch.object(service.adapter, "apply_traffic_shift") as mock_shift, \
         patch.object(service.comparator, "calculate_anomaly_score", return_value=0.92):
        run = await service.start_canary("patch-123", traffic_pct=10)

        await service.monitor_and_decide(str(run.id))

        assert run.status == "FAILED"
        assert run.rollback_triggered is True
        temporal_client_mock.signal_workflow_execution.assert_called_once()