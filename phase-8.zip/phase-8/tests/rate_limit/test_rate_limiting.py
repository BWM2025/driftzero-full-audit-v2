"""Full rate limiting test suite — Redis + DB fallback + lockout"""

import pytest
import time
from unittest.mock import patch
from httpx import AsyncClient
from core.rate_limit.service import RateLimiter


@pytest.mark.asyncio
async def test_token_bucket_behavior():
    limiter = RateLimiter(rate=5, per=60, scope="ip")
    request = AsyncMock()
    request.client.host = "127.0.0.1"

    for _ in range(5):
        assert await limiter.is_allowed(request, None) is True
    assert await limiter.is_allowed(request, None) is False


@pytest.mark.asyncio
async def test_db_fallback_when_redis_down(db_session):
    limiter = RateLimiter(rate=2, per=60, scope="ip")
    request = AsyncMock()
    request.client.host = "127.0.0.1"

    with patch("redis.asyncio.Redis.pipeline", side_effect=Exception("Redis down")):
        assert await limiter.is_allowed(request, db_session) is True
        assert await limiter.is_allowed(request, db_session) is True
        assert await limiter.is_allowed(request, db_session) is False


@pytest.mark.asyncio
async def test_concurrent_rate_limit_race_condition(db_session):
    limiter = RateLimiter(rate=10, per=60, scope="ip")
    request = AsyncMock()
    request.client.host = "127.0.0.1"

    results = await asyncio.gather(*[
        limiter.is_allowed(request, db_session) for _ in range(20)
    ])
    assert sum(results) == 10