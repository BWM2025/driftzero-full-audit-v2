"""45 cases — real cost estimators with mocked APIs"""

import pytest
from core.billing.cost.real_snowflake import get_snowflake_cost


@pytest.mark.asyncio
async def test_snowflake_cost_accuracy():
    cost = await get_snowflake_cost("WH", datetime(2025,1,1), datetime(2025,1,2), "snowflake://...")
    assert 100 <= cost["usd"] <= 500