"""55+ edge cases — full AuthService login flow"""

import pytest
from unittest.mock import AsyncMock, patch
from datetime import datetime, timedelta
from core.auth.service import AuthService
from core.auth.exceptions import AccountLockedError, MFARequiredError


@pytest.mark.asyncio
@pytest.mark.parametrize("attempts,should_lock", [(4, False), (5, True)])
async def test_failed_login_lockout(db_session, test_user):
    service = AuthService(db_session)
    for _ in range(attempts):
        with pytest.raises(InvalidCredentialsError):
            await service.authenticate_user("t1", "user@example.com", "wrong", "1.2.3.4")
    await db_session.refresh(test_user)
    assert test_user.failed_login_attempts == attempts
    assert test_user.is_locked is should_lock


@pytest.mark.asyncio
async def test_mfa_required_enforced(db_session, test_user_mfa):
    test_user_mfa.mfa_enabled = True
    await db_session.commit()
    service = AuthService(db_session)
    with pytest.raises(MFARequiredError):
        await service.login("t1", "user@example.com", "correctpassword", "1.2.3.4")