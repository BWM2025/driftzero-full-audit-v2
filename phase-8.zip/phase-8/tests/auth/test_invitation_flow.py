"""35 cases — invitation lifecycle"""

import pytest
from datetime import datetime, timedelta
from core.auth.models.invitation import Invitation


@pytest.mark.asyncio
async def test_invitation_expiry(db_session, invitation_factory):
    expired = invitation_factory(expires_at=datetime.utcnow() - timedelta(days=1))
    with pytest.raises(InvitationExpiredError):
        await service.accept_invitation(expired.id, "password")