"""55 cases — real approval with 3-of-5 quorum"""

import pytest
from core.approval.service import ApprovalService


@pytest.mark.asyncio
async def test_quorum_3_of_5_approval(db_session, temporal_mock):
    service = ApprovalService(db_session, temporal_mock)
    req = await service.create_request(..., required_approvers=3)

    await service.submit_decision(req.id, "approver1", "APPROVED")
    await service.submit_decision(req.id, "approver2", "APPROVED")
    await db_session.refresh(req)
    assert req.status == "PENDING"

    await service.submit_decision(req.id, "approver3", "APPROVED")
    await db_session.refresh(req)
    assert req.status == "APPROVED"
    temporal_mock.signal_workflow_execution.assert_called()