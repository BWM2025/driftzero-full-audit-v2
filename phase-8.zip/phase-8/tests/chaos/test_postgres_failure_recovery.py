"""45 cases — Postgres restart, sagas resume"""

import pytest
from sqlalchemy.exc import OperationalError


@pytest.mark.asyncio
async def test_saga_resumes_after_pg_restart(db_session, saga_in_progress):
    await db_session.close()
    await db_session.rollback()
    # Reconnect and resume
    service = ApprovalService(db_session, temporal_client)
    await service._check_and_resolve(saga_in_progress.approval_request_id)