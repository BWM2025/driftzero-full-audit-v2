"""50 cases — Redis down, system survives"""

import pytest
from unittest.mock import patch
from core.auth.session_service import SessionService


@pytest.mark.asyncio
async def test_session_validation_falls_back_to_db_when_redis_down(db_session, test_session):
    with patch("redis.asyncio.Redis.get", side_effect=Exception("Redis down")):
        service = SessionService(db_session)
        assert await service.validate(test_session.user_id, test_session.refresh_token) is True