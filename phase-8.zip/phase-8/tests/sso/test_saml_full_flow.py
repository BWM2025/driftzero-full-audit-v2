"""50 cases — real SAML round-trip with embedded IdP"""

import pytest
from core.sso.saml2.provider import SAML2Provider


@pytest.mark.asyncio
async def test_saml_signed_assertion_validation():
    provider = SAML2Provider("t1", test_idp_metadata)
    result = provider.process_response(valid_signed_response)
    assert result["email"] == "user@company.com"