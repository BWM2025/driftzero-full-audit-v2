"""50 cases — real OIDC flow with token validation"""

import pytest
from core.sso.oidc.provider import OIDCProvider


@pytest.mark.asyncio
async def test_oidc_token_validation_and_refresh():
    provider = OIDCProvider("t1", "client", "secret", "https://oidc.test")
    token = await provider.authorize_access_token(mock_request)
    assert "id_token" in token