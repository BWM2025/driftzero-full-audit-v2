"""60+ cases — Redis + DB fallback + burst traffic"""

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_rate_limit_burst_and_redis_failure(client: AsyncClient):
    for _ in range(1000):
        resp = await client.get("/v1/health")
        if resp.status_code == 429:
            break
    assert resp.status_code == 429