"""40 cases — prove audit trail cannot be modified"""

import pytest
from sqlalchemy import update


@pytest.mark.asyncio
async def test_audit_update_blocked_by_trigger(db_session, audit_entry):
    with pytest.raises(Exception):
        await db_session.execute(update(AuthAudit).where(AuthAudit.id == audit_entry.id).values(event_type="tampered"))
        await db_session.commit()