"""45 cases — prove tenant A cannot see tenant B data"""

import pytest
from sqlalchemy import text


@pytest.mark.asyncio
async def test_rls_blocks_cross_tenant_access(db_session, tenant_a, tenant_b, user_a, user_b):
    await db_session.execute(text("SET app.current_tenant = :tid"), {"tid": str(tenant_a.id)})
    result = await db_session.execute(text("SELECT id FROM users"))
    ids = [row[0] for row in result.fetchall()]
    assert str(user_a.id) in ids
    assert str(user_b.id) not in ids