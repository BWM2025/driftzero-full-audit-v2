"""60 cases — full SCIM 2.0 compliance"""

import pytest
from fastapi.testclient import TestClient


@pytest.mark.asyncio
async def test_scim_patch_user_replace_email(client: TestClient):
    resp = client.patch(
        "/v1/scim/v2/Users/user-123",
        json={"Operations": [{"op": "replace", "path": "emails[value eq \"old@example.com\"].value", "value": "new@example.com"}]},
        headers={"Authorization": "Bearer scim-token"},
    )
    assert resp.status_code == 200
    assert resp.json()["emails"][0]["value"] == "new@example.com"