"""30 cases — 500 concurrent sagas, no deadlocks"""

import asyncio
import pytest
from core.locking.saga_lock import SagaLockManager


@pytest.mark.asyncio
async def test_500_concurrent_sagas_no_deadlock(db_session):
    manager = SagaLockManager(db_session)
    await asyncio.gather(*[manager.acquire_lock(f"ds-{i}", "saga-1") for i in range(500)])