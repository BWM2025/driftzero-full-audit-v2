"""Enforce valid JWT Bearer token and inject user/tenant/roles into request.state"""

from __future__ import annotations

from fastapi import Request, HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from core.auth.jwt_service import JWTService
from core.auth.models.user import User

bearer_scheme = HTTPBearer(auto_error=False)
jwt_service = JWTService()


async def require_authenticated_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
) -> User:
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing Authorization header",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        payload = jwt_service.decode_access_token(credentials.credentials)
        user_id = payload["user_id"]
        tenant_id = payload["tenant_id"]
        roles = payload.get("roles", [])

        request.state.user_id = user_id
        request.state.tenant_id = tenant_id
        request.state.user_roles = roles

        return User(id=user_id, tenant_id=tenant_id, roles=roles)

    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )