"""Enforce X-Tenant-ID header and set PostgreSQL RLS session variable"""

from __future__ import annotations

import uuid
from fastapi import Request, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from api.dependencies import get_db


async def require_tenant_context(
    request: Request,
    db: AsyncSession = Depends(get_db),
) -> str:
    tenant_id = request.headers.get("X-Tenant-ID")
    if not tenant_id:
        raise HTTPException(status_code=400, detail="X-Tenant-ID header required")

    try:
        tenant_uuid = uuid.UUID(tenant_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid X-Tenant-ID format")

    result = await db.execute(
        text("SELECT 1 FROM tenants WHERE id = :tid AND is_active = true"),
        {"tid": str(tenant_uuid)},
    )
    if not result.fetchone():
        raise HTTPException(status_code=403, detail="Invalid or inactive tenant")

    await db.execute(text("SET app.current_tenant = :tid"), {"tid": str(tenant_uuid)})
    request.state.tenant_id = str(tenant_uuid)
    return str(tenant_uuid)