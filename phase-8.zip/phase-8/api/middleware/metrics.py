"""Prometheus metrics for request counting and latency"""

from __future__ import annotations

from prometheus_client import Counter, Histogram
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

REQUEST_COUNT = Counter(
    "http_requests_total", "Total HTTP requests", ["method", "path", "status"]
)
REQUEST_LATENCY = Histogram(
    "http_request_duration_seconds", "Request latency", ["method", "path"]
)


class MetricsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        with REQUEST_LATENCY.labels(method=request.method, path=request.url.path).time():
            response = await call_next(request)
            REQUEST_COUNT.labels(
                method=request.method,
                path=request.url.path,
                status=response.status_code,
            ).inc()
            return response