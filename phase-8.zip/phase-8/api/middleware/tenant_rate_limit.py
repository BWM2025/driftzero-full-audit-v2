"""Strict per-tenant rate limiting"""

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from core.rate_limit.service import RateLimiter

tenant_limiter = RateLimiter(rate=5000, per=3600, scope="tenant")


class TenantRateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if not hasattr(request.state, "tenant_id"):
            return await call_next(request)

        db = request.state.get("db")
        if not await tenant_limiter.is_allowed(request, db):
            return JSONResponse(
                status_code=429,
                content={"detail": "Tenant rate limit exceeded"},
                headers={"Retry-After": "3600"},
            )
        return await call_next(request)