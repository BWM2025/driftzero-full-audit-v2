"""Tenant-aware CORS with credentials support"""

from fastapi import Request
from starlette.middleware.cors import CORSMiddleware

cors_middleware = CORSMiddleware(
    allow_origins=["https://app.driftzero.com", "https://*.driftzero.com"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=[
        "Authorization",
        "Content-Type",
        "X-Tenant-ID",
        "X-Request-ID",
    ],
    expose_headers=["X-Request-ID"],
    max_age=86400,
)