"""Apply default rate limiting to all endpoints"""

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from core.rate_limit.service import RateLimiter

global_limiter = RateLimiter(rate=1000, per=3600, scope="ip")


class GlobalRateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path.startswith(("/health", "/metrics", "/docs", "/openapi.json", "/webhooks")):
            return await call_next(request)

        if not await global_limiter.is_allowed(request, None):
            return JSONResponse(
                status_code=429,
                content={"detail": "Global rate limit exceeded"},
                headers={"Retry-After": "3600"},
            )
        return await call_next(request)