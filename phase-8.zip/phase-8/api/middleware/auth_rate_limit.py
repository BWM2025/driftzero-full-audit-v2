"""Very strict limits on auth endpoints"""

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from core.rate_limit.service import RateLimiter

auth_ip_limiter = RateLimiter(rate=10, per=60, scope="ip")


class AuthRateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.url.path in {"/v1/auth/login", "/v1/auth/password/reset-request"}:
            if not await auth_ip_limiter.is_allowed(request, None):
                return JSONResponse(
                    status_code=429,
                    content={"detail": "Too many authentication attempts"},
                    headers={"Retry-After": "60"},
                )
        return await call_next(request)