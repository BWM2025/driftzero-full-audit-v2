"""Immutable audit logging of every request"""

from __future__ import annotations

import time
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from sqlalchemy.ext.asyncio import AsyncSession
from core.security.audit.logger import SecurityAuditLogger
from api.dependencies import get_db


class AuditMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        response = await call_next(request)
        duration = time.time() - start_time

        audit_data = {
            "user_id": getattr(request.state, "user_id", None),
            "tenant_id": getattr(request.state, "tenant_id", None),
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration_ms": int(duration * 1000),
            "ip": request.client.host,
        }

        db: AsyncSession = next(get_db())
        await SecurityAuditLogger().log(db=db, **audit_data)

        return response