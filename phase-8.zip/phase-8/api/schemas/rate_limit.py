"""Standardized 429 response"""

from pydantic import BaseModel, Field


class RateLimitErrorResponse(BaseModel):
    detail: str = "Rate limit exceeded"
    retry_after: int = Field(..., description="Seconds until reset")
    limit: int
    remaining: int