"""Shared Pydantic models for paginated responses"""

from __future__ import annotations

from typing import TypeVar, Generic, Sequence, Optional
from pydantic import BaseModel

T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: Sequence[T]
    next_cursor: Optional[str] = None
    has_more: bool
    total: Optional[int] = None