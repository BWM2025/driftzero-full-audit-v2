"""Real approval queue + decision API — Temporal signal on resolution"""

from fastapi import APIRouter, Depends, HTTPException, status
from core.approval.service import ApprovalService
from core.approval.schemas import ApprovalDecisionRequest
from api.dependencies import get_current_user, require_tenant_context, get_db

router = APIRouter(prefix="/v1/approvals", tags=["Approvals"])


@router.get("/queue")
async def my_queue(user=Depends(get_current_user)):
    service = ApprovalService(db=None, temporal=None)
    return await service.get_pending_for_user(user.id, user.tenant_id)


@router.post("/{request_id}/decide", status_code=202)
async def decide(
    request_id: str,
    payload: ApprovalDecisionRequest,
    user=Depends(get_current_user),
    db=Depends(get_db),
):
    service = ApprovalService(db, temporal_client)
    await service.submit_decision(
        request_id=request_id,
        approver_user_id=user.id,
        decision=payload.decision,
        comment=payload.comment,
    )
    return {"detail": "Decision recorded — quorum evaluating"}