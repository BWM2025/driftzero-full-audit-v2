"""Audit log search — admin only"""

from fastapi import APIRouter, Depends
from core.security.audit.logger import SecurityAuditLogger
from api.dependencies import require_role_admin

router = APIRouter(prefix="/v1/audit", tags=["Audit"])


@router.get("/", dependencies=[Depends(require_role_admin)])
async def search_audit(
    event_type: str | None = None,
    user_id: str | None = None,
    page: int = 1,
    size: int = 100,
):
    logger = SecurityAuditLogger()
    return await logger.search({"event_type": event_type, "user_id": user_id}, page, size)