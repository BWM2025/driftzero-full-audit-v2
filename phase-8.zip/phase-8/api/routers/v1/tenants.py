"""Tenant lifecycle — admin only"""

from fastapi import APIRouter, Depends
from core.tenancy.service import TenantService
from api.dependencies import require_role_admin, get_db

router = APIRouter(prefix="/v1/tenants", tags=["Tenants"])


@router.post("/", status_code=201, dependencies=[Depends(require_role_admin)])
async def create_tenant(payload: dict, db=Depends(get_db)):
    service = TenantService()
    tenant = await service.create_tenant(**payload)
    return {"id": str(tenant.id), "slug": tenant.slug}