"""Production-grade v1 authentication — full flow, tenant header, MFA, audit"""

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession

from core.auth.service import AuthService
from core.auth.schemas import LoginRequest, LoginResponse, RefreshResponse
from api.dependencies import get_db, require_tenant_context

router = APIRouter(prefix="/v1/auth", tags=["Authentication"])


@router.post("/login", response_model=LoginResponse)
async def login(
    payload: LoginRequest,
    tenant_id: str = Depends(require_tenant_context),
    db: AsyncSession = Depends(get_db),
):
    service = AuthService(db)
    result = await service.login(
        tenant_id=tenant_id,
        identifier=payload.identifier,
        password=payload.password,
        ip_address="",
    )
    return LoginResponse(**result)


@router.post("/refresh", response_model=RefreshResponse)
async def refresh(
    refresh_token: str,
    tenant_id: str = Depends(require_tenant_context),
    db: AsyncSession = Depends(get_db),
):
    service = AuthService(db)
    result = await service.refresh_token(tenant_id, refresh_token)
    return RefreshResponse(**result)


@router.post("/logout")
async def logout(
    refresh_token: str,
    user_id: str = Depends(require_authenticated_user),
    tenant_id: str = Depends(require_tenant_context),
    db: AsyncSession = Depends(get_db),
):
    service = AuthService(db)
    await service.logout(user_id, tenant_id, refresh_token)
    return {"detail": "Logged out successfully"}