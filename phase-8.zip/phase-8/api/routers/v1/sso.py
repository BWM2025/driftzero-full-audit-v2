"""Full SAML 2.0 + OIDC endpoints — production ready"""

from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import RedirectResponse, Response
from core.sso.saml2.provider import SAML2Provider
from core.sso.saml2.acs import handle_acs
from core.sso.oidc.provider import OIDCProvider
from api.dependencies import require_tenant_context

router = APIRouter(prefix="/v1/sso", tags=["SSO"])


@router.get("/saml/metadata/{tenant_id}")
async def saml_metadata(tenant_id: str):
    provider = SAML2Provider(tenant_id, idp_metadata="")
    return Response(content=provider.get_sp_metadata(), media_type="application/xml")


@router.get("/saml/login/{tenant_id}")
async def saml_login(tenant_id: str, request: Request, relay_state: str | None = None):
    provider = SAML2Provider(tenant_id, "")
    redirect_url = provider.build_authn_request("", relay_state or str(request.url))
    return RedirectResponse(url=redirect_url)


@router.post("/saml/acs/{tenant_id}")
async def saml_acs(tenant_id: str, request: Request):
    form = await request.form()
    result = handle_acs(form.get("SAMLResponse"), form.get("RelayState"), SAML2Provider(tenant_id, ""))
    return {"user": result}


@router.get("/oidc/login/{tenant_id}")
async def oidc_login(tenant_id: str, request: Request):
    provider = OIDCProvider(tenant_id, "", "", "")
    return await provider.authorize_redirect(request, "https://app.driftzero.com/callback")


@router.get("/oidc/callback")
async def oidc_callback(request: Request):
    provider = OIDCProvider("", "", "", "")
    userinfo = await provider.get_userinfo(request)
    return {"user": userinfo}