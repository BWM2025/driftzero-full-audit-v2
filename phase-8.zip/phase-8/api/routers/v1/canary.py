"""HTTP API for canary control — real traffic shifting"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from core.canary.service import CanaryService
from api.dependencies import get_db, require_role_operator

router = APIRouter(prefix="/v1/canary", tags=["Canary"])


@router.post("/start", status_code=202)
async def start_canary(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    _: None = Depends(require_role_operator),
):
    service = CanaryService(db, temporal_client)
    run = await service.start_canary(
        patch_manifest_id=payload["patch_id"],
        traffic_pct=payload.get("traffic_percentage", 10),
    )
    return {"run_id": str(run.id), "status": "started"}