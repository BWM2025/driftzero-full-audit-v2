"""Admin user management with pagination and search"""

from fastapi import APIRouter, Depends, Query
from core.auth.service import AuthService
from api.dependencies import require_role_admin, get_db
from core.pagination import paginate

router = APIRouter(prefix="/v1/users", tags=["Users"])


@router.get("/", dependencies=[Depends(require_role_admin)])
async def list_users(
    search: str | None = None,
    page: int = 1,
    size: int = Query(50, ge=1, le=100),
    db=Depends(get_db),
):
    service = AuthService(db)
    return await paginate(service.list_users(search), page, size)


@router.post("/invite", dependencies=[Depends(require_role_admin)])
async def invite_user(payload: dict, db=Depends(get_db)):
    service = AuthService(db)
    await service.create_invitation(**payload)
    return {"status": "invitation_sent"}