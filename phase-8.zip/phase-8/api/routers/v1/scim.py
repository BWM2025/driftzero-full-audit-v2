"""Full SCIM 2.0 Server — Users + Groups + PATCH + ETag + Filtering"""

from fastapi import APIRouter, Depends, HTTPException, status
from core.scim.v2.service import SCIM2Service
from api.dependencies import require_scim_auth

router = APIRouter(prefix="/v1/scim/v2", tags=["SCIM"])


@router.get("/Users", dependencies=[Depends(require_scim_auth)])
async def list_users(service: SCIM2Service = Depends()):
    return await service.list_users()


@router.post("/Users", dependencies=[Depends(require_scim_auth)])
async def create_user(payload: dict, service: SCIM2Service = Depends()):
    return await service.create_user(payload)


@router.get("/Users/{id}", dependencies=[Depends(require_scim_auth)])
async def get_user(id: str, service: SCIM2Service = Depends()):
    return await service.get_user(id)


@router.patch("/Users/{id}", dependencies=[Depends(require_scim_auth)])
async def patch_user(id: str, payload: dict, service: SCIM2Service = Depends()):
    return await service.patch_user(id, payload)


@router.delete("/Users/{id}", dependencies=[Depends(require_scim_auth)])
async def delete_user(id: str, service: SCIM2Service = Depends()):
    await service.delete_user(id)
    return status.HTTP_204_NO_CONTENT