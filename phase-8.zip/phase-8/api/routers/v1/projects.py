"""Project CRUD — tenant scoped"""

from fastapi import APIRouter, Depends
from api.dependencies import require_tenant_context

router = APIRouter(prefix="/v1/projects", tags=["Projects"])


@router.get("/")
async def list_projects(tenant_id: str = Depends(require_tenant_context)):
    return {"projects": []}