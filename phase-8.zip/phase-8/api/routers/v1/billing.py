"""Billing views — tenant scoped"""

from fastapi import APIRouter, Depends
from core.billing.service import BillingService
from api.dependencies import require_tenant_context, get_db

router = APIRouter(prefix="/v1/billing", tags=["Billing"])


@router.get("/invoices")
async def list_invoices(tenant_id: str = Depends(require_tenant_context), db=Depends(get_db)):
    service = BillingService(db)
    return await service.get_invoices(tenant_id)


@router.get("/usage")
async def get_usage(tenant_id: str = Depends(require_tenant_context), db=Depends(get_db)):
    service = BillingService(db)
    return await service.get_usage(tenant_id)