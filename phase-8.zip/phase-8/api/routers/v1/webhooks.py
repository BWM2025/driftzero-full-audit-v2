"""External webhook ingestion"""

from fastapi import APIRouter
from core.billing.stripe.webhook import stripe_webhook

router = APIRouter(prefix="/v1/webhooks", tags=["Webhooks"])
router.include_router(stripe_webhook.router)