"""add_rate_limit_tracking"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID


def upgrade() -> None:
    op.create_table(
        "rate_limit_events",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("tenant_id", UUID(as_uuid=True), sa.ForeignKey("tenants.id")),
        sa.Column("user_id", UUID(as_uuid=True), nullable=True),
        sa.Column("ip_address", sa.String(45)),
        sa.Column("endpoint", sa.String(255)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
    )
    op.create_index("ix_rate_limit_tenant_endpoint", "rate_limit_events", ["tenant_id", "endpoint", "created_at DESC"])
    op.create_index("ix_rate_limit_ip_endpoint", "rate_limit_events", ["ip_address", "endpoint", "created_at DESC"])


def downgrade() -> None:
    op.drop_index("ix_rate_limit_ip_endpoint", table_name="rate_limit_events")
    op.drop_index("ix_rate_limit_tenant_endpoint", table_name="rate_limit_events")
    op.drop_table("rate_limit_events")