"""add_user_password_hash_and_roles"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import ARRAY


def upgrade() -> None:
    op.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash VARCHAR(255)")
    op.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS roles VARCHAR[]")
    op.execute("UPDATE users SET password_hash = '' WHERE password_hash IS NULL")
    op.execute("UPDATE users SET roles = ARRAY['viewer'] WHERE roles IS NULL")
    op.alter_column("users", "password_hash", nullable=False)
    op.alter_column("users", "roles", type_=ARRAY(sa.String), nullable=False, server_default="{}")
    op.create_unique_constraint("uq_tenant_username", "users", ["tenant_id", "username"])
    op.create_unique_constraint("uq_tenant_email", "users", ["tenant_id", "email"])


def downgrade() -> None:
    op.drop_constraint("uq_tenant_email", "users", type_="unique")
    op.drop_constraint("uq_tenant_username", "users", type_="unique")
    op.drop_column("users", "roles")
    op.drop_column("users", "password_hash")