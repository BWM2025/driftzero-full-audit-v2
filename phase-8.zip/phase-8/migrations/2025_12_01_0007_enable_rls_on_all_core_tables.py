"""enable_rls_on_all_core_tables"""

from alembic import op
import sqlalchemy as sa


TABLES = [
    "users", "sessions", "login_attempts", "invitations", "mfa_recovery_codes",
    "tenants", "drift_incidents", "drift_sagas", "patch_manifests",
    "quarantine_records", "approval_requests", "approval_decisions",
    "approval_assignments", "billing_customers", "billing_subscriptions",
    "audit_trail", "auth_audit",
]


def upgrade() -> None:
    for table in TABLES:
        op.execute(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY")
        op.execute(
            f"""
            CREATE POLICY tenant_isolation ON {table}
            USING (tenant_id = current_setting('app.current_tenant')::uuid)
            WITH CHECK (tenant_id = current_setting('app.current_tenant')::uuid)
            """
        )


def downgrade() -> None:
    for table in TABLES:
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation ON {table}")
        op.execute(f"ALTER TABLE {table} DISABLE ROW LEVEL SECURITY")