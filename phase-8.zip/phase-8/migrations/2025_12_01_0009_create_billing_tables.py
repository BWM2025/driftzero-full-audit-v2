"""create_billing_tables"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects.postgresql import UUID


def upgrade() -> None:
    op.create_table(
        "billing_customers",
        sa.Column("tenant_id", UUID(as_uuid=True), sa.ForeignKey("tenants.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("provider", sa.String(50), nullable=False),
        sa.Column("external_id", sa.String(255), nullable=False),
        sa.Column("email", sa.String(255)),
        sa.Column("status", sa.String(50), server_default="active"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), onupdate=sa.text("now()")),
        sa.UniqueConstraint("provider", "external_id"),
    )

    op.create_table(
        "billing_subscriptions",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("tenant_id", UUID(as_uuid=True), sa.ForeignKey("tenants.id")),
        sa.Column("customer_id", UUID(as_uuid=True), sa.ForeignKey("billing_customers.tenant_id")),
        sa.Column("provider_subscription_id", sa.String(255), nullable=False),
        sa.Column("plan", sa.String(100), nullable=False),
        sa.Column("status", sa.String(50), nullable=False),
        sa.Column("current_period_start", sa.DateTime(timezone=True), nullable=False),
        sa.Column("current_period_end", sa.DateTime(timezone=True), nullable=False),
        sa.Column("cancel_at_period_end", sa.Boolean(), server_default="false"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.Column("updated_at", sa.DateTime(timezone=True), onupdate=sa.text("now()")),
        sa.UniqueConstraint("tenant_id"),
    )

    op.create_table(
        "billing_invoices",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("tenant_id", UUID(as_uuid=True), sa.ForeignKey("tenants.id")),
        sa.Column("invoice_number", sa.String(100), unique=True),
        sa.Column("provider_invoice_id", sa.String(255)),
        sa.Column("amount_due_cents", sa.Integer()),
        sa.Column("amount_paid_cents", sa.Integer()),
        sa.Column("status", sa.String(50)),
        sa.Column("hosted_invoice_url", sa.String(512)),
        sa.Column("pdf_url", sa.String(512)),
        sa.Column("period_start", sa.DateTime(timezone=True)),
        sa.Column("period_end", sa.DateTime(timezone=True)),
        sa.Column("issued_at", sa.DateTime(timezone=True)),
    )

    op.create_table(
        "billing_usage",
        sa.Column("id", UUID(as_uuid=True), primary_key=True),
        sa.Column("tenant_id", UUID(as_uuid=True), sa.ForeignKey("tenants.id")),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("active_datasets", sa.Integer()),
        sa.Column("drift_events", sa.Column("sandbox_executions", sa.Integer()),
        sa.Column("canary_executions", sa.Integer()),
        sa.Column("storage_gb", sa.Numeric(12,2)),
        sa.Column("recorded_at", sa.DateTime(timezone=True), server_default=sa.text("now()")),
        sa.PrimaryKeyConstraint("tenant_id", "date"),
    )


def downgrade() -> None:
    op.drop_table("billing_usage")
    op.drop_table("billing_invoices")
    op.drop_table("billing_subscriptions")
    op.drop_table("billing_customers")