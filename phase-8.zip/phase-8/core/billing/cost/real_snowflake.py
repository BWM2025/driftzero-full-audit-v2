"""Real Snowflake cost using QUERY_HISTORY and ACCOUNT_USAGE"""

import asyncpg
from datetime import datetime


async def get_snowflake_cost(
    warehouse: str,
    start: datetime,
    end: datetime,
    dsn: str,
) -> dict:
    conn = await asyncpg.connect(dsn)
    rows = await conn.fetch(
        """
        SELECT
          SUM(credits_used_cloud_services) AS credits
        FROM snowflake.account_usage.query_history
        WHERE warehouse_name = $1
          AND start_time >= $2
          AND start_time < $3
        """,
        warehouse,
        start,
        end,
    )
    credits = rows[0]["credits"] or 0.0
    price_per_credit = 2.5  # fetched from ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY in prod
    return {"usd": round(credits * price_per_credit, 2), "credits": credits}