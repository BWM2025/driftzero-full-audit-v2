"""Real BigQuery cost using INFORMATION_SCHEMA.JOBS"""

from google.cloud import bigquery


async def get_bigquery_cost(project_id: str, start: datetime, end: datetime) -> dict:
    client = bigquery.Client(project=project_id)
    query = f"""
        SELECT
          SUM(total_bytes_processed) / 1024 / 1024 / 1024 / 1024.0 * 6.25 AS cost_tb
        FROM `{project_id}.region-us`.INFORMATION_SCHEMA.JOBS
        WHERE creation_time BETWEEN @start AND @end
    """
    job = client.query(query, job_config=bigquery.QueryJobConfig(
        query_parameters=[
            bigquery.ScalarQueryParameter("start", "TIMESTAMP", start),
            bigquery.ScalarQueryParameter("end", "TIMESTAMP", end),
        ]
    ))
    row = job.result().to_dataframe().iloc[0]
    return {"usd": round(row["cost_tb"], 2), "tb_processed": row["cost_tb"] / 6.25}