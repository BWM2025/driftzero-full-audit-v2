"""Real Databricks DBU cost"""

import httpx


async def get_databricks_cost(cluster_id: str, start: datetime, end: datetime, token: str) -> dict:
    headers = {"Authorization": f"Bearer {token}"}
    resp = await httpx.get(
        f"https://<workspace>.cloud.databricks.com/api/2.0/clusters/get",
        headers=headers,
        params={"start_time": int(start.timestamp() * 1000), "end_time": int(end.timestamp() * 1000)},
    )
    data = resp.json()
    dbu = sum(item["dbu"] for item in data.get("executions", []))
    price_per_dbu = 0.55
    return {"usd": round(dbu * price_per_dbu, 2), "dbu": dbu}