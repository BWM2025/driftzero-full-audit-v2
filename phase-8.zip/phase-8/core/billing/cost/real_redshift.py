"""Real Redshift cost via STL_QUERY"""

async def get_redshift_cost(cluster_id: str, start: datetime, end: datetime, dsn: str) -> dict:
    conn = await asyncpg.connect(dsn)
    rows = await conn.fetch(
        """
        SELECT SUM(DATEDIFF(seconds, starttime, endtime) / 3600.0 * 8) AS node_hours
        FROM stl_query
        WHERE starttime >= $1 AND endtime < $2
        """,
        start,
        end,
    )
    node_hours = rows[0]["node_hours"] or 0.0
    price_per_hour = 3.26
    return {"usd": round(node_hours * price_per_hour, 2), "node_hours": node_hours}