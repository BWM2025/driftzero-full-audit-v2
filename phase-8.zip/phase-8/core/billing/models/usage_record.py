"""Daily granular usage per tenant"""

from __future__ import annotations

from uuid import uuid4
from datetime import date

from sqlalchemy import Date, Integer, Numeric, DateTime, func, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from db.base import Base


class BillingUsageRecord(Base):
    __tablename__ = "billing_usage"

    id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    tenant_id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False)
    date: Mapped[date] = mapped_column(Date, nullable=False)

    active_datasets: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    drift_events: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    sandbox_executions: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    canary_executions: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    storage_gb: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False, server_default="0")

    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        sa.PrimaryKeyConstraint("tenant_id", "date"),
        sa.Index("ix_billing_usage_tenant_date", "tenant_id", "date"),
    )