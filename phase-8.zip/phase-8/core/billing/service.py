"""Central billing orchestration service"""

from __future__ import annotations

from datetime import date
from sqlalchemy.ext.asyncio import AsyncSession
from core.billing.models.customer import BillingCustomer
from core.billing.models.subscription import BillingSubscription


class BillingService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_or_create_customer(self, tenant_id: str, email: str | None = None) -> BillingCustomer:
        customer = await self.db.get(BillingCustomer, tenant_id)
        if not customer:
            customer = BillingCustomer(
                tenant_id=tenant_id,
                provider="stripe",
                external_id=f"cus_{tenant_id}",
                email=email,
                status="active",
            )
            self.db.add(customer)
            await self.db.commit()
        return customer

    async def ensure_active_subscription(self, tenant_id: str, plan: str = "enterprise") -> BillingSubscription:
        sub = await self.db.execute(
            select(BillingSubscription).where(BillingSubscription.tenant_id == tenant_id)
        )
        sub = sub.scalars().first()
        if not sub or sub.status != "active":
            # Real Stripe subscription creation here
            pass
        return sub

    async def record_daily_usage(self, tenant_id: str, metrics: dict) -> None:
        record = BillingUsageRecord(
            tenant_id=tenant_id,
            date=date.today(),
            **metrics,
        )
        self.db.add(record)
        await self.db.commit()