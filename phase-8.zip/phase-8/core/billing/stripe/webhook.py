"""Stripe webhook receiver with signature verification"""

from fastapi import APIRouter, Request, HTTPException, Header
import stripe
from core.config import settings

router = APIRouter()


@router.post("/billing/webhook/stripe")
async def stripe_webhook(request: Request, stripe_signature: str | None = Header(None)):
    payload = await request.body()
    try:
        event = stripe.Webhook.construct_event(
            payload, stripe_signature, settings.STRIPE_WEBHOOK_SECRET
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid payload")
    except stripe.error.SignatureVerificationError:
        raise HTTPException(status_code=400, detail="Invalid signature")

    # Handle events
    if event["type"] == "invoice.paid":
        # Mark invoice paid
        pass
    elif event["type"] == "customer.subscription.deleted":
        # Disable tenant
        pass

    return {"status": "success"}