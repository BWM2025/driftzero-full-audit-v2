"""Per-tenant authentication policy configuration"""

from __future__ import annotations

from sqlalchemy import Integer, Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from db.base import Base


class TenantAuthSettings(Base):
    __tablename__ = "tenant_auth_settings"

    tenant_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id"), primary_key=True
    )

    mfa_required: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")
    password_min_length: Mapped[int] = mapped_column(Integer, nullable=False, server_default="12")
    password_require_special: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")

    lockout_threshold: Mapped[int] = mapped_column(Integer, nullable=False, server_default="5")
    lockout_duration_minutes: Mapped[int] = mapped_column(Integer, nullable=False, server_default="30")

    session_timeout_minutes: Mapped[int] = mapped_column(Integer, nullable=False, server_default="30")