"""Immutable auth event logging"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession
from core.auth.models.auth_audit import AuthAudit
from uuid import uuid4


class AuthAuditService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def log_login_success(self, user_id: str, tenant_id: str, ip: str):
        await self._log("login_success", user_id, tenant_id, {"ip": ip})

    async def log_login_failure(self, tenant_id: str, identifier: str, ip: str):
        await self._log("login_failure", None, tenant_id, {"identifier": identifier, "ip": ip})

    async def _log(self, event_type: str, user_id: str | None, tenant_id: str | None, details: dict):
        audit = AuthAudit(
            id=uuid4(),
            tenant_id=tenant_id,
            user_id=user_id,
            event_type=event_type,
            ip_address=details.get("ip"),
            details=details,
        )
        self.db.add(audit)
        await self.db.commit()