"""Secure password hashing and policy enforcement"""

from __future__ import annotations

import re
import bcrypt


class PasswordPolicyError(ValueError):
    pass


class PasswordService:
    COST = 13

    def hash(self, password: str) -> str:
        salt = bcrypt.gensalt(rounds=self.COST)
        return bcrypt.hashpw(password.encode(), salt).decode()

    def verify(self, password: str, hashed: str) -> bool:
        return bcrypt.checkpw(password.encode(), hashed.encode())

    def enforce_policy(self, password: str, min_length: int = 12, require_special: bool = True) -> None:
        if len(password) < min_length:
            raise PasswordPolicyError(f"Password must be at least {min_length} characters")
        if require_special and not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
            raise PasswordPolicyError("Password must contain a special character")
        if not re.search(r"[A-Z]", password):
            raise PasswordPolicyError("Password must contain an uppercase letter")
        if not re.search(r"[a-z]", password):
            raise PasswordPolicyError("Password must contain a lowercase letter")
        if not re.search(r"\d", password):
            raise PasswordPolicyError("Password must contain a digit")