"""Redis + DB coordinated session storage and revocation"""

from __future__ import annotations

from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete
from redis.asyncio import Redis
from core.auth.models.session import Session
from core.config import settings

redis = Redis.from_url(settings.REDIS_URL)


class SessionService:
    PREFIX = "session:"

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, user_id: str, tenant_id: str, refresh_token: str) -> None:
        expires_in = timedelta(days=7)
        session = Session(
            user_id=user_id,
            tenant_id=tenant_id,
            refresh_token=refresh_token,
            expires_at=datetime.utcnow() + expires_in,
        )
        self.db.add(session)
        await self.db.commit()

        await redis.setex(f"{self.PREFIX}{user_id}", expires_in, refresh_token)

    async def validate(self, user_id: str, refresh_token: str) -> bool:
        session = await self.db.get(Session, user_id)
        if not session or session.refresh_token != refresh_token or session.is_expired():
            return False
        redis_token = await redis.get(f"{self.PREFIX}{user_id}")
        return redis_token == refresh_token.encode()

    async def revoke_all_for_user(self, user_id: str) -> None:
        await redis.delete(f"{self.PREFIX}{user_id}")
        await self.db.execute(delete(Session).where(Session.user_id == user_id))
        await self.db.commit()