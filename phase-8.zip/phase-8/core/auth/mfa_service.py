"""Full TOTP + recovery code flow"""

from __future__ import annotations

import pyotp
import qrcode
from io import BytesIO
import base64


class MFAService:
    def generate_secret(self) -> str:
        return pyotp.random_base32()

    def get_qr_code(self, secret: str, email: str, issuer: str = "DriftZero") -> str:
        totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(name=email, issuer_name=issuer)
        qr = qrcode.QRCode()
        qr.add_data(totp_uri)
        qr.make(fit=True)
        img = qr.make_image()
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode()

    def verify_totp(self, token: str, secret: str, window: int = 1) -> bool:
        totp = pyotp.TOTP(secret)
        return totp.verify(token, valid_window=window)

    def generate_recovery_codes(self, count: int = 10) -> list[str]:
        return [pyotp.random_base32()[:16] for _ in range(count)]