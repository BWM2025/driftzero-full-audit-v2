"""Stateless JWT creation and validation with type tagging"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
from core.config import settings


class JWTService:
    ALGORITHM = "HS256"
    ACCESS_EXPIRES_MINUTES = 60
    REFRESH_EXPIRES_DAYS = 7

    def create_access_token(self, user_id: str, tenant_id: str, roles: list[str]) -> str:
        expire = datetime.now(timezone.utc) + timedelta(minutes=self.ACCESS_EXPIRES_MINUTES)
        payload = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "roles": roles,
            "exp": expire,
            "iat": datetime.now(timezone.utc),
            "type": "access",
        }
        return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=self.ALGORITHM)

    def create_refresh_token(self, user_id: str, tenant_id: str) -> str:
        expire = datetime.now(timezone.utc) + timedelta(days=self.REFRESH_EXPIRES_DAYS)
        payload = {
            "user_id": user_id,
            "tenant_id": tenant_id,
            "exp": expire,
            "iat": datetime.now(timezone.utc),
            "type": "refresh",
        }
        return jwt.encode(payload, settings.JWT_SECRET_KEY, algorithm=self.ALGORITHM)

    def decode_access_token(self, token: str) -> dict[str, Any]:
        payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[self.ALGORITHM])
        if payload.get("type") != "access":
            raise jwt.InvalidTokenError("Not an access token")
        return payload

    def decode_refresh_token(self, token: str) -> dict[str, Any]:
        payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[self.ALGORITHM])
        if payload.get("type") != "refresh":
            raise jwt.InvalidTokenError("Not a refresh token")
        return payload