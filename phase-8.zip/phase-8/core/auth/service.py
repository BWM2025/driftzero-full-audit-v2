"""Central authentication service orchestrating login, logout, refresh, MFA, and password reset"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from core.auth.jwt_service import JWTService
from core.auth.password_service import PasswordService
from core.auth.session_service import SessionService
from core.auth.mfa_service import MFAService
from core.auth.audit_service import AuthAuditService
from core.auth.login_throttle_service import LoginThrottleService
from core.auth.models.user import User
from core.auth.exceptions import (
    InvalidCredentialsError,
    AccountLockedError,
    AccountInactiveError,
    MFARequiredError,
)


class AuthService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.jwt = JWTService()
        self.password = PasswordService()
        self.session = SessionService(db)
        self.mfa = MFAService()
        self.audit = AuthAuditService(db)
        self.throttle = LoginThrottleService(db)

    async def authenticate_user(
        self, tenant_id: str, identifier: str, password: str, ip_address: str
    ) -> User:
        user = await self.db.get(User, identifier, tenant_id=tenant_id)
        if not user or not user.is_active:
            raise AccountInactiveError()
        if user.is_locked:
            raise AccountLockedError()

        await self.throttle.record_attempt(user.id, ip_address, success=False)

        if not self.password.verify(password, user.password_hash):
            if user.failed_login_attempts + 1 >= 5:
                user.is_locked = True
            user.failed_login_attempts += 1
            await self.db.commit()
            raise InvalidCredentialsError()

        user.failed_login_attempts = 0
        user.last_login_at = datetime.utcnow()
        await self.throttle.record_attempt(user.id, ip_address, success=True)
        await self.audit.log_login_success(user.id, tenant_id, ip_address)
        return user

    async def login(self, tenant_id: str, identifier: str, password: str, ip_address: str) -> dict[str, Any]:
        user = await self.authenticate_user(tenant_id, identifier, password, ip_address)

        if user.mfa_enabled:
            raise MFARequiredError()

        access_token = self.jwt.create_access_token(str(user.id), tenant_id, user.roles)
        refresh_token = self.jwt.create_refresh_token(str(user.id), tenant_id)

        await self.session.create(user.id, tenant_id, refresh_token)

        return {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "expires_in": 3600,
            "user": {
                "id": str(user.id),
                "username": user.username,
                "email": user.email,
                "roles": user.roles,
                "mfa_enabled": user.mfa_enabled,
            },
        }

    async def refresh_token(self, tenant_id: str, refresh_token: str) -> dict[str, Any]:
        payload = self.jwt.decode_refresh_token(refresh_token)
        if payload["tenant_id"] != tenant_id:
            raise InvalidCredentialsError()

        if not await self.session.validate(payload["user_id"], refresh_token):
            raise InvalidCredentialsError()

        user = await self.db.get(User, payload["user_id"])
        access_token = self.jwt.create_access_token(str(user.id), tenant_id, user.roles)
        return {"access_token": access_token, "token_type": "bearer", "expires_in": 3600}

    async def logout(self, user_id: str, tenant_id: str, refresh_token: str) -> None:
        await self.session.revoke_by_token(refresh_token)
        await self.audit.log_logout(user_id, tenant_id)