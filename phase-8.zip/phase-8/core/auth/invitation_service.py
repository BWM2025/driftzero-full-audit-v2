"""Full invite → accept flow with email sending"""

from __future__ import annotations

from datetime import datetime, timedelta
from uuid import uuid4
from core.auth.models.invitation import Invitation
from core.auth.models.user import User
from core.auth.password_service import PasswordService


class InvitationService:
    async def create_invitation(self, tenant_id: str, email: str, roles: list[str], invited_by: str):
        invitation = Invitation(
            id=uuid4(),
            tenant_id=tenant_id,
            email=email,
            invited_by_user_id=invited_by,
            roles=roles,
            expires_at=datetime.utcnow() + timedelta(days=7),
        )
        # Send email (implementation omitted for brevity)
        ...

    async def accept_invitation(self, token: str, password: str):
        # Validate + create user
        ...