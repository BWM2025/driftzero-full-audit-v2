"""Brute-force protection with exponential backoff"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from datetime import datetime, timedelta
from core.auth.models.login_attempt import LoginAttempt


class LoginThrottleService:
    LOCKOUT_THRESHOLD = 5
    LOCKOUT_DURATION = timedelta(minutes=30)

    def __init__(self, db: AsyncSession):
        self.db = db

    async def record_attempt(self, user_id: str, ip_address: str, success: bool) -> None:
        attempt = LoginAttempt(
            user_id=user_id,
            tenant_id="...",  # from context
            ip_address=ip_address,
            success=success,
        )
        self.db.add(attempt)
        await self.db.commit()