"""Immediate token revocation tracking"""

from __future__ import annotations

from datetime import timedelta
from redis.asyncio import Redis
from core.config import settings

redis = Redis.from_url(settings.REDIS_URL)


class TokenBlacklist:
    PREFIX = "blacklist:"

    @staticmethod
    async def blacklist(token: str, expires_in: timedelta) -> None:
        token_hash = hash(token)
        await redis.setex(f"{TokenBlacklist.PREFIX}{token_hash}", expires_in, "1")

    @staticmethod
    async def is_blacklisted(token: str) -> bool:
        token_hash = hash(token)
        return await redis.exists(f"{TokenBlacklist.PREFIX}{token_hash}") == 1