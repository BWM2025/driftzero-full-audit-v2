"""Role hierarchy and permission resolution"""

from __future__ import annotations

from typing import List


ROLE_HIERARCHY = {
    "admin": 100,
    "approver": 80,
    "operator": 60,
    "viewer": 40,
}


class RBACService:
    @staticmethod
    def has_permission(user_roles: List[str], required_role: str) -> bool:
        user_level = max(ROLE_HIERARCHY.get(role, 0) for role in user_roles)
        return user_level >= ROLE_HIERARCHY.get(required_role, 0)

    @staticmethod
    def has_any_permission(user_roles: List[str], required_roles: List[str]) -> bool:
        return any(RBACService.has_permission(user_roles, role) for role in required_roles)