"""SAML Assertion Consumer Service — pure logic"""
from __future__ import annotations
from typing import Any
from core.sso.saml2.provider import SAML2Provider
def handle_acs(saml_response: str, relay_state: str | None, provider: SAML2Provider) -> dict[str, Any]:
    request_data = {
        "https": "on",
        "http_host": "app.driftzero.com",
        "script_name": "/api/v1/sso/saml/acs",
        "post_data": {"SAMLResponse": saml_response, "RelayState": relay_state or ""},
    }
    return provider.process_response(request_data)