"""Full SAML 2.0 Service Provider — python3-saml — production hardened"""
from __future__ import annotations
from typing import Any
from onelogin.saml2.auth import OneLogin_Saml2_Auth
from onelogin.saml2.settings import OneLogin_Saml2_Settings
from core.config import settings
class SAML2Provider:
    def __init__(self, tenant_id: str, idp_metadata: str):
        self.tenant_id = tenant_id
        self.sp_config = {
            "strict": True,
            "debug": settings.DEBUG,
            "sp": {
                "entityId": f"https://app.driftzero.com/sso/saml/metadata/{tenant_id}",
                "assertionConsumerService": {
                    "url": f"https://app.driftzero.com/api/v1/sso/saml/acs/{tenant_id}",
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
                },
                "singleLogoutService": {
                    "url": f"https://app.driftzero.com/api/v1/sso/saml/slo/{tenant_id}",
                    "binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"
                },
                "NameIDFormat": "urn:oasis:names:tc:SAML:1.nameid-format:transient",
                "x509cert": "",
                "privateKey": "",
            },
            "idp": OneLogin_Saml2_IdPMetadataParser.parse(idp_metadata),
            "security": {
                "authnRequestsSigned": True,
                "logoutRequestSigned": True,
                "logoutResponseSigned": True,
                "signMetadata": True,
                "wantMessagesSigned": True,
                "wantAssertionsSigned": True,
                "wantAssertionsEncrypted": True,
                "wantNameId": True,
                "wantNameIdEncrypted": False,
                "signatureAlgorithm": "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256",
                "digestAlgorithm": "http://www.w3.org/2001/04/xmlenc#sha256",
            },
        }
        self.settings = OneLogin_Saml2_Settings(settings=self.sp_config)
    def get_auth(self, request_data: dict) -> OneLogin_Saml2_Auth:
        return OneLogin_Saml2_Auth(request_data, old_settings=self.settings)
    def build_authn_request(self, relay_state: str | None = None) -> str:
        auth = self.get_auth({})
        return auth.login(return_to=relay_state)
    def process_response(self, request_data: dict) -> dict[str, Any]:
        auth = self.get_auth(request_data)
        auth.process_response()
        errors = auth.get_errors()
        if errors:
            raise ValueError(f"SAML errors: {errors}")
        if not auth.is_authenticated():
            raise ValueError("SAML authentication failed")
        attrs = auth.get_attributes()
        return {
            "email": attrs.get("email", [""])[0] or attrs.get("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress", [""])[0],
            "first_name": attrs.get("givenName", [""])[0] or attrs.get("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname", [""])[0],
            "last_name": attrs.get("surname", [""])[0] or attrs.get("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname", [""])[0],
            "roles": attrs.get("roles", []),
            "name_id": auth.get_nameid(),
            "session_index": auth.get_session_index(),
        }