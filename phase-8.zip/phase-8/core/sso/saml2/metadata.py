"""Dynamic SP metadata generation per tenant"""
from __future__ import annotations
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.dom import minidom
def generate_sp_metadata(tenant_id: str, cert: str) -> str:
    ns = {
        "md": "urn:oasis:names:tc:SAML:2.0:metadata",
        "ds": "http://www.w3.org/2000/09/xmldsig#",
    }
    entity = Element("md:EntityDescriptor", {
        "entityID": f"https://app.driftzero.com/sso/saml/metadata/{tenant_id}",
        **{f"xmlns:{k}": v for k, v in ns.items()}
    })
    sp = SubElement(entity, "md:SPSSODescriptor", {
        "protocolSupportEnumeration": "urn:oasis:names:tc:SAML:2.0:protocol",
        "AuthnRequestsSigned": "true",
        "WantAssertionsSigned": "true",
    })
    key = SubElement(sp, "md:KeyDescriptor", {"use": "signing"})
    key_info = SubElement(key, "ds:KeyInfo")
    x509 = SubElement(key_info, "ds:X509Data")
    x509_cert = SubElement(x509, "ds:X509Certificate")
    x509_cert.text = cert.replace("\n", "")
    acs = SubElement(sp, "md:AssertionConsumerService", {
        "Binding": "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST",
        "Location": f"https://app.driftzero.com/api/v1/sso/saml/acs/{tenant_id}",
        "index": "1",
        "isDefault": "true",
    })
    xml_str = tostring(entity, encoding="unicode")
    return minidom.parseString(xml_str).toprettyxml(indent=" ")