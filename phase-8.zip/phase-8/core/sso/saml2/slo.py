"""Single Logout — IdP and SP initiated"""
from __future__ import annotations
from core.sso.saml2.provider import SAML2Provider
class SAML2SLO:
    def __init__(self, provider: SAML2Provider):
        self.provider = provider
    def initiate_logout(self, name_id: str, session_index: str) -> str:
        auth = self.provider.get_auth({})
        return auth.logout(name_id=name_id, session_index=session_index)
    def process_logout(self, request_data: dict) -> None:
        auth = self.provider.get_auth(request_data)
        auth.process_slo()
        if auth.get_errors():
            raise ValueError("SLO failed")