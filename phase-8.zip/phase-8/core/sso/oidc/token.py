"""OIDC token exchange and validation"""
from __future__ import annotations
from authlib.jose import jwt, JsonWebToken
from core.sso.oidc.jwks import get_jwks
async def validate_id_token(token: str, issuer: str, audience: str) -> dict:
    jwks = await get_jwks(issuer)
    claims = jwt.decode(token, jwks)
    claims.validate()
    if claims["iss"] != issuer or audience not in claims.get("aud", []):
        raise ValueError("Invalid token claims")
    return claims