"""OIDC discovery document caching"""
from __future__ import annotations
import httpx
import json
from redis.asyncio import Redis
from core.config import settings
redis = Redis.from_url(settings.REDIS_URL)
async def get_discovery_document(issuer: str) -> dict:
    key = f"oidc:discovery:{issuer}"
    cached = await redis.get(key)
    if cached:
        return json.loads(cached)
    async with httpx.AsyncClient() as client:
        resp = await client.get(f"{issuer}/.well-known/openid-configuration")
        resp.raise_for_status()
        data = resp.json()
        await redis.setex(key, 86400, json.dumps(data))
        return data