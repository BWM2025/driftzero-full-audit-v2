"""Fetch and map OIDC UserInfo"""
from __future__ import annotations
import httpx
async def get_userinfo(access_token: str, userinfo_endpoint: str) -> dict:
    headers = {"Authorization": f"Bearer {access_token}"}
    async with httpx.AsyncClient() as client:
        resp = await client.get(userinfo_endpoint, headers=headers)
        resp.raise_for_status()
        return resp.json()