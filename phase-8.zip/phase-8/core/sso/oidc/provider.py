"""OpenID Connect client — Auth0 / Okta / Azure AD / Google"""
from __future__ import annotations
from authlib.integrations.starlette_client import StarletteOAuth2App
from starlette.requests import Request
class OIDCProvider:
    def __init__(self, tenant_id: str, client_id: str, client_secret: str, issuer: str):
        self.client = StarletteOAuth2App(
            client_id=client_id,
            client_secret=client_secret,
            server_metadata_url=f"{issuer}/.well-known/openid-configuration",
            client_kwargs={"scope": "openid email profile"},
        )
    async def authorize_redirect(self, request: Request, redirect_uri: str):
        return await self.client.authorize_redirect(request, redirect_uri)
    async def get_userinfo(self, request: Request) -> dict:
        token = await self.client.authorize_access_token(request)
        userinfo = token.get("userinfo")
        if not userinfo:
            userinfo = await self.client.userinfo(token=token)
        return {
            "email": userinfo["email"],
            "first_name": userinfo.get("given_name"),
            "last_name": userinfo.get("family_name"),
            "roles": userinfo.get("roles", []),
        }