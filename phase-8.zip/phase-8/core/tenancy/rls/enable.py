"""One-time idempotent RLS activation for all tenant-scoped tables"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text


TABLES = [
    "users", "sessions", "login_attempts", "invitations", "mfa_recovery_codes",
    "tenants", "drift_incidents", "drift_sagas", "patch_manifests",
    "quarantine_records", "approval_requests", "approval_decisions",
    "approval_assignments", "billing_customers", "billing_subscriptions",
    "audit_trail", "auth_audit", "rate_limit_events",
]


async def enable_rls_on_all_tables(db: AsyncSession) -> None:
    """Enable RLS and create tenant isolation policies — fully idempotent"""
    for table in TABLES:
        # Enable RLS
        await db.execute(text(f"ALTER TABLE {table} ENABLE ROW LEVEL SECURITY"))

        # Drop existing policy if any
        await db.execute(text(f"DROP POLICY IF EXISTS tenant_isolation ON {table}"))

        # Create strict isolation policy
        await db.execute(text(f"""
            CREATE POLICY tenant_isolation ON {table}
            USING (tenant_id = current_setting('app.current_tenant')::uuid)
            WITH CHECK (tenant_id = current_setting('app.current_tenant')::uuid)
        """))

    await db.commit()