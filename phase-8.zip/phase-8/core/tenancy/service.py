"""Real tenant provisioning and lifecycle management"""

from __future__ import annotations

from uuid import uuid4
from sqlalchemy.ext.asyncio import AsyncSession
from core.auth.models.tenant import Tenant
from core.auth.models.tenant_auth_settings import TenantAuthSettings


class TenantService:
    async def create_tenant(
        self,
        db: AsyncSession,
        name: str,
        slug: str,
        admin_email: str,
    ) -> Tenant:
        tenant = Tenant(id=uuid4(), name=name, slug=slug, is_active=True)
        db.add(tenant)

        # Default security settings
        settings = TenantAuthSettings(tenant_id=tenant.id)
        db.add(settings)

        await db.commit()
        await db.refresh(tenant)
        return tenant

    async def deactivate_tenant(self, db: AsyncSession, tenant_id: str) -> None:
        await db.execute(
            text("UPDATE tenants SET is_active = false WHERE id = :tid"),
            {"tid": tenant_id},
        )
        await db.commit()