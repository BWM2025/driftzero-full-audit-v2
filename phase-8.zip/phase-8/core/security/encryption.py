"""Field-level encryption using Fernet"""

from __future__ import annotations

from cryptography.fernet import Fernet
import base64
from core.config import settings


class FieldEncryptor:
    def __init__(self):
        key = base64.urlsafe_b64decode(settings.ENCRYPTION_KEY)  # 32-byte key from Vault
        self.fernet = Fernet(key)

    def encrypt(self, plaintext: str) -> str:
        return self.fernet.encrypt(plaintext.encode()).decode()

    def decrypt(self, ciphertext: str) -> str:
        return self.fernet.decrypt(ciphertext.encode()).decode()