"""Immutable security audit logging"""

from __future__ import annotations

from uuid import uuid4
from sqlalchemy.ext.asyncio import AsyncSession
from core.auth.models.auth_audit import AuthAudit


class SecurityAuditLogger:
    async def log(
        self,
        db: AsyncSession,
        event_type: str,
        user_id: str | None,
        tenant_id: str | None,
        details: dict | None = None,
        ip_address: str | None = None,
    ) -> None:
        audit = AuthAudit(
            id=uuid4(),
            tenant_id=tenant_id,
            user_id=user_id,
            event_type=event_type,
            ip_address=ip_address,
            details=details or {},
        )
        db.add(audit)
        await db.commit()