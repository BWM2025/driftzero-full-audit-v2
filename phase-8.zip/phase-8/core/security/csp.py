"""Dynamic CSP with per-request nonce"""

import secrets
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request


class CSPMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        nonce = secrets.token_urlsafe(16)
        request.state.csp_nonce = nonce

        csp = (
            "default-src 'self'; "
            f"script-src 'self' 'nonce-{nonce}' https://cdn.jsdelivr.net; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob:; "
            "font-src 'self'; "
            "object-src 'none'; "
            "frame-ancestors 'none';"
        )

        response = await call_next(request)
        response.headers["Content-Security-Policy"] = csp
        return response