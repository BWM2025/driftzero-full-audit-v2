"""Unified interface to Vault / AWS SM / GCP SM"""

from __future__ import annotations

from abc import ABC, abstractmethod
import os
import hvac
import boto3
from google.cloud import secretmanager


class SecretProvider(ABC):
    @abstractmethod
    def get_secret(self, key: str) -> str: ...

    @abstractmethod
    def set_secret(self, key: str, value: str) -> None: ...


class VaultProvider(SecretProvider):
    def __init__(self):
        self.client = hvac.Client(url=os.getenv("VAULT_ADDR"))
        self.client.token = os.getenv("VAULT_TOKEN")

    def get_secret(self, key: str) -> str:
        resp = self.client.secrets.kv.v2.read_secret_version(path=key)
        return resp["data"]["data"]["value"]

    def set_secret(self, key: str, value: str) -> None:
        self.client.secrets.kv.v2.create_or_update_secret(path=key, secret={"value": value})