"""Redis token bucket with DB fallback"""

from __future__ import annotations

import time
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession
from core.config import settings

redis = Redis.from_url(settings.REDIS_URL)


class RateLimiter:
    def __init__(self, rate: int, per: int):
        self.rate = rate
        self.per = per

    async def is_allowed(self, key: str) -> bool:
        now = int(time.time())
        pipeline = redis.pipeline()
        pipeline.zremrangebyscore(key, 0, now - self.per)
        pipeline.zcard(key)
        pipeline.zadd(key, {now: now})
        pipeline.expire(key, self.per)
        _, count = await pipeline.execute()[:2]
        return count <= self.rate