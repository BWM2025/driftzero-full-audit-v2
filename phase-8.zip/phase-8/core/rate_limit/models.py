"""Persistent rate limit event tracking — Redis fallback"""

from __future__ import annotations

from uuid import uuid4
from datetime import datetime
from sqlalchemy import DateTime, func, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from db.base import Base


class RateLimitEvent(Base):
    __tablename__ = "rate_limit_events"

    id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    tenant_id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tenants.id"), index=True)
    user_id: Mapped[UUID | None] = mapped_column(UUID(as_uuid=True), nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    endpoint: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        sa.Index("ix_rl_tenant_endpoint", "tenant_id", "endpoint", "created_at"),
        sa.Index("ix_rl_ip_endpoint", "ip_address", "endpoint", "created_at"),
    )