"""@rate_limit decorator — IP + tenant scopes"""

from __future__ import annotations

from functools import wraps
from fastapi import Request, HTTPException
from core.rate_limit.service import RateLimiter


def rate_limit(rate: int, per: int, scope: str = "ip"):
    limiter = RateLimiter(rate, per, scope)

    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            db = kwargs.get("db")
            if not await limiter.is_allowed(request, db):
                raise HTTPException(
                    status_code=429,
                    detail="Rate limit exceeded",
                    headers={"Retry-After": str(per)},
                )
            return await func(request, *args, **kwargs)
        return wrapper
    return decorator