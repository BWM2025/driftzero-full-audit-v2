"""Hybrid Redis + DB token bucket — survives Redis outage"""

from __future__ import annotations

import time
from redis.asyncio import Redis
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from datetime import datetime, timedelta
from core.rate_limit.models import RateLimitEvent
from core.config import settings

redis = Redis.from_url(settings.REDIS_URL)


class RateLimiter:
    def __init__(self, rate: int, per: int, scope: str = "ip"):
        self.rate = rate
        self.per = per
        self.scope = scope

    async def _redis_is_allowed(self, key: str) -> bool:
        now = int(time.time())
        p = redis.pipeline()
        p.zremrangebyscore(key, 0, now - self.per)
        p.zcard(key)
        p.zadd(key, {now: now})
        p.expire(key, self.per)
        _, count = await p.execute()[:2]
        return count <= self.rate

    async def _db_count(self, db: AsyncSession, key: str) -> int:
        cutoff = datetime.utcnow() - timedelta(seconds=self.per)
        result = await db.execute(
            select(func.count()).select_from(RateLimitEvent).where(
                and_(
                    RateLimitEvent.endpoint == key,
                    RateLimitEvent.created_at > cutoff,
                )
            )
        )
        return result.scalar() or 0

    async def is_allowed(self, request, db: AsyncSession | None) -> bool:
        key = f"rl:{self.scope}:{request.client.host if self.scope == 'ip' else request.state.tenant_id}"

        try:
            if await self._redis_is_allowed(key):
                if db:
                    event = RateLimitEvent(
                        tenant_id=getattr(request.state, "tenant_id", None),
                        ip_address=request.client.host,
                        endpoint=key,
                    )
                    db.add(event)
                return True
        except Exception:
            pass  # Redis down

        if db and await self._db_count(db, key) < self.rate:
            event = RateLimitEvent(
                tenant_id=getattr(request.state, "tenant_id", None),
                ip_address=request.client.host,
                endpoint=key,
            )
            db.add(event)
            return True
        return False