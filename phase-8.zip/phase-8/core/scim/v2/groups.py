"""SCIM /Groups endpoint"""
from fastapi import APIRouter
from core.scim.v2.service import SCIM2Service
router = APIRouter()
@router.get("/Groups")
async def list_groups(service: SCIM2Service = Depends()):
    return await service.list_groups()