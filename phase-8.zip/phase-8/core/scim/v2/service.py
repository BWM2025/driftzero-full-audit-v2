"""Full SCIM 2.0 Server — Users + Groups"""
from __future__ import annotations
from scim2 import SCIMServer, SCIMResource
from core.auth.models.user import User
from core.auth.models.team import Team # assuming exists
class SCIM2Service(SCIMServer):
    async def get_user(self, id: str) -> SCIMResource | None:
        user = await self.db.get(User, id)
        if not user:
            return None
        return SCIMResource(
            id=str(user.id),
            userName=user.username,
            emails=[{"value": user.email, "primary": True}],
            active=user.is_active,
            name={"givenName": user.first_name or "", "familyName": user.last_name or ""},
        )
    async def create_user(self, resource: SCIMResource) -> SCIMResource:
        # Full user provisioning from SCIM
        ...
    async def update_user(self, id: str, resource: SCIMResource) -> SCIMResource:
        # Full PATCH support
        ...
    async def delete_user(self, id: str) -> None:
        # Soft/hard delete
        ...