"""SCIM /Users endpoint"""
from fastapi import APIRouter
from core.scim.v2.service import SCIM2Service
router = APIRouter()
@router.get("/Users")
async def list_users(service: SCIM2Service = Depends()):
    return await service.list_users()
@router.post("/Users")
async def create_user(payload: dict, service: SCIM2Service = Depends()):
    return await service.create_user(payload)