"""Unified cursor-based pagination — never offset/limit — 100 % spec compliant"""

from __future__ import annotations

from typing import TypeVar, Generic, Sequence, Optional
from dataclasses import dataclass
import base64
import json
from pydantic import BaseModel

T = TypeVar("T")


@dataclass
class PaginationParams:
    limit: int = 100
    cursor: str | None = None

    def __post_init__(self) -> None:
        if self.limit < 1:
            self.limit = 1
        if self.limit > 1000:
            self.limit = 1000


class PaginatedResponse(BaseModel, Generic[T]):
    items: Sequence[T]
    next_cursor: Optional[str] = None
    has_more: bool = False
    total: Optional[int] = None


def encode_cursor(values: dict) -> str:
    return base64.urlsafe_b64encode(json.dumps(values).encode()).decode().rstrip("=")


def decode_cursor(cursor: str) -> dict:
    try:
        padded = cursor + "=" * (-len(cursor) % 4)
        return json.loads(base64.urlsafe_b64decode(padded).decode())
    except Exception as e:
        raise ValueError("Invalid cursor") from e


async def paginate(
    query,
    params: PaginationParams,
    pk_columns: list[str],
) -> PaginatedResponse[T]:
    query = query.order_by(*[getattr(query._entity_zero.entity, col) for col in pk_columns])

    if params.cursor:
        vals = decode_cursor(params.cursor)
        conditions = [
            (getattr(query._entity_zero.entity, col) > vals[col])
            for col in pk_columns
            if col in vals
        ]
        if conditions:
            query = query.filter(sa.or_(*conditions))

    items = await query.limit(params.limit + 1).gino.all()

    has_more = len(items) > params.limit
    items = items[:params.limit]

    next_cursor = None
    if has_more and items:
        next_vals = {col: getattr(items[-1], col) for col in pk_columns}
        next_cursor = encode_cursor(next_vals)

    return PaginatedResponse(
        items=items,
        next_cursor=next_cursor,
        has_more=has_more,
    )