"""Statistical anomaly detection — Mann-Whitney U + Chi-squared"""

from __future__ import annotations

import numpy as np
from scipy.stats import mannwhitneyu, chi2_contingency


class CanaryMetricsComparator:
    def calculate_anomaly_score(self, baseline: dict, canary: dict) -> float:
        score = 0.0

        # Error rate: Chi-squared test
        if baseline["error_rate"] > 0:
            observed = np.array([
                [canary["errors"], canary["total"] - canary["errors"]],
                [baseline["errors"], baseline["total"] - baseline["errors"]],
            ])
            _, p_value, _, _ = chi2_contingency(observed)
            if p_value < 0.01:
                score += 0.6

        # Latency: Mann-Whitney U test
        if len(canary["latencies"]) > 10 and len(baseline["latencies"]) > 10:
            _, p_value = mannwhitneyu(canary["latencies"], baseline["latencies"], alternative="greater")
            if p_value < 0.01:
                score += 0.4

        return min(score, 1.0)