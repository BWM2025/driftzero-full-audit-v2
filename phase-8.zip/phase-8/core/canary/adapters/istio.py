"""Real Istio VirtualService traffic shifting"""

from __future__ import annotations

from kubernetes import client, config
from kubernetes.client.rest import ApiException


class IstioCanaryAdapter:
    def __init__(self):
        config.load_incluster_config()
        self.api = client.CustomObjectsApi()

    async def apply_traffic_shift(self, patch_id: str, percentage: int) -> None:
        vs_name = f"driftzero-canary-{patch_id}"
        vs = {
            "apiVersion": "networking.istio.io/v1beta1",
            "kind": "VirtualService",
            "metadata": {"name": vs_name, "namespace": "driftzero"},
            "spec": {
                "hosts": ["payments.prod.svc.cluster.local"],
                "http": [
                    {
                        "route": [
                            {"destination": {"host": "payments-prod"}, "weight": 100 - percentage},
                            {"destination": {"host": f"payments-canary-{patch_id}"}, "weight": percentage},
                        ]
                    }
                ],
            },
        }
        try:
            self.api.create_namespaced_custom_object(
                group="networking.istio.io",
                version="v1beta1",
                namespace="driftzero",
                plural="virtualservices",
                body=vs,
            )
        except ApiException:
            self.api.replace_namespaced_custom_object(
                group="networking.istio.io",
                version="v1beta1",
                namespace="driftzero",
                plural="virtualservices",
                name=vs_name,
                body=vs,
            )