"""BigQuery slot reservation for canary queries"""

from __future__ import annotations

from google.cloud import bigquery_reservation_v1


class BigQuerySlotCanaryAdapter:
    def __init__(self, project_id: str, location: str = "US"):
        self.client = bigquery_reservation_v1.ReservationServiceClient()
        self.parent = f"projects/{project_id}/locations/{location}"

    def create_canary_reservation(self, patch_id: str, slots: int = 100):
        reservation = bigquery_reservation_v1.Reservation()
        reservation.name = f"{self.parent}/reservations/canary-{patch_id}"
        reservation.slot_capacity = slots
        self.client.create_reservation(parent=self.parent, reservation=reservation)