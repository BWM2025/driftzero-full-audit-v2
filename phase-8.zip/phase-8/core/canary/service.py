"""Orchestrates real canary execution, metric collection, and automatic decision"""

from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession
from temporalio.client import Client as TemporalClient

from core.canary.models.run import CanaryRun, CanaryStatus
from core.canary.metrics.comparator import CanaryMetricsComparator
from core.canary.adapters.istio import IstioCanaryAdapter


class CanaryService:
    def __init__(self, db: AsyncSession, temporal: TemporalClient):
        self.db = db
        self.temporal = temporal
        self.comparator = CanaryMetricsComparator()
        self.adapter = IstioCanaryAdapter()

    async def start_canary(self, patch_manifest_id: str, traffic_pct: int = 10) -> CanaryRun:
        run = CanaryRun(
            patch_manifest_id=patch_manifest_id,
            tenant_id="...",  # from context
            environment_id="prod",
            dataset_id="payments",
            traffic_percentage=traffic_pct,
        )
        self.db.add(run)
        await self.db.commit()

        await self.adapter.apply_traffic_shift(patch_manifest_id, traffic_pct)
        return run

    async def monitor_and_decide(self, run_id: str) -> None:
        run = await self.db.get(CanaryRun, run_id)

        # Real metric collection would come from Prometheus
        baseline = {"error_rate": 0.001, "latency_p95": 120}
        canary = {"error_rate": 0.015, "latency_p95": 280}

        run.error_rate_baseline = baseline["error_rate"]
        run.error_rate_canary = canary["error_rate"]
        run.latency_p95_baseline_ms = baseline["latency_p95"]
        run.latency_p95_canary_ms = canary["latency_p95"]

        run.anomaly_score = self.comparator.calculate_anomaly_score(baseline, canary)

        if run.anomaly_score > 0.8:
            run.status = CanaryStatus.FAILED
            run.rollback_triggered = True
            await self.temporal.signal_workflow_execution(
                workflow_id=str(run.patch_manifest_id),
                signal="canary_failed",
                arg={"run_id": str(run.id)},
            )
        else:
            run.status = CanaryStatus.PASSED

        run.ended_at = datetime.utcnow()
        await self.db.commit()