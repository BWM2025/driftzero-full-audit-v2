"""Persistent canary run record with full metrics and rollback flag"""

from __future__ import annotations

from uuid import uuid import uuid4
from datetime import datetime
from enum import Enum

from sqlalchemy import String, DateTime, func, ForeignKey, Integer, Numeric, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from db.base import Base


class CanaryStatus(str, Enum):
    RUNNING = "RUNNING"
    PASSED = "PASSED"
    FAILED = "FAILED"
    ABORTED = "ABORTED"


class CanaryRun(Base):
    __tablename__ = "canary_runs"

    id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    patch_manifest_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("patch_manifests.id"), nullable=False, index=True
    )
    tenant_id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False, index=True)
    environment_id: Mapped[str] = mapped_column(String(64), nullable=False)
    dataset_id: Mapped[str] = mapped_column(String(256), nullable=False)

    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    status: Mapped[CanaryStatus] = mapped_column(
        sa.Enum(CanaryStatus), nullable=False, server_default="RUNNING"
    )

    traffic_percentage: Mapped[int] = mapped_column(Integer, nullable=False)
    error_rate_baseline: Mapped[float | None] = mapped_column(Numeric(10, 6), nullable=True)
    error_rate_canary: Mapped[float | None] = mapped_column(Numeric(10, 6), nullable=True)
    latency_p95_baseline_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    latency_p95_canary_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)

    anomaly_score: Mapped[float | None] = mapped_column(Numeric(8, 6), nullable=True)
    rollback_triggered: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="false")

    notes: Mapped[str | None] = mapped_column(Text, nullable=True)