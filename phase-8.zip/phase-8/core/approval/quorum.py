"""Configurable quorum logic"""

from __future__ import annotations

from typing import List
from core.approval.models.decision import ApprovalDecision, DecisionType


class QuorumEvaluator:
    def is_met(self, decisions: List[ApprovalDecision], required: int) -> bool:
        approvals = sum(1 for d in decisions if d.decision == DecisionType.APPROVED)
        return approvals >= required