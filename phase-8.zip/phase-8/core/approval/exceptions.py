"""Approval exception hierarchy"""

from __future__ import annotations


class ApprovalError(Exception):
    """Base approval exception"""


class RequestNotFound(ApprovalError):
    pass


class AlreadyDecided(ApprovalError):
    pass


class RequestExpired(ApprovalError):
    pass


class InsufficientApprovals(ApprovalError):
    pass