"""Dataset glob pattern → approver assignment"""

from __future__ import annotations

from uuid import uuid4

from sqlalchemy import String, DateTime, func, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from db.base import Base


class ApprovalAssignment(Base):
    __tablename__ = "approval_assignments"
    __table_args__ = (
        UniqueConstraint("tenant_id", "user_id", "dataset_pattern", name="uq_tenant_user_pattern"),
    )

    id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    tenant_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False, index=True
    )
    user_id: Mapped[str] = mapped_column(String(255), nullable=False)
    dataset_pattern: Mapped[str] = mapped_column(String(512), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())