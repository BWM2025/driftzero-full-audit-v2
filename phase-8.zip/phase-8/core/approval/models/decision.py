"""Individual approver decision with comment and audit"""

from __future__ import annotations

from uuid import uuid4
from datetime import datetime
from enum import Enum

from sqlalchemy import String, DateTime, func, ForeignKey, Text, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db.base import Base


class DecisionType(str, Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class ApprovalDecision(Base):
    __tablename__ = "approval_decisions"

    id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    request_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("approval_requests.id"), nullable=False, index=True
    )
    approver_user_id: Mapped[str] = mapped_column(String(255), nullable=False)
    decision: Mapped[DecisionType] = mapped_column(SQLEnum(DecisionType), nullable=False)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    decided_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    request: Mapped["ApprovalRequest"] = relationship("ApprovalRequest", back_populates="decisions")