"""Production-grade approval request with quorum, expiry, escalation"""

from __future__ import annotations

from typing import List, TYPE_CHECKING
from uuid import uuid4
from datetime import datetime
from enum import Enum

from sqlalchemy import String, DateTime, func, ForeignKey, Integer, Text, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db.base import Base

if TYPE_CHECKING:
    from .decision import ApprovalDecision


class ApprovalStatus(str, Enum):
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class ApprovalRequest(Base):
    __tablename__ = "approval_requests"

    id: Mapped[UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    saga_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("drift_sagas.id"), nullable=False, index=True
    )
    tenant_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("tenants.id"), nullable=False, index=True
    )
    environment_id: Mapped[str] = mapped_column(String(64), nullable=False)
    dataset_id: Mapped[str] = mapped_column(String(256), nullable=False)

    requested_by: Mapped[str] = mapped_column(String(255), nullable=False)
    requested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    required_approvers: Mapped[int] = mapped_column(Integer, nullable=False, server_default="1")

    status: Mapped[ApprovalStatus] = mapped_column(
        SQLEnum(ApprovalStatus), nullable=False, server_default="PENDING", index=True
    )
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    resolved_by: Mapped[str | None] = mapped_column(String(255), nullable=True)
    resolution_reason: Mapped[str | None] = mapped_column(Text, nullable=True)

    decisions: Mapped[List["ApprovalDecision"]] = relationship(
        "ApprovalDecision", back_populates="request", cascade="all, delete-orphan"
    )