"""Immutable approval audit trail"""

from __future__ import annotations

from uuid import uuid4
from sqlalchemy.ext.asyncio import AsyncSession
from core.auth.models.auth_audit import AuthAudit


class ApprovalAuditLogger:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def log_created(self, request) -> None:
        await self._log("approval_request_created", request)

    async def log_decision(self, decision) -> None:
        await self._log("approval_decision", decision.request, {"decision": decision.decision.value})

    async def _log(self, event_type: str, request, details: dict | None = None) -> None:
        audit = AuthAudit(
            id=uuid4(),
            tenant_id=request.tenant_id,
            event_type=event_type,
            details={**details or {}, "request_id": str(request.id)},
        )
        self.db.add(audit)
        await self.db.commit()