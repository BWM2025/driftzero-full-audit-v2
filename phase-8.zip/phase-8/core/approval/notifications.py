"""Email/Slack notifications for approval events"""

from __future__ import annotations

class ApprovalNotifier:
    async def send_requested(self, request, approvers: List[str]) -> None:
        # Send via SendGrid + Slack webhook
        pass

    async def send_decided(self, request, decision) -> None:
        pass