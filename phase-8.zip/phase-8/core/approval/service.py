"""Full approval service — quorum, escalation, Temporal signal"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession
from temporalio.client import Client as TemporalClient

from core.approval.models.request import ApprovalRequest, ApprovalStatus
from core.approval.models.decision import ApprovalDecision, DecisionType
from core.approval.quorum import QuorumEvaluator
from core.approval.audit import ApprovalAuditLogger
from core.approval.exceptions import ApprovalError


class ApprovalService:
    def __init__(self, db: AsyncSession, temporal: TemporalClient):
        self.db = db
        self.temporal = temporal
        self.quorum = QuorumEvaluator()
        self.audit = ApprovalAuditLogger(db)

    async def create_request(
        self,
        saga_id: str,
        tenant_id: str,
        dataset_id: str,
        requested_by: str,
        required_approvers: int = 1,
        ttl_hours: int = 24,
    ) -> ApprovalRequest:
        request = ApprovalRequest(
            saga_id=saga_id,
            tenant_id=tenant_id,
            dataset_id=dataset_id,
            requested_by=requested_by,
            required_approvers=required_approvers,
            expires_at=datetime.utcnow() + timedelta(hours=ttl_hours),
        )
        self.db.add(request)
        await self.db.commit()
        await self.audit.log_created(request)
        return request

    async def submit_decision(
        self,
        request_id: str,
        approver_user_id: str,
        decision: DecisionType,
        comment: str | None = None,
    ) -> None:
        request = await self.db.get(ApprovalRequest, request_id)
        if request.status != ApprovalStatus.PENDING:
            raise ApprovalError("Request already resolved")

        existing = await self.db.execute(
            select(ApprovalDecision).where(
                ApprovalDecision.request_id == request_id,
                ApprovalDecision.approver_user_id == approver_user_id,
            )
        )
        if existing.scalar_one_or_none():
            raise ApprovalError("Already decided")

        decision_obj = ApprovalDecision(
            request_id=request_id,
            approver_user_id=approver_user_id,
            decision=decision,
            comment=comment,
        )
        self.db.add(decision_obj)
        await self.db.commit()
        await self.audit.log_decision(decision_obj)

        await self._check_and_resolve(request)

    async def _check_and_resolve(self, request: ApprovalRequest) -> None:
        decisions = await self.db.execute(
            select(ApprovalDecision).where(ApprovalDecision.request_id == request.id)
        )
        decisions = decisions.scalars().all()

        if self.quorum.is_met(decisions, request.required_approvers):
            if any(d.decision == DecisionType.REJECTED for d in decisions):
                request.status = ApprovalStatus.REJECTED
                request.resolution_reason = "Rejected by approver"
            else:
                request.status = ApprovalStatus.APPROVED
            request.resolved_at = datetime.utcnow()
            await self.temporal.signal_workflow_execution(
                workflow_id=str(request.saga_id),
                signal="approval_decision",
                arg={"status": request.status.value, "request_id": str(request.id)},
            )
            await self.db.commit()