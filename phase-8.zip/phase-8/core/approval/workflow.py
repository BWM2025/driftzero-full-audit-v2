"""Temporal signal integration for approval decisions"""

from __future__ import annotations

from temporalio import workflow
from datetime import timedelta

@workflow.signal
async def approval_decision(self, data: dict) -> None:
    self.approval_result = data