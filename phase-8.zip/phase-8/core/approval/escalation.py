"""Auto-escalation on SLA breach"""

from __future__ import annotations

from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from core.approval.models.request import ApprovalRequest, ApprovalStatus


async def escalate_stale_requests(db: AsyncSession) -> None:
    threshold = datetime.utcnow() - timedelta(hours=12)
    stale = await db.execute(
        select(ApprovalRequest).where(
            ApprovalRequest.status == ApprovalStatus.PENDING,
            ApprovalRequest.requested_at < threshold,
        )
    )
    for req in stale.scalars():
        # Notify admins or auto-reject
        pass